'''Day-based weather effects and lightning strikes.'''

import math
import random
import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    LIGHTNING_MIN_INTERVAL,
    LIGHTNING_MAX_INTERVAL,
    LIGHTNING_DAMAGE,
    LIGHTNING_HIT_RADIUS,
    LIGHTNING_SPREAD_X,
    LIGHTNING_SPREAD_Y,
)


class WeatherEffects:
    def __init__(self):
        self.rain_drops = [
            [random.randrange(SCREEN_WIDTH), random.randrange(SCREEN_HEIGHT)]
            for _ in range(140)
        ]
        self._storm_started = False
        self.lightning_timer = random.uniform(LIGHTNING_MIN_INTERVAL, LIGHTNING_MAX_INTERVAL)
        self.lightning_flash_timer = 0.0
        self.lightning_bolt_timer = 0.0
        self.lightning_points = []

    def update(self, dt: float, current_day: int, player) -> bool:
        '''Update rain and lightning; return whether this strike hit the player.'''
        hit_by_lightning = False

        if current_day >= 2:
            rain_speed = 420.0 if current_day == 2 else 600.0
            for drop in self.rain_drops:
                drop[0] = (drop[0] + rain_speed * dt * 0.12) % SCREEN_WIDTH
                drop[1] += rain_speed * dt
                if drop[1] >= SCREEN_HEIGHT:
                    drop[0] = random.randrange(SCREEN_WIDTH)
                    drop[1] = random.randrange(-40, 0)

        self.lightning_flash_timer = max(0.0, self.lightning_flash_timer - dt)
        self.lightning_bolt_timer = max(0.0, self.lightning_bolt_timer - dt)

        if current_day < 3:
            self._storm_started = False
            return hit_by_lightning

        if not self._storm_started:
            self._storm_started = True
            self.lightning_timer = random.uniform(LIGHTNING_MIN_INTERVAL, LIGHTNING_MAX_INTERVAL)

        self.lightning_timer -= dt
        if self.lightning_timer > 0.0:
            return hit_by_lightning

        self.lightning_timer = random.uniform(LIGHTNING_MIN_INTERVAL, LIGHTNING_MAX_INTERVAL)
        self.lightning_flash_timer = 0.22
        self.lightning_bolt_timer = 0.45

        player_x, player_y = player.hitbox.center
        strike_x = player_x + random.uniform(-LIGHTNING_SPREAD_X, LIGHTNING_SPREAD_X)
        strike_y = player_y + random.uniform(-LIGHTNING_SPREAD_Y, LIGHTNING_SPREAD_Y)
        self.lightning_points = self._make_bolt(strike_x, strike_y)

        distance = math.hypot(strike_x - player_x, strike_y - player_y)
        if distance <= LIGHTNING_HIT_RADIUS:
            player.survival.health = max(0.0, player.survival.health - LIGHTNING_DAMAGE)
            if player.survival.health <= 0.0:
                player.survival.is_dead = True
            hit_by_lightning = True

        return hit_by_lightning

    @staticmethod
    def _make_bolt(x: float, y: float) -> list[tuple[int, int]]:
        points = [(int(x), int(y - 210))]
        for step in range(1, 7):
            points.append((int(x + random.randint(-28, 28)), int(y - 210 + step * 30)))
        points.append((int(x), int(y)))
        return points

    def draw(self, surface: pygame.Surface, camera, current_day: int):
        if current_day >= 2:
            shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            shade.fill((50, 60, 75, 28 if current_day == 2 else 48))
            surface.blit(shade, (0, 0))

            drop_count = 65 if current_day == 2 else 140
            rain_color = (165, 190, 210) if current_day == 2 else (145, 175, 200)
            rain_length = 7 if current_day == 2 else 11
            for x, y in self.rain_drops[:drop_count]:
                start = (int(x), int(y))
                end = (int(x - 3), int(y + rain_length))
                pygame.draw.line(surface, rain_color, start, end, 1)

        if self.lightning_bolt_timer > 0.0 and self.lightning_points:
            screen_points = [
                (int(x - camera.x), int(y - camera.y))
                for x, y in self.lightning_points
            ]
            pygame.draw.lines(surface, (205, 230, 255), False, screen_points, 4)
            pygame.draw.lines(surface, (255, 255, 255), False, screen_points, 2)
            impact_x, impact_y = screen_points[-1]
            pygame.draw.ellipse(surface, (45, 37, 31), (impact_x - 9, impact_y - 3, 18, 7))
            pygame.draw.circle(surface, (255, 248, 205), (impact_x, impact_y), 7)
            pygame.draw.circle(surface, (255, 255, 255), (impact_x, impact_y), 3)
            for dx, dy in ((-16, 5), (-9, 12), (9, 11), (16, 4)):
                pygame.draw.line(
                    surface,
                    (255, 230, 160),
                    (impact_x, impact_y),
                    (impact_x + dx, impact_y + dy),
                    2,
                )

        if self.lightning_flash_timer > 0.0:
            flash = pygame.Surface(surface.get_size())
            flash.fill((255, 255, 255))
            alpha = int(175 * self.lightning_flash_timer / 0.22)
            flash.set_alpha(alpha)
            surface.blit(flash, (0, 0))

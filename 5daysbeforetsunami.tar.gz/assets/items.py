'''
해일 전 3일 (3 Days Before Tsunami)
아이템 및 제작 레시피 데이터 관리 모듈
'''

import json
from pathlib import Path
import pygame
from image_assets import fit_sprite, get_item_sprite, get_item_surface, get_sprite_frames

# 기본 내장 데이터 (데이터 파일이 없거나 브라우저 환경에서 경로 문제가 발생할 때를 대비한 안전망)
DEFAULT_ITEMS = {
    "branch": {
        "id": "branch",
        "name": "나뭇가지",
        "category": "자원",
        "description": "땅에 떨어진 굵은 나뭇가지. 도구 제작과 땔감으로 쓰입니다.",
        "color": [140, 95, 60],
        "icon": "stick",
    },
    "wood_log": {
        "id": "wood_log",
        "name": "나무 원목",
        "category": "자원",
        "description": "돌도끼로 벌목하여 얻은 통나무. 건축과 모닥불의 주 재료입니다.",
        "color": [115, 75, 45],
        "icon": "log",
    },
    "stone": {
        "id": "stone",
        "name": "돌",
        "category": "자원",
        "description": "해변과 숲에 흩어져 있는 단단한 돌멩이. 도구 제작에 필수입니다.",
        "color": [130, 135, 145],
        "icon": "stone",
    },
    "plant_fiber": {
        "id": "plant_fiber",
        "name": "풀 1번",
        "category": "자원",
        "description": "해안가 덤불에서 채취한 질긴 줄기. 밧줄이나 천을 엮는 데 쓰입니다.",
        "color": [100, 180, 80],
        "icon": "fiber",
    },
    "berry": {
        "id": "berry",
        "name": "베리",
        "category": "식량/자원",
        "description": "야생 베리 덤불에서 딴 달콤한 열매. 수분과 영양을 공급합니다.",
        "color": [220, 60, 70],
        "icon": "berry",
    },
    "coconut": {
        "id": "coconut",
        "name": "코코넛",
        "category": "식량/자원",
        "description": "야자수에서 떨어진 열매. 갈증을 해소하고 다양하게 활용됩니다.",
        "color": [150, 105, 55],
        "icon": "coconut",
    },
    "stone_axe": {
        "id": "stone_axe",
        "name": "돌도끼",
        "category": "도구",
        "description": "돌과 가지, 섬유를 엮어 만든 도끼. 야자수를 베어 [나무 원목]을 채취합니다.",
        "color": [180, 185, 195],
        "icon": "axe",
    },
    "rope": {
        "id": "rope",
        "name": "밧줄",
        "category": "가공품",
        "description": "식물 섬유를 꼬아 만든 질긴 밧줄. 거처 제작에 필수입니다.",
        "color": [190, 160, 110],
        "icon": "rope",
    },
    "cloth": {
        "id": "cloth",
        "name": "돛천",
        "category": "가공품",
        "description": "가지 틀에 섬유를 엮어 만든 직물. 비바람을 막는 지붕이 됩니다.",
        "color": [215, 205, 185],
        "icon": "cloth",
    },
    "campfire": {
        "id": "campfire",
        "name": "모닥불",
        "category": "구조물",
        "description": "원목과 돌로 둘러쌓은 모닥불. 추위와 어둠을 쫓아줍니다.",
        "color": [245, 120, 40],
        "icon": "campfire",
    },
    "torch": {
        "id": "torch",
        "name": "횃불",
        "category": "도구/조명",
        "description": "나뭇가지에 섬유를 감아 불을 붙인 휴대용 조명입니다.",
        "color": [255, 170, 50],
        "icon": "torch",
    },
    "shelter": {
        "id": "shelter",
        "name": "간이 거처",
        "category": "구조물",
        "description": "다가올 거대한 해일과 폭풍에 맞설 수 있는 견고한 쉼터입니다.",
        "color": [160, 120, 80],
        "icon": "shelter",
    },
    "base_raft": {
        "id": "base_raft",
        "name": "기본 뗏목",
        "category": "탈출/선박",
        "description": "원목을 밧줄로 엮어 만든 튼튼한 뗏목 선체. 해변 건조대에 설치합니다.",
        "color": [140, 95, 55],
        "icon": "raft",
    },
    "sail": {
        "id": "sail",
        "name": "돛",
        "category": "탈출/선박",
        "description": "바람을 타고 해일을 벗어날 수 있게 해주는 돛입니다.",
        "color": [235, 225, 205],
        "icon": "sail",
    },
}

DEFAULT_RECIPES = {
    "stone_axe": {
        "result_id": "stone_axe",
        "name": "돌도끼",
        "yield_count": 1,
        "category": "도구",
        "description": "야자수를 벌목하여 [나무 원목]을 획득할 수 있습니다.",
        "ingredients": {"branch": 2, "stone": 2, "plant_fiber": 1},
    },
    "rope": {
        "result_id": "rope",
        "name": "밧줄",
        "yield_count": 1,
        "category": "가공품",
        "description": "구조물을 결속하는 질긴 밧줄입니다.",
        "ingredients": {"plant_fiber": 2},
    },
    "cloth": {
        "result_id": "cloth",
        "name": "천 (돛천)",
        "yield_count": 1,
        "category": "가공품",
        "description": "거처 지붕이나 뗏목 돛을 만드는 데 쓰이는 직물입니다.",
        "ingredients": {"branch": 2, "plant_fiber": 3},
    },
    "campfire": {
        "result_id": "campfire",
        "name": "모닥불",
        "yield_count": 1,
        "category": "구조물",
        "description": "따뜻함과 빛을 제공하고 생존 기반이 됩니다.",
        "ingredients": {"wood_log": 3, "stone": 2},
    },
    "torch": {
        "result_id": "torch",
        "name": "횃불",
        "yield_count": 1,
        "category": "도구/조명",
        "description": "주변을 밝히는 들고 다닐 수 있는 횃불입니다.",
        "ingredients": {"branch": 2, "plant_fiber": 1},
    },
    "shelter": {
        "result_id": "shelter",
        "name": "간이 거처",
        "yield_count": 1,
        "category": "구조물",
        "description": "해일과 폭풍에 맞설 수 있는 견고한 쉼터입니다.",
        "ingredients": {"wood_log": 3, "rope": 2, "stone": 3, "cloth": 1},
    },
    "base_raft": {
        "result_id": "base_raft",
        "name": "기본 뗏목",
        "yield_count": 1,
        "category": "탈출/선박",
        "description": "해변 건조대에 설치할 기본 뗏목 선체입니다.",
        "ingredients": {"wood_log": 10, "rope": 4, "stone": 3},
    },
    "sail": {
        "result_id": "sail",
        "name": "돛",
        "yield_count": 1,
        "category": "탈출/선박",
        "description": "해변의 뗏목에 장착할 바람을 타는 돛입니다.",
        "ingredients": {"wood_log": 2, "rope": 2, "cloth": 1},
    },
}


def load_items_data() -> dict:
    '''data/items.json 에서 아이템 데이터 로드'''
    data_path = Path(__file__).parent / "data" / "items.json"
    if data_path.is_file():
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[Warning] Failed to load data/items.json: {e}")
    return DEFAULT_ITEMS


def load_recipes_data() -> dict:
    '''data/recipes.json 에서 제작법 데이터 로드'''
    data_path = Path(__file__).parent / "data" / "recipes.json"
    if data_path.is_file():
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[Warning] Failed to load data/recipes.json: {e}")
    return DEFAULT_RECIPES


ITEMS = load_items_data()
RECIPES = load_recipes_data()


def get_item(item_id: str) -> dict:
    '''아이템 정보 조회 (존재하지 않을 시 기본 딕셔너리 반환)'''
    return ITEMS.get(
        item_id,
        {
            "id": item_id,
            "name": item_id,
            "category": "기타",
            "description": "",
            "color": [200, 200, 200],
            "icon": "unknown",
        },
    )


def get_recipe(recipe_id: str) -> dict:
    '''제작 레시피 조회'''
    return RECIPES.get(recipe_id)


# 아이템 픽셀 아이콘 생성 캐시
_ICON_CACHE = {}

# image_assets.get_item_surface를 통해 정확하게 로드 가능한 아이템 목록
_IMAGE_ASSET_ITEMS = {
    "branch",
    "wood_log",
    "stone",
    "plant_fiber",
    "berry",
    "coconut",
    "stone_axe",
    "rope",
    "cloth",
    "torch",
    "campfire",
    "shelter",
}


def get_item_icon(item_id: str, size: int = 24) -> pygame.Surface:
    '''아이템 ID에 대응하는 깔끔한 픽셀 그래픽 아이콘 표면 생성 및 캐싱'''
    cache_key = (item_id, size)
    if cache_key in _ICON_CACHE:
        return _ICON_CACHE[cache_key]

    sprite = None
    if item_id in _IMAGE_ASSET_ITEMS:
        try:
            sprite = get_item_surface(item_id)
        except Exception:
            sprite = None

    if sprite is not None:
        icon = fit_sprite(sprite, (size, size))
        _ICON_CACHE[cache_key] = icon
        return icon

    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    item = get_item(item_id)
    icon_type = item.get("icon", item_id)
    col = item.get("color", [200, 200, 200])

    if icon_type == "stick":
        # 대각선 나뭇가지
        pygame.draw.line(surf, (80, 50, 30), (4, size - 4), (size - 4, 4), 5)
        pygame.draw.line(surf, (140, 95, 60), (5, size - 5), (size - 5, 5), 3)
        pygame.draw.line(surf, (180, 130, 80), (7, size - 7), (size - 7, 7), 1)

    elif icon_type == "log":
        # 둥근 통나무 단면과 몸통
        pygame.draw.rect(surf, (80, 50, 30), (3, 6, size - 6, size - 12))
        pygame.draw.rect(surf, (120, 80, 50), (4, 7, size - 8, size - 14))
        pygame.draw.ellipse(surf, (190, 150, 100), (3, 6, 8, size - 12))
        pygame.draw.circle(surf, (140, 100, 60), (7, size // 2), 2)

    elif icon_type == "stone":
        # 다면체 돌멩이
        pts = [(6, size - 5), (3, 11), (11, 4), (size - 5, 7), (size - 3, size - 7)]
        pygame.draw.polygon(surf, (70, 75, 85), pts)
        inner = [(7, size - 6), (5, 12), (11, 6), (size - 6, 8), (size - 5, size - 8)]
        pygame.draw.polygon(surf, (130, 135, 145), inner)
        pygame.draw.polygon(surf, (180, 185, 195), [(10, 7), (size - 8, 9), (size // 2, 13)])

    elif icon_type == "fiber":
        # 땋은 식물 줄기/풀잎 3가닥
        pygame.draw.line(surf, (40, 100, 35), (4, size - 4), (size - 6, 6), 4)
        pygame.draw.line(surf, (80, 170, 60), (4, size - 4), (size - 6, 6), 2)
        pygame.draw.line(surf, (120, 210, 90), (6, size - 4), (size - 4, 10), 2)
        pygame.draw.line(surf, (90, 180, 70), (size // 2, size - 4), (size - 4, 14), 2)

    elif icon_type == "berry":
        # 동글동글한 붉은 베리 3알 + 녹색 잎
        pygame.draw.circle(surf, (50, 130, 40), (size // 2, 5), 3)
        berries = [(8, 14), (16, 14), (12, 18)]
        for bx, by in berries:
            pygame.draw.circle(surf, (120, 20, 30), (bx, by), 5)
            pygame.draw.circle(surf, (220, 50, 60), (bx, by), 4)
            pygame.draw.circle(surf, (255, 140, 150), (bx - 1, by - 1), 1)

    elif icon_type == "coconut":
        # 둥근 코코넛 열매
        cx, cy = size // 2, size // 2
        pygame.draw.circle(surf, (80, 50, 25), (cx, cy), 9)
        pygame.draw.circle(surf, (140, 95, 50), (cx, cy), 8)
        # 코코넛 세 개의 눈
        pygame.draw.circle(surf, (60, 35, 15), (cx - 3, cy - 2), 1)
        pygame.draw.circle(surf, (60, 35, 15), (cx + 3, cy - 2), 1)
        pygame.draw.circle(surf, (60, 35, 15), (cx, cy + 3), 1)

    elif icon_type == "axe":
        # 돌도끼: 갈색 자루 + 돌날
        pygame.draw.line(surf, (100, 65, 40), (4, size - 4), (size - 6, 6), 3)
        axe_head = [(size - 12, 3), (size - 2, 3), (size - 4, 13), (size - 14, 11)]
        pygame.draw.polygon(surf, (70, 75, 85), axe_head)
        pygame.draw.polygon(surf, (170, 175, 185), axe_head, 1)

    elif icon_type == "rope":
        # 꼬인 밧줄 매듭
        pygame.draw.ellipse(surf, (130, 100, 60), (4, 4, size - 8, size - 8), 4)
        pygame.draw.ellipse(surf, (200, 170, 110), (5, 5, size - 10, size - 10), 2)
        pygame.draw.line(surf, (130, 100, 60), (4, size // 2), (size - 4, size // 2), 3)

    elif icon_type == "cloth":
        # 접힌 직물/천
        rect = pygame.Rect(4, 5, size - 8, size - 10)
        pygame.draw.rect(surf, (160, 150, 130), rect)
        pygame.draw.rect(surf, (220, 210, 190), (5, 6, size - 10, size - 12))
        pygame.draw.line(surf, (180, 170, 150), (8, 6), (8, size - 7), 1)
        pygame.draw.line(surf, (180, 170, 150), (14, 6), (14, size - 7), 1)

    elif icon_type == "campfire":
        # 바닥 돌/나무 + 활활 타오르는 불꽃
        pygame.draw.ellipse(surf, (80, 50, 30), (3, size - 7, size - 6, 6))
        flame_pts = [(size // 2, 3), (size - 6, size - 6), (size // 2, size - 4), (6, size - 6)]
        pygame.draw.polygon(surf, (240, 80, 30), flame_pts)
        inner_flame = [(size // 2, 7), (size - 9, size - 6), (9, size - 6)]
        pygame.draw.polygon(surf, (255, 200, 50), inner_flame)

    elif icon_type == "torch":
        # 막대기 + 불꽃
        pygame.draw.line(surf, (110, 75, 45), (6, size - 4), (size - 8, 10), 3)
        pygame.draw.circle(surf, (240, 90, 30), (size - 6, 8), 6)
        pygame.draw.circle(surf, (255, 210, 60), (size - 6, 8), 3)

    elif icon_type == "shelter":
        # 삼각 텐트/쉼터
        tent_pts = [(size // 2, 3), (size - 4, size - 4), (4, size - 4)]
        pygame.draw.polygon(surf, (130, 90, 60), tent_pts)
        pygame.draw.polygon(surf, (190, 150, 110), [(size // 2, 4), (size - 6, size - 5), (size // 2, size - 5)])
        # 입구
        pygame.draw.polygon(surf, (40, 30, 20), [(size // 2, 10), (size // 2 + 4, size - 4), (size // 2 - 4, size - 4)])

    elif icon_type == "raft":
        # 뗏목: 3개의 엮인 통나무
        pygame.draw.rect(surf, (115, 75, 45), (4, 4, size - 8, 4), border_radius=2)
        pygame.draw.rect(surf, (135, 90, 55), (4, 9, size - 8, 5), border_radius=2)
        pygame.draw.rect(surf, (115, 75, 45), (4, 15, size - 8, 5), border_radius=2)
        # 결속 밧줄 2줄
        pygame.draw.line(surf, (190, 160, 100), (8, 3), (8, 20), 2)
        pygame.draw.line(surf, (190, 160, 100), (size - 9, 3), (size - 9, 20), 2)

    elif icon_type == "sail":
        # 돛: 기둥 + 바람을 머금은 흰색 삼각 돛
        pygame.draw.line(surf, (110, 75, 45), (6, 3), (6, size - 3), 3)
        pygame.draw.line(surf, (110, 75, 45), (6, size - 6), (size - 4, size - 6), 2)
        # 돛천
        sail_pts = [(7, 4), (size - 5, size - 7), (7, size - 7)]
        pygame.draw.polygon(surf, (235, 230, 215), sail_pts)
        pygame.draw.polygon(surf, (180, 175, 160), sail_pts, 1)

    else:
        # 기본 사각형
        pygame.draw.rect(surf, col, (3, 3, size - 6, size - 6), border_radius=3)
        pygame.draw.rect(surf, (255, 255, 255), (3, 3, size - 6, size - 6), 1, border_radius=3)

    _ICON_CACHE[cache_key] = surf
    return surf

"""
해일 전 5일 (5 Days Before Tsunami)
생존, 멧돼지 및 탐험가의 일지 시스템이 연동된 메인 게임 루프
"""

import asyncio
import sys
import pygame

from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    FPS,
    TITLE,
    COLOR_UI_TEXT,
    COLOR_UI_BG,
    COLOR_UI_ACCENT,
)
from fonts import get_font, draw_font_warning_if_needed
from player import Player
from world import World, Camera
from structures import PlacedShelter
from journal import PlacedJournal, JournalUI
from ui import (
    CraftingUI,
    NotificationManager,
    draw_survival_bars,
    draw_time_hud,
    draw_interaction_prompt,
    draw_bottom_quickbar,
    draw_game_over_or_tsunami,
)


def draw_hud(screen: pygame.Surface, clock: pygame.time.Clock, player: Player):
    """상단 좌측 타이틀 & 조작 가이드 패널"""
    title_font = get_font(18, bold=True)
    controls_font = get_font(13)

    panel_w = 350
    panel_h = 60
    panel_surface = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    pygame.draw.rect(panel_surface, COLOR_UI_BG, (0, 0, panel_w, panel_h), border_radius=6)
    pygame.draw.rect(panel_surface, (70, 90, 110, 180), (0, 0, panel_w, panel_h), width=1, border_radius=6)

    # 타이틀
    title_text = title_font.render(TITLE, True, COLOR_UI_TEXT)
    panel_surface.blit(title_text, (10, 8))

    # 조작 가이드 ([J] 일지 추가)
    controls_text = controls_font.render("WASD: 이동 | E: 상호작용 | TAB: 제작 | J: 일지", True, COLOR_UI_ACCENT)
    panel_surface.blit(controls_text, (10, 33))

    screen.blit(panel_surface, (16, 16))


async def main():
    """비동기 게임 루프 (Pygbag 웹 브라우저 호환)"""
    pygame.init()
    pygame.font.init()

    # 960x540 16:9 화면 생성
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(TITLE)

    clock = pygame.time.Clock()

    # 1. 월드 및 플레이어 초기화
    world = World()
    player = Player(world.spawn_point[0], world.spawn_point[1])

    # 2. 카메라 생성
    camera = Camera(world.width, world.height)
    camera.x = max(0.0, min(player.x - SCREEN_WIDTH / 2, world.width - SCREEN_WIDTH))
    camera.y = max(0.0, min(player.y - SCREEN_HEIGHT / 2, world.height - SCREEN_HEIGHT))

    # 3. UI 시스템 초기화
    crafting_ui = CraftingUI()
    journal_ui = JournalUI()
    notifications = NotificationManager()

    notifications.add("시작 지점에 [탐험가의 일지]가 있습니다! [E] 또는 [J]키로 열어보세요.", color=(255, 220, 100), duration=5.0)
    notifications.add("생존 목표: 5일 후 도달할 거대한 해일에 대비하세요!", color=(220, 230, 245), duration=4.5)

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        dt = min(dt, 0.05)

        # ----------------- 이벤트 처리 -----------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

            # 사망 또는 해일 도달 시 [R] 키로 재시작
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                if player.survival.is_dead or world.time_system.tsunami_arrived:
                    world = World()
                    player = Player(world.spawn_point[0], world.spawn_point[1])
                    camera.x = max(0.0, min(player.x - SCREEN_WIDTH / 2, world.width - SCREEN_WIDTH))
                    camera.y = max(0.0, min(player.y - SCREEN_HEIGHT / 2, world.height - SCREEN_HEIGHT))
                    crafting_ui.is_open = False
                    journal_ui.is_open = False
                    notifications.notifications.clear()
                    notifications.add("새로운 생존을 시작합니다! [1일 차]", color=(255, 230, 120))
                    continue

            # 탐험가의 일지 이벤트 우선 처리 ([J] 키 토글 등)
            consumed_by_journal = journal_ui.handle_event(event)
            if consumed_by_journal:
                continue

            # 인벤토리/제작 창 이벤트 처리
            if not journal_ui.is_open:
                consumed = crafting_ui.handle_event(event, player, world, notifications)
                if consumed:
                    continue

            # 퀵 섭취 단축키 (필드에서 1번: 베리 섭취, 2번: 코코넛 섭취)
            if event.type == pygame.KEYDOWN and not crafting_ui.is_open and not journal_ui.is_open:
                if event.key == pygame.K_1:
                    if player.inventory.has_item("berry"):
                        success, rec, msg = player.survival.eat("berry")
                        if success:
                            player.inventory.remove_item("berry", 1)
                            notifications.add(msg, color=(100, 240, 140))
                        else:
                            notifications.add(msg, color=(255, 160, 90))
                    else:
                        notifications.add("가방에 베리가 없습니다.", color=(180, 180, 190))
                elif event.key == pygame.K_2:
                    if player.inventory.has_item("coconut"):
                        success, rec, msg = player.survival.eat("coconut")
                        if success:
                            player.inventory.remove_item("coconut", 1)
                            notifications.add(msg, color=(100, 240, 140))
                        else:
                            notifications.add(msg, color=(255, 160, 90))
                    else:
                        notifications.add("가방에 코코넛이 없습니다.", color=(180, 180, 190))

        # ----------------- 로직 업데이트 -----------------
        # 탐험가의 일지를 읽는 동안에는 게임 시간 및 월드 업데이트가 완전히 정지됨
        is_paused = journal_ui.is_open

        if not is_paused:
            # 1. 5일 낮/밤 시간 시스템 갱신
            time_events = world.time_system.update(dt)
            for evt_type, evt_msg in time_events:
                if evt_type == "NIGHT_START":
                    notifications.add(evt_msg, color=(140, 180, 255), duration=4.0)
                elif evt_type == "DAY_START":
                    notifications.add(evt_msg, color=(255, 230, 100), duration=4.0)
                elif evt_type == "NEW_DAY":
                    notifications.add(evt_msg, color=(255, 215, 80), duration=4.5)
                elif evt_type == "TSUNAMI":
                    notifications.add(evt_msg, color=(100, 220, 255), duration=6.0)

            # 2. 월드 동적 오브젝트(모닥불, 멧돼지 AI) 갱신
            world_events = world.update(dt, player)
            for evt_type, evt_msg in world_events:
                if evt_type == "BOAR_ATTACK":
                    notifications.add(evt_msg, color=(255, 60, 60), duration=3.0)

            # 3. 플레이어 이동 및 생존 수치(허기, 체온, 체력) 갱신
            can_move = not crafting_ui.is_open and not player.survival.is_dead and not world.time_system.tsunami_arrived
            survival_alerts = player.update(dt, world, can_move=can_move)
            for alert_type, alert_msg in survival_alerts:
                notifications.add(alert_msg, color=(255, 90, 80), duration=3.5)

            # 4. 상호작용 가능한 근처 노드 탐색
            nearby_node = world.get_nearby_interactable(player)

            # 5. [E] 키 1회 누름 시 상호작용 (일지 펼치기, 수면, 채집, 벌목 등)
            if player.e_just_pressed and not crafting_ui.is_open and nearby_node:
                if isinstance(nearby_node, PlacedJournal):
                    journal_ui.is_open = True
                    notifications.add("탐험가의 일지를 펼쳤습니다. [게임 일시정지, J키로 닫기]", color=(255, 215, 80))
                elif isinstance(nearby_node, PlacedShelter):
                    success, msg = nearby_node.interact(player, world.time_system)
                    msg_color = (100, 240, 140) if success else (255, 170, 80)
                    notifications.add(msg, color=msg_color)
                else:
                    success, item_id, count, msg = nearby_node.interact(player)
                    if msg:
                        msg_color = (100, 240, 140) if success else (255, 180, 90)
                        notifications.add(msg, color=msg_color)

            camera.update(player.hitbox)
            notifications.update(dt)
        else:
            nearby_node = None

        # ----------------- 렌더링 -----------------
        # 1) 지형 타일
        world.draw_ground(screen, camera)

        # 2) Y-정렬 엔티티 (바위, 나무, 거처, 모닥불, 일지, 멧돼지, 자원 노드, 플레이어)
        world.draw_entities(screen, camera, player)

        # 3) 밤 암전 및 시야/조명 효과
        world.draw_lighting_and_darkness(screen, camera, player)

        # 4) 상호작용 안내 툴팁
        if nearby_node and not crafting_ui.is_open and not journal_ui.is_open and not player.survival.is_dead:
            if isinstance(nearby_node, PlacedShelter):
                prompt = nearby_node.get_prompt(player, world.time_system)
            else:
                prompt = nearby_node.get_prompt(player)
            draw_interaction_prompt(screen, prompt)

        # 5) 상단 HUD: 타이틀 / 시간 / 생존 수치
        draw_hud(screen, clock, player)
        draw_time_hud(screen, world.time_system)
        draw_survival_bars(screen, player)

        # 6) 알림 팝업 및 하단 퀵바
        notifications.draw(screen)
        draw_bottom_quickbar(screen, player)

        # 7) [TAB] 가방 & 제작 모달 창
        crafting_ui.draw(screen, player)

        # 8) [J] 탐험가의 일지 큰 책 모달 창 (시간 정지 상태)
        journal_ui.draw(screen)

        # 9) 사망 또는 해일 도달 오버레이
        draw_game_over_or_tsunami(screen, player, world.time_system)

        # 10) 폰트 상태 경고 배너
        draw_font_warning_if_needed(screen)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())

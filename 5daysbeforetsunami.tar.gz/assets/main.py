import asyncio
import sys
import pygame

from audio import BackgroundMusic, SoundEffects
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    FPS,
    TITLE,
)
from fonts import draw_font_warning_if_needed
from player import Player
from world import World, Camera
from raft import RaftEscapeCutscene, RaftSlipway
from structures import PlacedShelter
from journal import PlacedJournal, JournalUI
from ui import (
    CraftingUI,
    NotificationManager,
    draw_survival_bars,
    draw_time_hud,
    draw_interaction_prompt,
    draw_bottom_quickbar,
    draw_game_over_or_tsunami,
    PauseMenu,
    TitleScreen,
    OpeningSequence,
)


async def main():
    pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=1024)
    pygame.init()
    pygame.font.init()

    # 960x540 16:9 화면 생성
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(TITLE)

    clock = pygame.time.Clock()
    sounds = SoundEffects()
    music = BackgroundMusic()

    # 1. 월드 및 플레이어 초기화
    world = World()
    player = Player(world.spawn_point[0], world.spawn_point[1])

    # 2. 카메라 생성
    camera = Camera(world.width, world.height)
    camera.x = max(0.0, min(player.x - SCREEN_WIDTH / 2, world.width - SCREEN_WIDTH))
    camera.y = max(0.0, min(player.y - SCREEN_HEIGHT / 2, world.height - SCREEN_HEIGHT))

    # 3. UI 시스템 초기화
    crafting_ui = CraftingUI()
    journal_ui = JournalUI()
    notifications = NotificationManager()
    escape_cutscene = RaftEscapeCutscene()
    pause_menu = PauseMenu()
    title_screen = TitleScreen()
    opening_sequence = OpeningSequence()
    music.play("title", fade_ms=0)
    world_frame = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    zoomed_world_frame = pygame.Surface((round(SCREEN_WIDTH * 1.25), round(SCREEN_HEIGHT * 1.25)))
    camera_zoom = 1.25
    seen_interaction_prompts = set()

    notifications.add("시작 지점의 [탐험가의 일지]는 좌클릭 또는 [J]키로 열 수 있습니다.", color=(255, 220, 100), duration=5.0)
    notifications.add("생존 목표: 3일 후 도달할 거대한 해일에 대비하세요!", color=(220, 230, 245), duration=4.5)

    def return_to_title():
        nonlocal world, player, escape_cutscene
        world = World()
        player = Player(world.spawn_point[0], world.spawn_point[1])
        escape_cutscene = RaftEscapeCutscene()
        camera.x = max(0.0, min(player.x - SCREEN_WIDTH / 2, world.width - SCREEN_WIDTH))
        camera.y = max(0.0, min(player.y - SCREEN_HEIGHT / 2, world.height - SCREEN_HEIGHT))
        crafting_ui.is_open = False
        journal_ui.is_open = False
        pause_menu.is_open = False
        opening_sequence.is_active = False
        title_screen.is_open = True
        seen_interaction_prompts.clear()
        notifications.notifications.clear()
        notifications.add("시작 지점의 [탐험가의 일지]는 좌클릭 또는 [J]키로 열 수 있습니다.", color=(255, 220, 100), duration=5.0)
        notifications.add("생존 목표: 3일 후 도달할 거대한 해일에 대비하세요!", color=(220, 230, 245), duration=4.5)
        music.play("title")

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        dt = min(dt, 0.05)
        music.update(dt)
        left_click_pressed = False

        # ----------------- 이벤트 처리 -----------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

            if escape_cutscene.is_active and escape_cutscene.is_finished:
                if (
                    event.type == pygame.KEYDOWN
                    and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE)
                    or event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                ):
                    return_to_title()
                continue

            if escape_cutscene.is_active:
                continue

            if title_screen.is_open:
                action = title_screen.handle_event(event)
                if action == "start":
                    sounds.play("ui")
                    music.play("survival")
                    title_screen.is_open = False
                    opening_sequence.start(player)
                elif action == "quit":
                    sounds.play("ui")
                    running = False
                    break
                continue

            if opening_sequence.is_active:
                opening_sequence.handle_event(event, player)
                continue

            if player.survival.is_dead or world.time_system.tsunami_arrived:
                if (
                    event.type == pygame.KEYDOWN
                    and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE, pygame.K_r)
                    or event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                ):
                    return_to_title()
                continue

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                sounds.play("ui")
                if pause_menu.is_open:
                    action = pause_menu.handle_event(event)
                    if action == "continue":
                        pause_menu.is_open = False
                    continue
                if journal_ui.is_open or crafting_ui.is_open:
                    if journal_ui.is_open:
                        journal_ui.handle_event(event)
                    else:
                        crafting_ui.handle_event(event, player, world, notifications)
                    continue
                pause_menu.is_open = True
                continue

            if pause_menu.is_open:
                action = pause_menu.handle_event(event)
                if action:
                    sounds.play("ui")
                if action == "continue":
                    pause_menu.is_open = False
                elif action == "title":
                    return_to_title()
                elif action == "quit":
                    running = False
                    break
                continue

            # 탐험가의 일지 이벤트 우선 처리 ([J] 키 토글 등)
            consumed_by_journal = journal_ui.handle_event(event)
            if consumed_by_journal:
                continue

            # 인벤토리/제작 창 이벤트 처리
            if not journal_ui.is_open:
                selected_item = crafting_ui.selected_item_id
                selected_count = player.inventory.get_count(selected_item) if selected_item else 0
                inventory_before_event = player.inventory.items
                placement_position = None
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                    player_anchor_x = int(player.hitbox.centerx - camera.x)
                    player_anchor_y = int(player.hitbox.centery - camera.y)
                    zoom_offset_x = round(player_anchor_x * (1 - camera_zoom))
                    zoom_offset_y = round(player_anchor_y * (1 - camera_zoom))
                    placement_position = (
                        camera.x + (event.pos[0] - zoom_offset_x) / camera_zoom,
                        camera.y + (event.pos[1] - zoom_offset_y) / camera_zoom,
                    )
                consumed = crafting_ui.handle_event(
                    event,
                    player,
                    world,
                    notifications,
                    placement_position=placement_position,
                )
                if (
                    event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 3
                    and selected_item in ("berry", "coconut", "campfire", "shelter")
                    and player.inventory.get_count(selected_item) < selected_count
                ):
                    sounds.play("eat" if selected_item in ("berry", "coconut") else "build")
                elif consumed and (
                    event.type == pygame.KEYDOWN
                    and event.key in (pygame.K_e, pygame.K_TAB)
                    or event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                ):
                    sounds.play(
                        "build" if player.inventory.items != inventory_before_event else "ui"
                    )
                if consumed:
                    continue

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                left_click_pressed = True

        if not running:
            break

        if title_screen.is_open:
            music.ensure_playing("title")
            title_screen.draw(screen)
            pygame.display.flip()
            await asyncio.sleep(0)
            continue

        if escape_cutscene.is_active:
            if not escape_cutscene.is_finished:
                escape_cutscene.update(dt)
            escape_cutscene.draw(screen)
            pygame.display.flip()
            await asyncio.sleep(0)
            continue

        # ----------------- 로직 업데이트 -----------------
        # 탐험가의 일지를 읽는 동안에는 게임 시간 및 월드 업데이트가 완전히 정지됨
        is_paused = journal_ui.is_open or pause_menu.is_open or opening_sequence.is_active

        if not is_paused:
            # 1. 3일 낮/밤 시간 시스템 갱신
            time_events = world.time_system.update(dt)
            for evt_type, evt_msg in time_events:
                if evt_type == "NIGHT_START":
                    notifications.add(evt_msg, color=(140, 180, 255), duration=4.0)
                elif evt_type == "DAY_START":
                    notifications.add(evt_msg, color=(255, 230, 100), duration=4.0)
                elif evt_type == "NEW_DAY":
                    notifications.add(evt_msg, color=(255, 215, 80), duration=4.5)
                elif evt_type == "TSUNAMI":
                    notifications.add(evt_msg, color=(100, 220, 255), duration=6.0)

            # 2. 월드 동적 오브젝트(모닥불, 멧돼지 AI, 드롭 아이템) 갱신
            world_events = world.update(dt, player)
            pickup_sound_played = False
            for evt_type, evt_msg in world_events:
                if evt_type == "BOAR_ATTACK":
                    sounds.play("hurt")
                    notifications.add(evt_msg, color=(255, 60, 60), duration=3.0)
                elif evt_type == "ITEM_PICKUP" and not pickup_sound_played:
                    sounds.play("pickup")
                    pickup_sound_played = True

            # 3. 플레이어 이동 및 생존 수치(허기, 체온, 체력) 갱신
            can_move = not crafting_ui.is_open and not player.survival.is_dead and not world.time_system.tsunami_arrived
            survival_alerts = player.update(dt, world, can_move=can_move)
            for alert_type, alert_msg in survival_alerts:
                if alert_type == "AXE_HIT":
                    sounds.play("chop")
                    continue
                if alert_type == "CHOP" and alert_msg.startswith("나무를 찍었습니다!"):
                    continue
                color = (255, 215, 80) if alert_type == "CHOP" else (255, 90, 80)
                notifications.add(alert_msg, color=color, duration=3.5)

            # 4. 상호작용 가능한 근처 노드 탐색
            nearby_node = world.get_nearby_interactable(player)

            # 채집·벌목·수면·일지·뗏목은 마우스 왼쪽 클릭으로 상호작용
            can_interact = not crafting_ui.is_open and not player.survival.is_dead
            if can_interact and nearby_node and left_click_pressed:
                if isinstance(nearby_node, PlacedJournal):
                    journal_ui.is_open = True
                    notifications.add("탐험가의 일지를 펼쳤습니다. [게임 일시정지, J키로 닫기]", color=(255, 215, 80))
                elif isinstance(nearby_node, PlacedShelter):
                    success, msg = nearby_node.interact(player, world.time_system)
                    msg_color = (100, 240, 140) if success else (255, 170, 80)
                    notifications.add(msg, color=msg_color)
                elif isinstance(nearby_node, RaftSlipway):
                    success, action, msg = nearby_node.interact(player, crafting_ui.selected_item_id)
                    if msg:
                        msg_color = (100, 240, 140) if success else (255, 170, 80)
                        notifications.add(msg, color=msg_color)
                    if success and action == "BOARD_ESCAPE":
                        sounds.play("launch")
                        music.play("departure")
                        escape_cutscene.start()
                    elif success:
                        sounds.play("build")
                else:
                    success, item_id, count, msg = nearby_node.interact(player)
                    if success and count > 0:
                        sounds.play("pickup")
                    if msg and item_id != "chopping" and not msg.startswith("나무를 찍었습니다!") and not (success and count > 0):
                        msg_color = (100, 240, 140) if success else (255, 180, 90)
                        notifications.add(msg, color=msg_color)

            camera.update(player.hitbox, dt)
            sounds.update(dt, player.is_moving)
            notifications.update(dt)
        else:
            nearby_node = None

        # ----------------- 렌더링 -----------------
        # 1) 지형 타일
        world_frame.fill((26, 60, 92))
        world.draw_ground(world_frame, camera)

        # 2) Y-정렬 엔티티 (바위, 나무, 거처, 모닥불, 일지, 멧돼지, 자원 노드, 플레이어)
        world.draw_entities(world_frame, camera, player)

        # 3) 밤 암전 및 시야/조명 효과
        world.draw_lighting_and_darkness(world_frame, camera, player)
        pygame.transform.scale(world_frame, zoomed_world_frame.get_size(), zoomed_world_frame)
        player_anchor_x = int(player.hitbox.centerx - camera.x)
        player_anchor_y = int(player.hitbox.centery - camera.y)
        zoom_offset = (
            round(player_anchor_x * (1 - camera_zoom)),
            round(player_anchor_y * (1 - camera_zoom)),
        )
        screen.blit(zoomed_world_frame, zoom_offset)

        # 4) 상호작용 안내 툴팁
        if nearby_node and not crafting_ui.is_open and not journal_ui.is_open and not pause_menu.is_open and not player.survival.is_dead:
            if isinstance(nearby_node, PlacedShelter):
                prompt = nearby_node.get_prompt(player, world.time_system)
            else:
                prompt = nearby_node.get_prompt(player)
            prompt_key = (id(nearby_node), prompt.split(" (")[0] if "도끼질 벌목" in prompt else prompt)
            if prompt and prompt_key not in seen_interaction_prompts:
                draw_interaction_prompt(screen, prompt)
                seen_interaction_prompts.add(prompt_key)

        # 5) 상단 HUD: 시간 / 생존 수치
        draw_time_hud(screen, world.time_system)
        draw_survival_bars(screen, player)

        # 6) 알림 팝업 및 하단 퀵바
        notifications.draw(screen)

        # 7) [E] 가방 / [TAB] 제작 모달 창
        crafting_ui.draw(screen, player)
        draw_bottom_quickbar(screen, player, crafting_ui)

        # 8) [J] 탐험가의 일지 큰 책 모달 창 (시간 정지 상태)
        journal_ui.draw(screen)

        # 9) 사망 또는 해일 도달 오버레이
        draw_game_over_or_tsunami(screen, player, world.time_system)

        # 10) 폰트 상태 경고 배너
        draw_font_warning_if_needed(screen)

        # 11) ESC 일시 정지 메뉴
        pause_menu.draw(screen)

        # 12) 표류 직후의 오프닝 대화
        opening_sequence.draw(screen)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


asyncio.run(main())

'''
해일 전 3일 (3 Days Before Tsunami)
필드 자원 노드 및 채집 상호작용 모듈
'''

import math
import random
from typing import Optional
import pygame
from image_assets import get_item_surface, scale_pixel_art
from items import get_item


class DroppedItem:
    '''바닥에 떨어져 있어 플레이어가 지나가면(접촉 시) 자동으로 인벤토리에 들어오는 아이템'''

    def __init__(self, x: float, y: float, item_id: str, count: int = 1):
        self.x = float(x)
        self.y = float(y)
        self.item_id = item_id
        self.count = count
        self.is_active = True

        # 바닥 아이템은 원본보다 작게 2배 정수 스케일로 표시
        self.scale = 2
        raw_surf = get_item_surface(item_id, centered_16x16=item_id != "wood_log")
        self.width = raw_surf.get_width() * self.scale
        self.height = raw_surf.get_height() * self.scale
        self.surface = scale_pixel_art(raw_surf, self.scale)

        # 픽업 판정 반경 및 부유 애니메이션
        self.pickup_radius = 36.0
        self.anim_timer = random.uniform(0.0, 6.28)

    @property
    def hitbox(self) -> pygame.Rect:
        return pygame.Rect(int(self.x + 4), int(self.y + 6), self.width - 8, self.height - 10)

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return int(self.y + self.height)

    def check_pickup(self, player) -> bool:
        if not self.is_active:
            return False
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        if player_center.distance_to(self.center) <= self.pickup_radius or player.hitbox.colliderect(self.hitbox):
            self.is_active = False
            player.inventory.add_item(self.item_id, self.count)
            return True
        return False

    def update(self, dt: float):
        self.anim_timer += dt * 3.5

    def draw(self, target_surface: pygame.Surface, camera):
        if not self.is_active:
            return
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 바닥 그림자
        shadow_rect = pygame.Rect(screen_x + 4, screen_y + self.height - 6, self.width - 8, 8)
        pygame.draw.ellipse(target_surface, (20, 25, 20, 90), shadow_rect)

        # 살짝 위아래로 부유하는 애니메이션
        bob_offset = int(math.sin(self.anim_timer) * 2)
        target_surface.blit(self.surface, (screen_x, screen_y + bob_offset))


class ResourceNode:
    '''필드에 스폰되어 플레이어가 마우스 좌클릭으로 채집할 수 있는 노드 기본 클래스'''

    def __init__(self, x: int, y: int, width: int, height: int, name: str, item_id: str):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.name = name
        self.item_id = item_id
        self.is_active = True
        self.surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # 상호작용 가능 반경 (플레이어와 중심 간 거리 판정)
        self.interaction_radius = 42

    @property
    def is_depleted(self) -> bool:
        return not self.is_active

    def respawn(self):
        self.is_active = True

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.y + self.height

    def can_interact(self, player) -> bool:
        '''플레이어와의 거리가 상호작용 반경 이내인지 확인'''
        if not self.is_active:
            return False
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        '''플레이어가 가까이 다가왔을 때 표시할 안내 텍스트 (마우스 좌클릭)'''
        item_data = get_item(self.item_id)
        return f"[좌클릭] {item_data['name']} 줍기"

    def interact(self, player) -> tuple:
        '''
        마우스 왼쪽 클릭 시 호출
        반환: (성공여부: bool, 획득한아이템ID: str, 수량: int, 메시지: str)
        '''
        if not self.is_active:
            return False, "", 0, ""

        self.is_active = False
        item_data = get_item(self.item_id)
        player.inventory.add_item(self.item_id, 1)
        return True, self.item_id, 1, f"+1 {item_data['name']} 획득"

    def draw(self, target_surface: pygame.Surface, camera):
        if not self.is_active:
            return
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class BranchNode(ResourceNode):
    '''바닥에 떨어진 나뭇가지 자원 노드 (원본 16x16의 3배 = 48x48)'''

    def __init__(self, x: int, y: int, flip_x: bool = False):
        super().__init__(x, y, 48, 48, "나뭇가지", "branch")
        self.flip_x = flip_x
        self._build_surface()

    def _build_surface(self):
        surface = scale_pixel_art(get_item_surface("branch"), 3)
        self.surface = pygame.transform.flip(surface, True, False) if self.flip_x else surface


class StoneNode(ResourceNode):
    '''바닥이나 해변에 흩어져 있는 작은 돌멩이 자원 노드 (원본 16x16의 3배 = 48x48)'''

    def __init__(self, x: int, y: int, sprite_key: Optional[str] = None, flip_x: bool = False):
        super().__init__(x, y, 48, 48, "돌", "stone")
        self.sprite_key = sprite_key
        self.flip_x = flip_x
        self._build_surface()

    def _build_surface(self):
        if self.sprite_key is not None:
            key = self.sprite_key
        else:
            variant = (self.x // 48 + self.y // 48) % 3
            key = "stone" if variant == 0 else ("stone_2" if variant == 1 else "stone_3")
        surface = scale_pixel_art(get_item_surface(key), 3)
        self.surface = pygame.transform.flip(surface, True, False) if self.flip_x else surface


class FiberNode(ResourceNode):
    '''채집 가능한 야생 식물 섬유 덤불 (원본 16x16의 3배 = 48x48)'''

    def __init__(self, x: int, y: int, sprite_key: Optional[str] = None, flip_x: bool = False):
        super().__init__(x, y, 48, 48, "풀 1번", "plant_fiber")
        self.sprite_key = sprite_key
        self.flip_x = flip_x
        self._build_surface()

    def _build_surface(self):
        if self.sprite_key is not None:
            key = self.sprite_key
        else:
            variant = (self.x // 48 + self.y // 48) % 2
            key = "plant_fiber" if variant == 0 else "plant_fiber_alt"
        surface = scale_pixel_art(get_item_surface(key), 3)
        self.surface = pygame.transform.flip(surface, True, False) if self.flip_x else surface

    def get_prompt(self, player) -> str:
        return "[좌클릭] 풀 1번 채집"


class BerryBushNode(ResourceNode):
    '''붉은 야생 베리가 열린 덤불 노드 (원본 16x16의 3배 = 48x48)'''

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 48, 48, "베리", "berry")
        self.has_berries = True
        self._build_surface()

    def _build_surface(self):
        key = "berry_bush" if self.has_berries else "berry_bush_empty"
        self.surface = scale_pixel_art(get_item_surface(key), 3)

    @property
    def is_depleted(self) -> bool:
        return not self.has_berries

    def respawn(self):
        self.has_berries = True
        self._build_surface()

    def get_prompt(self, player) -> str:
        if self.has_berries:
            return "[좌클릭] 베리 채집"
        return "열매가 없는 덤불"

    def interact(self, player) -> tuple:
        if not self.has_berries:
            return False, "", 0, "이미 채집한 덤불입니다."

        self.has_berries = False
        self._build_surface()  # 열매가 사라진 덤불로 다시 그리기
        yield_count = 1
        player.inventory.add_item("berry", yield_count)
        return True, "berry", yield_count, f"+{yield_count} 베리 채집!"


class InteractableTree(ResourceNode):
    '''
    벌목 및 흔들기가 가능한 야자수 노드 (고체 충돌 히트박스 포함)
    - 원본 30x41 픽셀의 3배 정수 스케일 (90x123)로 비율 정확히 보존
    - 돌도끼 소지 시: 3회 도끼질 클릭 후 나무 원목 3개 바닥 드롭!
    - 코코넛이 열린 나무는 벌목할 때만 코코넛 획득
    '''

    def __init__(self, x: int, y: int, has_coconuts: Optional[bool] = None):
        super().__init__(x, y, 90, 123, "야자수", "wood_log")
        self.interaction_radius = 65
        # 나무 밑동 고체 충돌 히트박스
        self.hitbox = pygame.Rect(x + 36, y + 96, 18, 18)
        self.is_chopped = False
        self.has_coconuts = random.choice((True, False)) if has_coconuts is None else has_coconuts
        self.shake_timer = 0.0
        # 3회 도끼질 후 벌목 완료
        self.max_hits = 3
        self.current_hits = 0
        self._build_surface()

    def _build_surface(self):
        if self.is_chopped:
            self.surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            # 아이템 시트의 그루터기(stump, 16x13)를 3배 스케일(48x39)하여 밑동에 배치
            stump = scale_pixel_art(get_item_surface("stump", centered_16x16=False), 3)
            self.surface.blit(stump, ((self.width - stump.get_width()) // 2, self.height - stump.get_height() - 6))
            return

        key = "palm_tree_coconut" if self.has_coconuts else "palm_tree"
        self.surface = scale_pixel_art(get_item_surface(key, centered_16x16=False), 3)

    def get_prompt(self, player) -> str:
        if self.is_chopped:
            return "베어진 나무 그루터기"

        # 플레이어가 돌도끼를 들고 있는지 확인
        if player.inventory.has_tool("stone_axe"):
            return f"[좌클릭] 도끼질 벌목 ({self.current_hits}/{self.max_hits})"
        else:
            return "[좌클릭] 나무 흔들기 (나뭇가지 획득, 벌목엔 돌도끼 필요)"

    def interact(self, player) -> tuple:
        if self.is_chopped:
            return False, "", 0, "이미 베어진 나무 그루터기입니다."

        # 1. 돌도끼를 소지하고 있는 경우 -> 도끼질 애니메이션 시작!
        if player.inventory.has_tool("stone_axe"):
            if getattr(player, "is_chopping", False):
                return False, "", 0, ""
            player.start_chopping(self)
            return True, "chopping", 0, f"도끼질 중... ({self.current_hits + 1}/{self.max_hits})"

        # 2. 돌도끼가 없는 경우 -> 나무 흔들기
        roll = random.random()
        if roll < 0.65:
            player.inventory.add_item("branch", 1)
            return True, "branch", 1, "나무를 흔들자 +1 나뭇가지가 떨어졌습니다!"
        else:
            return False, "", 0, "나무가 흔들렸지만 아무것도 떨어지지 않았습니다. (원목 벌목엔 돌도끼 필요)"

    def update(self, dt: float):
        if self.shake_timer > 0:
            self.shake_timer -= dt

    def draw(self, target_surface: pygame.Surface, camera):
        if not self.is_active:
            return
        # 타격 시 약간 흔들리는 효과
        shake_offset = int(math.sin(self.shake_timer * 40) * 3) if self.shake_timer > 0 else 0
        screen_x = int(self.x - camera.x) + shake_offset
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))

    def finish_chopping(self, player, world) -> str:
        '''도끼질 1회 완료 시 진행도를 갱신하고, 3회째에 나무와 아이템을 드롭'''
        if self.is_chopped:
            return ""

        self.current_hits += 1
        self.shake_timer = 0.2

        # 아직 3회 미만이면 타격 진행 상황을 알리고 나무를 유지
        if self.current_hits < self.max_hits:
            return f"나무를 찍었습니다! ({self.current_hits}/{self.max_hits})"

        # 3회 완료 시 완전히 벌목!
        self.is_chopped = True
        self._build_surface()

        # 나무 밑동 주변 좌표
        base_x = self.x + self.width // 2 - 16
        base_y = self.y + self.height - 24

        # 1. 바닥에 원목을 낱개로 드롭하고, 3개 드롭은 더 드물게 한다.
        wood_count = random.choices((1, 2, 3), weights=(4, 4, 1), k=1)[0]
        drop_offsets = [
            (-24, 8),  # 좌측 바닥
            (0, 18),   # 중앙 앞 바닥
            (24, 8),   # 우측 바닥
        ]
        for ox, oy in random.sample(drop_offsets, wood_count):
            world.add_dropped_item(DroppedItem(base_x + ox, base_y + oy, "wood_log", 1))

        # 코코넛 나무였다면 코코넛도 1개 바닥에 드롭
        if self.has_coconuts:
            world.add_dropped_item(DroppedItem(base_x, base_y + 30, "coconut", 1))

        # 나뭇가지도 바닥에 1개 드롭
        world.add_dropped_item(DroppedItem(base_x - 12, base_y - 8, "branch", 1))
        return f"벌목 완료! 나무 원목 {wood_count}개가 떨어졌습니다."

"""
해일 전 5일 (5 Days Before Tsunami)
필드 자원 노드 및 채집 상호작용 모듈
"""

import random
import pygame
from settings import (
    COLOR_SHADOW,
    COLOR_TREE_TRUNK,
    COLOR_TREE_LEAVES,
    COLOR_TREE_LIGHT,
    COLOR_ROCK,
    COLOR_ROCK_LIGHT,
    COLOR_ROCK_DARK,
)
from items import get_item


class ResourceNode:
    """필드에 스폰되어 플레이어가 [E] 키로 상호작용하여 채집할 수 있는 노드 기본 클래스"""

    def __init__(self, x: int, y: int, width: int, height: int, name: str, item_id: str):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.name = name
        self.item_id = item_id
        self.is_active = True
        self.surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # 상호작용 가능 반경 (플레이어와 중심 간 거리 판정)
        self.interaction_radius = 42

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.y + self.height

    def can_interact(self, player) -> bool:
        """플레이어와의 거리가 상호작용 반경 이내인지 확인"""
        if not self.is_active:
            return False
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        """플레이어가 가까이 다가왔을 때 표시할 안내 텍스트"""
        item_data = get_item(self.item_id)
        return f"[E] {item_data['name']} 줍기"

    def interact(self, player) -> tuple:
        """
        [E] 키 상호작용 시 호출
        반환: (성공여부: bool, 획득한아이템ID: str, 수량: int, 메시지: str)
        """
        if not self.is_active:
            return False, "", 0, ""

        self.is_active = False
        item_data = get_item(self.item_id)
        player.inventory.add_item(self.item_id, 1)
        return True, self.item_id, 1, f"+1 {item_data['name']} 획득"

    def draw(self, target_surface: pygame.Surface, camera):
        if not self.is_active:
            return
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class BranchNode(ResourceNode):
    """바닥에 떨어진 나뭇가지 자원 노드"""

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 24, 18, "나뭇가지", "branch")
        self._build_surface()

    def _build_surface(self):
        # 작은 그림자
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, (2, 10, 20, 6))
        # 꺾인 나뭇가지
        pygame.draw.line(self.surface, (80, 50, 30), (3, 14), (18, 5), 3)
        pygame.draw.line(self.surface, (140, 95, 60), (3, 14), (18, 5), 2)
        # 작은 잔가지
        pygame.draw.line(self.surface, (140, 95, 60), (10, 10), (15, 14), 2)


class StoneNode(ResourceNode):
    """바닥이나 해변에 흩어져 있는 작은 돌멩이 자원 노드"""

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 20, 16, "돌", "stone")
        self._build_surface()

    def _build_surface(self):
        # 그림자
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, (1, 8, 18, 7))
        # 다면체 돌 픽셀
        pts = [(3, 10), (7, 4), (15, 5), (17, 11), (9, 13)]
        pygame.draw.polygon(self.surface, COLOR_ROCK, pts)
        pygame.draw.polygon(self.surface, COLOR_ROCK_LIGHT, [(7, 5), (13, 6), (10, 10)])
        pygame.draw.polygon(self.surface, COLOR_ROCK_DARK, pts, 1)


class FiberNode(ResourceNode):
    """채집 가능한 야생 식물 섬유 덤불"""

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 26, 28, "식물 섬유", "plant_fiber")
        self._build_surface()

    def _build_surface(self):
        # 바닥 그림자
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, (3, 20, 20, 7))
        # 솟아오른 섬유질 풀잎 가닥들
        pygame.draw.line(self.surface, (60, 130, 50), (6, 24), (4, 6), 3)
        pygame.draw.line(self.surface, (90, 180, 70), (6, 24), (4, 6), 2)

        pygame.draw.line(self.surface, (50, 120, 45), (12, 24), (13, 4), 3)
        pygame.draw.line(self.surface, (110, 200, 85), (12, 24), (13, 4), 2)

        pygame.draw.line(self.surface, (70, 140, 55), (18, 24), (22, 8), 3)
        pygame.draw.line(self.surface, (120, 210, 95), (18, 24), (22, 8), 2)

    def get_prompt(self, player) -> str:
        return "[E] 식물 섬유 채집"


class BerryBushNode(ResourceNode):
    """붉은 야생 베리가 열린 덤불 노드"""

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 34, 30, "베리", "berry")
        self.has_berries = True
        self._build_surface()

    def _build_surface(self):
        self.surface.fill((0, 0, 0, 0))
        # 그림자
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, (2, 20, 30, 9))
        # 덤불 잎 군집
        pygame.draw.circle(self.surface, (45, 105, 50), (12, 16), 10)
        pygame.draw.circle(self.surface, (55, 125, 60), (22, 16), 10)
        pygame.draw.circle(self.surface, (70, 150, 75), (17, 12), 9)

        # 붉은 베리 열매
        if self.has_berries:
            berry_coords = [(11, 14), (20, 13), (16, 18), (24, 19), (13, 21)]
            for bx, by in berry_coords:
                pygame.draw.circle(self.surface, (150, 20, 30), (bx, by), 3)
                pygame.draw.circle(self.surface, (235, 60, 70), (bx, by), 2)
                self.surface.set_at((bx, by), (255, 180, 190))

    def get_prompt(self, player) -> str:
        if self.has_berries:
            return "[E] 베리 채집"
        return "열매가 없는 덤불"

    def interact(self, player) -> tuple:
        if not self.has_berries:
            return False, "", 0, "이미 채집한 덤불입니다."

        self.has_berries = False
        self._build_surface()  # 열매가 사라진 덤불로 다시 그리기
        yield_count = random.randint(1, 2)
        player.inventory.add_item("berry", yield_count)
        return True, "berry", yield_count, f"+{yield_count} 베리 채집!"


class CoconutNode(ResourceNode):
    """해변에 떨어진 코코넛 열매 노드"""

    def __init__(self, x: int, y: int):
        super().__init__(x, y, 22, 20, "코코넛", "coconut")
        self._build_surface()

    def _build_surface(self):
        # 그림자
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, (2, 10, 18, 8))
        # 코코넛 갈색 구체
        pygame.draw.circle(self.surface, (90, 55, 30), (11, 10), 8)
        pygame.draw.circle(self.surface, (140, 95, 55), (11, 10), 7)
        # 세 개의 눈 도트
        self.surface.set_at((9, 8), (60, 35, 20))
        self.surface.set_at((13, 8), (60, 35, 20))
        self.surface.set_at((11, 12), (60, 35, 20))

    def get_prompt(self, player) -> str:
        return "[E] 코코넛 줍기"


class InteractableTree(ResourceNode):
    """
    벌목 및 흔들기가 가능한 야자수 노드 (고체 충돌 히트박스 포함)
    - 돌도끼 소지 시: 벌목하여 [나무 원목] 획득!
    - 돌도끼 미소지 시: 나무를 흔들어 [코코넛] 또는 [나뭇가지] 확률 획득, "돌도끼 필요" 안내
    """

    def __init__(self, x: int, y: int):
        # 나무 크기 56x68
        super().__init__(x, y, 56, 68, "야자수", "wood_log")
        self.interaction_radius = 56
        # 밑동 고체 충돌 히트박스
        self.hitbox = pygame.Rect(x + 20, y + 50, 16, 16)
        self.is_chopped = False
        self.shake_cooldown = 0.0
        self._build_surface()

    def _build_surface(self):
        self.surface.fill((0, 0, 0, 0))
        if self.is_chopped:
            # 베어 넘어진 나무 그루터기(밑동)만 표시
            pygame.draw.ellipse(self.surface, COLOR_SHADOW, (14, 52, 28, 12))
            stump_rect = pygame.Rect(20, 48, 16, 14)
            pygame.draw.rect(self.surface, COLOR_TREE_TRUNK, stump_rect)
            pygame.draw.ellipse(self.surface, (160, 120, 80), (20, 46, 16, 6))
            pygame.draw.ellipse(self.surface, (110, 75, 45), (20, 46, 16, 6), 1)
        else:
            # 온전한 나무
            # 1. 밑동 그림자
            pygame.draw.ellipse(self.surface, COLOR_SHADOW, (12, 54, 32, 12))

            # 2. 나무 기둥
            trunk_rect = pygame.Rect(22, 34, 12, 26)
            pygame.draw.rect(self.surface, COLOR_TREE_TRUNK, trunk_rect)
            pygame.draw.rect(self.surface, (80, 52, 32), trunk_rect, 1)

            # 3. 나뭇잎 무더기
            leaf_clusters = [
                ((28, 22), 22, COLOR_TREE_LEAVES),
                ((18, 26), 14, COLOR_TREE_LEAVES),
                ((38, 24), 16, COLOR_TREE_LEAVES),
                ((28, 16), 16, COLOR_TREE_LIGHT),
            ]
            for center, radius, color in leaf_clusters:
                pygame.draw.circle(self.surface, color, center, radius)
                pygame.draw.circle(self.surface, (30, 80, 42), center, radius, 1)

            # 4. 야자수에 매달린 코코넛 2개
            pygame.draw.circle(self.surface, (110, 70, 35), (24, 30), 4)
            pygame.draw.circle(self.surface, (110, 70, 35), (32, 30), 4)

    def get_prompt(self, player) -> str:
        if self.is_chopped:
            return "베어진 나무 그루터기"

        # 플레이어가 돌도끼를 들고 있는지 확인
        if player.inventory.has_tool("stone_axe"):
            return "[E] 나무 벌목 (원목 채취)"
        else:
            return "[E] 나무 흔들기 (원목 채취엔 돌도끼 필요)"

    def interact(self, player) -> tuple:
        if self.is_chopped:
            return False, "", 0, "이미 베어진 나무입니다."

        # 1. 돌도끼를 소지하고 있는 경우 -> 벌목 성공!
        if player.inventory.has_tool("stone_axe"):
            self.is_chopped = True
            self._build_surface()
            # 나무 원목 1~2개 + 나뭇가지 1개 획득
            logs = random.randint(1, 2)
            player.inventory.add_item("wood_log", logs)
            player.inventory.add_item("branch", 1)
            return True, "wood_log", logs, f"벌목 완료! +{logs} 나무 원목, +1 나뭇가지"

        # 2. 돌도끼가 없는 경우 -> 나무 흔들기
        roll = random.random()
        if roll < 0.45:
            # 코코넛 떨어짐!
            player.inventory.add_item("coconut", 1)
            return True, "coconut", 1, "나무를 흔들자 +1 코코넛이 떨어졌습니다!"
        elif roll < 0.80:
            # 나뭇가지 떨어짐!
            player.inventory.add_item("branch", 1)
            return True, "branch", 1, "나무를 흔들자 +1 나뭇가지가 떨어졌습니다!"
        else:
            return False, "", 0, "나무가 흔들렸지만 아무것도 떨어지지 않았습니다. (원목 벌목엔 돌도끼 필요)"

'''
해일 전 3일 (3 Days Before Tsunami)
공통 한글 폰트 관리 모듈 (NanumGothic.ttf)
'''

import sys
from pathlib import Path
import pygame

# 폰트 파일 기본 경로: assets/fonts/font/NanumGothic.ttf
BASE_DIR = Path(__file__).parent
FONT_RELATIVE_PATH = "assets/fonts/font/NanumGothic.ttf"
FONT_PATH = BASE_DIR / FONT_RELATIVE_PATH

# 폰트 캐시: (size, bold) -> pygame.font.Font
_FONT_CACHE = {}
_FONT_LOAD_FAILED = False
_ERROR_MESSAGE = ""
_USING_FALLBACK = False


def get_font_path() -> Path:
    '''한글 폰트 파일 경로 반환'''
    return FONT_PATH


def is_font_available() -> bool:
    '''한글 폰트 파일이 정상적으로 존재하는지 확인'''
    return FONT_PATH.is_file()


def get_font(size: int = 16, bold: bool = False) -> pygame.font.Font:
    '''
    지정된 크기의 한글 폰트(NanumGothic)를 반환하는 공통 함수.
    - 폰트 객체를 캐싱하여 매 프레임 생성 없이 성능을 최적화합니다.
    - 폰트 파일이 없거나 로드 실패 시 콘솔에 명확한 오류 로그를 출력하고 대체 폰트를 반환합니다.
    '''
    global _FONT_LOAD_FAILED, _ERROR_MESSAGE, _USING_FALLBACK

    if not pygame.font.get_init():
        pygame.font.init()

    cache_key = (size, bold)
    if cache_key in _FONT_CACHE:
        return _FONT_CACHE[cache_key]

    font_obj = None

    # 1. assets/fonts/font/NanumGothic.ttf 파일 로드 시도
    if FONT_PATH.is_file():
        try:
            font_obj = pygame.font.Font(str(FONT_PATH), size)
            if bold:
                font_obj.set_bold(True)
        except Exception as e:
            _FONT_LOAD_FAILED = True
            _USING_FALLBACK = True
            _ERROR_MESSAGE = f"폰트 파일 '{FONT_PATH}' 로드 중 예외 발생: {e}"
            print(f"[Font Error] {_ERROR_MESSAGE}", file=sys.stderr)
    else:
        if not _FONT_LOAD_FAILED:
            _FONT_LOAD_FAILED = True
            _USING_FALLBACK = True
            _ERROR_MESSAGE = (
                f"한글 폰트 파일을 찾을 수 없습니다: '{FONT_PATH.resolve()}'. "
                f"assets/fonts/font/NanumGothic.ttf 경로에 폰트 파일이 존재하는지 확인해 주세요."
            )
            print(f"[Font Error] {_ERROR_MESSAGE}", file=sys.stderr)

    # 2. 로드 실패 시 시스템 한글 폰트 폴백 시도
    if font_obj is None:
        _USING_FALLBACK = True
        try:
            fallback_names = [
                "nanumgothic",
                "applegothic",
                "malgungothic",
                "notosanscjk",
                "notosanscjkkr",
                "gulim",
                "sans-serif",
            ]
            font_obj = pygame.font.SysFont(fallback_names, size, bold=bold)
        except Exception as sys_e:
            print(f"[Font Warning] 시스템 폰트 폴백 시도 실패: {sys_e}", file=sys.stderr)

    # 3. 최후의 수단: 기본 폰트
    if font_obj is None:
        try:
            font_obj = pygame.font.Font(None, size)
            if bold:
                font_obj.set_bold(True)
        except Exception:
            font_obj = pygame.font.SysFont(None, size)

    _FONT_CACHE[cache_key] = font_obj
    return font_obj


def get_font_load_status() -> tuple:
    '''폰트 로드 상태 반환 (정상여부: bool, 상태메시지: str)'''
    if not is_font_available():
        return False, f"폰트 파일 누락: '{FONT_PATH.resolve()}'"
    if _FONT_LOAD_FAILED:
        return False, _ERROR_MESSAGE
    return True, "정상 로드됨 (assets/fonts/font/NanumGothic.ttf)"


def draw_font_warning_if_needed(surface: pygame.Surface):
    '''폰트 로드에 문제가 있을 경우 화면 상단에 경고 배너 렌더링'''
    is_ok, msg = get_font_load_status()
    if is_ok and not _USING_FALLBACK:
        return

    # 경고 배너 렌더링
    warn_h = 24
    warn_surf = pygame.Surface((surface.get_width(), warn_h), pygame.SRCALPHA)
    pygame.draw.rect(warn_surf, (180, 40, 40, 220), (0, 0, surface.get_width(), warn_h))

    warn_font = get_font(13, bold=True)
    text = f"[폰트 경고] NanumGothic.ttf 로드 실패로 대체 폰트 사용 중: {msg}"
    txt_surf = warn_font.render(text, True, (255, 255, 255))
    warn_surf.blit(txt_surf, (10, 4))

    surface.blit(warn_surf, (0, 0))

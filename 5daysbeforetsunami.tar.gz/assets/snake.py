'''
해일 전 3일 (3 Days Before Tsunami)
오른쪽 풀숲을 지키는 독사와 독 투사체
'''

import math

import pygame

from fonts import get_font
from settings import (
    COLOR_SHADOW,
    COLOR_SNAKE_BELLY,
    COLOR_SNAKE_BODY,
    COLOR_SNAKE_DARK,
    COLOR_SNAKE_EYE,
    COLOR_SNAKE_VENOM,
    COLOR_SNAKE_VENOM_DARK,
    SNAKE_ATTACK_COOLDOWN,
    SNAKE_ATTACK_RANGE,
    SNAKE_ATTACK_WINDUP,
    SNAKE_VENOM_SPEED,
)


class VenomGlob:
    '''픽셀로 그린 독방울. 포물선처럼 보이지만 판정은 평면 좌표를 따른다.'''

    def __init__(self, origin: pygame.Vector2, target: pygame.Vector2):
        self.x = float(origin.x)
        self.y = float(origin.y)
        direction = target - origin
        self.remaining_distance = direction.length()
        if self.remaining_distance > 0:
            direction /= self.remaining_distance
        else:
            direction = pygame.Vector2(1, 0)
        self.direction = direction
        self.age = 0.0
        self.travel_time = max(self.remaining_distance / SNAKE_VENOM_SPEED, 0.1)
        self.is_active = True
        self.width = 16
        self.height = 16

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(round(self.x - 8), round(self.y - 8), self.width, self.height)

    @property
    def render_rect(self) -> pygame.Rect:
        return pygame.Rect(round(self.x - 10), round(self.y - 26), 20, 36)

    @property
    def render_y(self) -> int:
        return round(self.y + 8)

    def update(self, dt: float, player) -> bool:
        if not self.is_active:
            return False

        distance = min(self.remaining_distance, SNAKE_VENOM_SPEED * dt)
        self.x += self.direction.x * distance
        self.y += self.direction.y * distance
        self.remaining_distance -= distance
        self.age += dt

        if self.rect.colliderect(player.hitbox):
            self.is_active = False
            return True
        if self.remaining_distance <= 0:
            self.is_active = False
        return False

    def draw(self, target_surface: pygame.Surface, camera):
        if not self.is_active:
            return

        screen_x = int(self.x - camera.x)
        ground_y = int(self.y - camera.y)
        arc = int(math.sin(min(1.0, self.age / self.travel_time) * math.pi) * 13)
        screen_y = ground_y - arc

        pygame.draw.ellipse(
            target_surface,
            (24, 47, 28, 90),
            pygame.Rect(screen_x - 8, ground_y + 3, 16, 6),
        )
        for trail_step in (1, 2):
            trail_x = screen_x - round(self.direction.x * trail_step * 7)
            trail_y = screen_y - round(self.direction.y * trail_step * 7)
            pygame.draw.rect(
                target_surface,
                COLOR_SNAKE_VENOM_DARK,
                pygame.Rect(trail_x - 2, trail_y - 2, 4, 4),
            )
        pygame.draw.rect(
            target_surface,
            COLOR_SNAKE_VENOM_DARK,
            pygame.Rect(screen_x - 5, screen_y - 5, 10, 10),
        )
        pygame.draw.rect(
            target_surface,
            COLOR_SNAKE_VENOM,
            pygame.Rect(screen_x - 3, screen_y - 4, 6, 7),
        )
        pygame.draw.rect(
            target_surface,
            (246, 224, 255),
            pygame.Rect(screen_x - 2, screen_y - 3, 2, 2),
        )


class VenomSnake:
    '''풀숲을 맴돌며 독방울을 뱉는 포획 불가 야생 뱀.'''

    width = 96
    height = 44

    def __init__(self, center_x: float, center_y: float):
        self.home_x = float(center_x)
        self.home_y = float(center_y)
        self.x = self.home_x - self.width / 2
        self.y = self.home_y - self.height / 2
        self.state = "IDLE"
        self.state_timer = 0.0
        self.cooldown = 0.0
        self.animation_timer = 0.0
        self.aim_direction = pygame.Vector2(1, 0)
        self.facing = "right"
        self.spit_flash_timer = 0.0
        self.spit_origin = pygame.Vector2(center_x, center_y)
        self.projectiles: list[VenomGlob] = []
        self._create_surfaces()

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width / 2, self.y + self.height / 2)

    @property
    def rect(self) -> pygame.Rect:
        width, height = (
            (self.height, self.width)
            if self.facing in ("up", "down")
            else (self.width, self.height)
        )
        return pygame.Rect(
            round(self.center.x - width / 2),
            round(self.center.y - height / 2),
            width,
            height,
        )

    @property
    def render_y(self) -> int:
        return self.rect.bottom - 3

    def _create_surfaces(self):
        self.idle_surfaces = []
        for frame in range(8):
            base = self._make_base_surface(frame, coiled=False)
            self.idle_surfaces.append(self._orient_surfaces(base))

        self.coiled_surfaces = []
        for frame in range(8):
            base = self._make_base_surface(frame, coiled=True)
            self.coiled_surfaces.append(self._orient_surfaces(base))

        self.head_surfaces = self._create_head_surfaces()
        shadow = pygame.Surface((86, 12), pygame.SRCALPHA)
        pygame.draw.ellipse(shadow, COLOR_SHADOW, (0, 0, 86, 12))
        vertical_shadow = pygame.transform.rotate(shadow, 90)
        self.shadow_surfaces = {
            "right": shadow,
            "left": shadow,
            "up": vertical_shadow,
            "down": vertical_shadow,
        }

    def _orient_surfaces(self, base: pygame.Surface) -> dict[str, pygame.Surface]:
        right = pygame.transform.smoothscale(base, (self.width, self.height))
        return {
            "right": right,
            "left": pygame.transform.flip(right, True, False),
            "up": pygame.transform.rotate(right, 90),
            "down": pygame.transform.rotate(right, 270),
        }

    @staticmethod
    def _create_head_surfaces() -> dict[str, pygame.Surface]:
        scale = 4
        profile = pygame.Surface((28 * scale, 22 * scale), pygame.SRCALPHA)
        profile_outline = [
            (1, 11), (4, 6), (9, 3), (16, 4), (21, 8),
            (27, 9), (26, 13), (22, 16), (16, 18), (8, 18),
            (3, 16),
        ]
        scaled_outline = [(x * scale, y * scale) for x, y in profile_outline]
        pygame.draw.polygon(profile, COLOR_SNAKE_DARK, scaled_outline)
        pygame.draw.polygon(
            profile,
            COLOR_SNAKE_BODY,
            [(x * scale, y * scale) for x, y in (
                (2, 11), (5, 6), (10, 4), (16, 5), (21, 9),
                (25, 10), (25, 12), (21, 15), (16, 17), (8, 17),
                (4, 15),
            )],
        )
        pygame.draw.circle(profile, (255, 251, 243), (15 * scale, 7 * scale), 3 * scale)
        pygame.draw.circle(profile, COLOR_SNAKE_EYE, (15 * scale, 7 * scale), 2 * scale)
        pygame.draw.circle(profile, (68, 42, 49), (16 * scale, 7 * scale), scale)
        pygame.draw.circle(profile, COLOR_SNAKE_DARK, (24 * scale, 10 * scale), scale)
        pygame.draw.lines(
            profile,
            COLOR_SNAKE_DARK,
            False,
            [(15 * scale, 14 * scale), (20 * scale, 15 * scale), (24 * scale, 14 * scale)],
            scale,
        )
        pygame.draw.lines(
            profile,
            COLOR_SNAKE_EYE,
            False,
            [(25 * scale, 13 * scale), (27 * scale, 14 * scale), (27 * scale, 12 * scale)],
            scale,
        )
        profile = pygame.transform.smoothscale(profile, (28, 22))

        front = pygame.Surface((26 * scale, 28 * scale), pygame.SRCALPHA)
        front_outline = [
            (5, 2), (21, 2), (24, 6), (25, 12), (22, 18),
            (17, 24), (13, 27), (9, 24), (4, 18), (1, 12),
            (2, 6),
        ]
        pygame.draw.polygon(
            front,
            COLOR_SNAKE_DARK,
            [(x * scale, y * scale) for x, y in front_outline],
        )
        pygame.draw.polygon(
            front,
            COLOR_SNAKE_BODY,
            [(x * scale, y * scale) for x, y in (
                (6, 3), (20, 3), (23, 7), (24, 12), (21, 18),
                (17, 23), (13, 26), (9, 23), (5, 18), (2, 12),
                (3, 7),
            )],
        )
        for eye_x in (7, 19):
            pygame.draw.circle(front, (255, 251, 243), (eye_x * scale, 11 * scale), 2 * scale)
            pygame.draw.circle(front, COLOR_SNAKE_EYE, (eye_x * scale, 11 * scale), scale)
            pygame.draw.circle(front, (68, 42, 49), (eye_x * scale, 12 * scale), scale // 2)
        pygame.draw.circle(front, COLOR_SNAKE_DARK, (13 * scale, 19 * scale), scale)
        pygame.draw.lines(
            front,
            COLOR_SNAKE_DARK,
            False,
            [(9 * scale, 20 * scale), (13 * scale, 22 * scale), (17 * scale, 20 * scale)],
            scale,
        )
        pygame.draw.lines(
            front,
            COLOR_SNAKE_EYE,
            False,
            [(13 * scale, 22 * scale), (13 * scale, 26 * scale), (10 * scale, 28 * scale)],
            scale,
        )
        pygame.draw.line(
            front,
            COLOR_SNAKE_EYE,
            (13 * scale, 26 * scale),
            (16 * scale, 28 * scale),
            scale,
        )
        front = pygame.transform.smoothscale(front, (26, 28))
        return {
            "right": profile,
            "left": pygame.transform.flip(profile, True, False),
            "up": pygame.transform.flip(front, False, True),
            "down": front,
        }

    @staticmethod
    def _make_base_surface(frame: int, coiled: bool) -> pygame.Surface:
        scale = 4
        surface = pygame.Surface((96 * scale, 44 * scale), pygame.SRCALPHA)
        phase = frame * math.tau / 8
        if coiled:
            curves = (
                ((5, 27), (18, 26), (24, 21), (37, 21)),
                ((37, 21), (50, 21), (53, 28), (65, 28)),
                ((65, 28), (72, 28), (76, 23), (78, 23)),
            )
        else:
            curves = (
                ((5, 27), (18, 26), (23, 20), (37, 20)),
                ((37, 20), (50, 20), (53, 28), (65, 28)),
                ((65, 28), (72, 29), (76, 24), (78, 23)),
            )

        points = []
        for curve_index, curve in enumerate(curves):
            steps = range(21) if curve_index == 0 else range(1, 21)
            p0, p1, p2, p3 = curve
            for step in steps:
                t = step / 20
                inverse = 1 - t
                x = (
                    inverse**3 * p0[0]
                    + 3 * inverse**2 * t * p1[0]
                    + 3 * inverse * t**2 * p2[0]
                    + t**3 * p3[0]
                )
                y = (
                    inverse**3 * p0[1]
                    + 3 * inverse**2 * t * p1[1]
                    + 3 * inverse * t**2 * p2[1]
                    + t**3 * p3[1]
                )
                points.append(pygame.Vector2(x * scale, y * scale))

        for index, point in enumerate(points):
            progress = index / (len(points) - 1)
            wave = math.sin(phase - progress * math.tau * 1.25)
            wave *= 1.8 * (0.25 + 0.75 * (1.0 - progress))
            point.y += wave * scale

        edge_left = []
        edge_right = []
        body_left = []
        body_right = []
        highlights = []
        for index, point in enumerate(points):
            previous = points[max(0, index - 1)]
            following = points[min(len(points) - 1, index + 1)]
            tangent = following - previous
            if tangent.length_squared() > 0:
                tangent.normalize_ip()
            progress = index / (len(points) - 1)
            normal = pygame.Vector2(-tangent.y, tangent.x)
            tail_taper = 0.42 + 0.58 * min(1.0, progress / 0.12)
            neck_taper = 0.75 + 0.25 * min(1.0, (1.0 - progress) / 0.14)
            radius = 4.1 * tail_taper * neck_taper * scale
            edge_radius = radius + 1.0 * scale
            edge_left.append(point + normal * edge_radius)
            edge_right.append(point - normal * edge_radius)
            body_left.append(point + normal * radius)
            body_right.append(point - normal * radius)
            highlights.append(point + normal * radius * 0.48)

        outline = edge_left + list(reversed(edge_right))
        body = body_left + list(reversed(body_right))
        pygame.draw.polygon(surface, COLOR_SNAKE_DARK, outline)
        pygame.draw.polygon(surface, COLOR_SNAKE_BODY, body)
        pygame.draw.lines(
            surface,
            COLOR_SNAKE_BELLY,
            False,
            [(round(point.x), round(point.y)) for point in highlights],
            scale,
        )
        return surface

    def _set_facing(self, direction: pygame.Vector2):
        if abs(direction.x) >= abs(direction.y):
            self.facing = "right" if direction.x >= 0 else "left"
        else:
            self.facing = "down" if direction.y >= 0 else "up"

    def update(self, dt: float, player) -> tuple[bool, str]:
        if player.survival.is_dead:
            return False, ""

        self.animation_timer += dt
        self.cooldown = max(0.0, self.cooldown - dt)
        self.spit_flash_timer = max(0.0, self.spit_flash_timer - dt)

        player_center = pygame.Vector2(player.hitbox.center)
        to_player = player_center - self.center
        distance = to_player.length()
        poisoned = False

        if self.state == "IDLE":
            drift = math.sin(self.animation_timer * 0.8)
            self.x = self.home_x - self.width / 2 + drift * 2.5
            self.y = self.home_y - self.height / 2 + math.sin(
                self.animation_timer * 0.8 - 0.7
            )
            if distance <= SNAKE_ATTACK_RANGE and self.cooldown <= 0:
                self.state = "WINDUP"
                self.state_timer = SNAKE_ATTACK_WINDUP

        if self.state == "WINDUP":
            if distance > SNAKE_ATTACK_RANGE * 1.25:
                self.state = "IDLE"
                self.cooldown = 0.6
            else:
                if distance > 0:
                    self.aim_direction = to_player.normalize()
                self._set_facing(self.aim_direction)
                self.state_timer -= dt
                if self.state_timer <= 0:
                    origin = self.center + self.aim_direction * 15
                    self.projectiles.append(VenomGlob(origin, player_center))
                    self.spit_origin = origin
                    self.spit_flash_timer = 0.2
                    self.state = "RECOVERY"
                    self.state_timer = 0.35
                    self.cooldown = SNAKE_ATTACK_COOLDOWN

        elif self.state == "RECOVERY":
            self.state_timer -= dt
            if self.state_timer <= 0:
                self.state = "IDLE"

        for projectile in self.projectiles:
            if projectile.update(dt, player):
                poisoned = True
        self.projectiles = [projectile for projectile in self.projectiles if projectile.is_active]

        if poisoned:
            return True, "독방울에 맞았습니다! 10초 동안 초당 체력 3이 감소합니다."
        return False, ""

    def draw(self, target_surface: pygame.Surface, camera):
        center = self.center
        screen_center = (round(center.x - camera.x), round(center.y - camera.y))
        shadow = self.shadow_surfaces[self.facing]
        shadow_rect = shadow.get_rect(center=(screen_center[0], screen_center[1] + 4))
        target_surface.blit(shadow, shadow_rect)

        if self.state == "WINDUP":
            frame = int((SNAKE_ATTACK_WINDUP - max(0.0, self.state_timer)) * 8)
            frame %= len(self.coiled_surfaces)
            sprite = self.coiled_surfaces[frame][self.facing]
        else:
            frame = int(self.animation_timer * 8) % len(self.idle_surfaces)
            sprite = self.idle_surfaces[frame][self.facing]
        target_surface.blit(sprite, sprite.get_rect(center=screen_center))

        head_offsets = {
            "right": (33, 1),
            "left": (-33, 1),
            "up": (0, -33),
            "down": (0, 33),
        }
        head_offset = head_offsets[self.facing]
        head_center = (
            screen_center[0] + head_offset[0],
            screen_center[1] + head_offset[1],
        )
        head = self.head_surfaces[self.facing]
        target_surface.blit(head, head.get_rect(center=head_center))

        if self.state == "WINDUP":
            alert_font = get_font(16, bold=True)
            alert_surf = alert_font.render("!", True, (255, 40, 40))
            alert_top = head_center[1] - head.get_height() // 2 - 18
            bg_rect = pygame.Rect(head_center[0] - 8, alert_top, 16, 16)
            pygame.draw.rect(target_surface, (20, 20, 20, 220), bg_rect, border_radius=3)
            pygame.draw.rect(target_surface, (255, 60, 60), bg_rect, 1, border_radius=3)
            target_surface.blit(alert_surf, (head_center[0] - 4, alert_top - 2))

        if self.spit_flash_timer > 0:
            flash_x = int(self.spit_origin.x - camera.x)
            flash_y = int(self.spit_origin.y - camera.y)
            for dx, dy in ((-5, -2), (0, -6), (5, -2)):
                pygame.draw.rect(
                    target_surface,
                    COLOR_SNAKE_VENOM,
                    pygame.Rect(flash_x + dx, flash_y + dy, 3, 3),
                )

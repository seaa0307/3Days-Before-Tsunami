"""
해일 전 5일 (5 Days Before Tsunami)
탐험가의 일지 (Explorer's Journal) 월드 오브젝트 및 책 UI 모듈
"""

import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    COLOR_UI_TEXT,
    COLOR_UI_ACCENT,
    COLOR_SHADOW,
)
from fonts import get_font


class PlacedJournal:
    """게임 시작 지점에 놓여 있는 탐험가의 일지 월드 오브젝트"""

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.width = 36
        self.height = 32
        self.is_active = True
        self.hitbox = pygame.Rect(x + 4, y + 10, 28, 18)
        self.interaction_radius = 50

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def can_interact(self, player) -> bool:
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        return "[E] 탐험가의 일지 펼치기 (J키)"

    def interact(self, player) -> tuple:
        return True, "journal", 1, "탐험가의 일지를 펼쳤습니다. [J키로 다시 열람 가능]"

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 그림자
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 2, screen_y + 18, 32, 10))

        # 2. 나무 받침대 / 그루터기
        pygame.draw.rect(target_surface, (110, 75, 45), (screen_x + 6, screen_y + 14, 24, 12))
        pygame.draw.rect(target_surface, (75, 50, 30), (screen_x + 6, screen_y + 14, 24, 12), 1)

        # 3. 갈색 가죽 표지의 일지 책
        pygame.draw.rect(target_surface, (140, 50, 40), (screen_x + 4, screen_y + 6, 28, 14), border_radius=2)
        pygame.draw.rect(target_surface, (80, 25, 20), (screen_x + 4, screen_y + 6, 28, 14), 1, border_radius=2)

        # 4. 펼쳐진 양장 종이 단면 & 금빛 나침반 문양
        pygame.draw.rect(target_surface, (245, 235, 210), (screen_x + 7, screen_y + 7, 22, 12))
        pygame.draw.line(target_surface, (190, 160, 60), (screen_x + 18, screen_y + 7), (screen_x + 18, screen_y + 19), 2)
        pygame.draw.circle(target_surface, (230, 190, 70), (screen_x + 18, screen_y + 13), 3)


class JournalUI:
    """
    화면 중앙에 큰 책 형태로 표시되는 탐험가의 일지 뷰어
    - 열람 중에는 게임 시간이 정지됨
    - E키(일지 앞) 또는 J키(언제든지)로 토글
    - 내용: 기본 조작, 자원 채집, 도구 제작, 생존 및 수면, 뗏목 제작과 탈출 방법
    """

    def __init__(self):
        self.is_open = False
        self.current_page = 0  # 0: 기본조작&자원채집, 1: 도구제작&생존수면, 2: 뗏목과탈출

        # 책 크기 (화면 중앙 배치)
        self.width = 740
        self.height = 460
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2

        # 닫기 버튼 사각형
        self.close_btn_rect = pygame.Rect(self.x + self.width - 34, self.y + 10, 24, 24)
        self.prev_btn_rect = pygame.Rect(self.x + 28, self.y + self.height - 38, 100, 26)
        self.next_btn_rect = pygame.Rect(self.x + self.width - 128, self.y + self.height - 38, 100, 26)

        # 탭 버튼 사각형 캐시
        self.tab_rects = []

    def toggle(self):
        self.is_open = not self.is_open

    def handle_event(self, event: pygame.event.Event) -> bool:
        """이벤트 처리 (J키 토글, ESC 닫기, 페이지 전환)"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_j:
                self.toggle()
                return True
            elif event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True
            elif self.is_open:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    self.current_page = max(0, self.current_page - 1)
                    return True
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.current_page = min(2, self.current_page + 1)
                    return True

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # 닫기 버튼
            if self.close_btn_rect.collidepoint(mouse_pos):
                self.is_open = False
                return True

            # 이전 페이지 버튼
            if self.prev_btn_rect.collidepoint(mouse_pos):
                self.current_page = max(0, self.current_page - 1)
                return True

            # 다음 페이지 버튼
            if self.next_btn_rect.collidepoint(mouse_pos):
                self.current_page = min(2, self.current_page + 1)
                return True

            # 상단 탭 버튼 클릭
            for idx, r in self.tab_rects:
                if r.collidepoint(mouse_pos):
                    self.current_page = idx
                    return True

        # 일지 창 내부 클릭 시 게임 조작 차단
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            window_rect = pygame.Rect(self.x, self.y, self.width, self.height)
            if window_rect.collidepoint(event.pos):
                return True

        return True

    def draw(self, surface: pygame.Surface):
        if not self.is_open:
            return

        # 1. 배경 어둡게 딤 처리
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((5, 10, 15, 180))
        surface.blit(dim, (0, 0))

        # 2. 책 외피 (고급 양장본 가죽 표지)
        book_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(book_surf, (85, 45, 30), (0, 0, self.width, self.height), border_radius=10)
        pygame.draw.rect(book_surf, (55, 28, 18), (0, 0, self.width, self.height), 3, border_radius=10)

        # 책 중앙 접지선 음영
        mid_x = self.width // 2

        # 3. 양쪽 펼쳐진 양피지 페이지 (크림색 바탕)
        page_margin = 12
        left_page = pygame.Rect(page_margin + 6, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)
        right_page = pygame.Rect(mid_x + 4, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)

        pygame.draw.rect(book_surf, (244, 236, 214), left_page, border_radius=4)
        pygame.draw.rect(book_surf, (244, 236, 214), right_page, border_radius=4)
        pygame.draw.rect(book_surf, (205, 192, 165), left_page, 1, border_radius=4)
        pygame.draw.rect(book_surf, (205, 192, 165), right_page, 1, border_radius=4)

        # 가운데 책등 붉은 책갈피 리본
        pygame.draw.line(book_surf, (180, 40, 35), (mid_x, 14), (mid_x, self.height - 10), 3)

        # 4. 상단 챕터 탭 3개
        self.tab_rects.clear()
        tabs = [
            ("제1장: 조작 및 자원", 0),
            ("제2장: 도구 및 생존", 1),
            ("제3장: 뗏목과 탈출", 2),
        ]
        tab_x = 20
        tab_font = get_font(13, bold=True)
        for name, idx in tabs:
            tab_w = 126
            tab_h = 28
            is_active = (self.current_page == idx)
            bg_col = (244, 236, 214) if is_active else (60, 32, 22)
            txt_col = (50, 35, 25) if is_active else (200, 180, 160)
            rect = pygame.Rect(tab_x, 12, tab_w, tab_h)
            pygame.draw.rect(book_surf, bg_col, rect, border_top_left_radius=4, border_top_right_radius=4)
            if not is_active:
                pygame.draw.rect(book_surf, (100, 60, 40), rect, 1, border_top_left_radius=4, border_top_right_radius=4)

            lbl = tab_font.render(name, True, txt_col)
            book_surf.blit(lbl, (tab_x + (tab_w - lbl.get_width()) // 2, 18))
            self.tab_rects.append((idx, pygame.Rect(self.x + tab_x, self.y + 12, tab_w, tab_h)))
            tab_x += tab_w + 6

        # 닫기 버튼 [X]
        pygame.draw.rect(book_surf, (180, 60, 60), (self.width - 34, 10, 24, 24), border_radius=4)
        x_lbl = get_font(14, bold=True).render("X", True, (255, 255, 255))
        book_surf.blit(x_lbl, (self.width - 27, 13))

        # 5. 페이지 내용 렌더링
        h1_font = get_font(16, bold=True)
        h2_font = get_font(14, bold=True)
        p_font = get_font(13)

        if self.current_page == 0:
            # ---------------- [1페이지: 기본 조작] ----------------
            lx, ly = left_page.x + 16, left_page.y + 16
            book_surf.blit(h1_font.render("◈ 제1조: 탐험가의 기본 조작", True, (130, 40, 30)), (lx, ly))
            ly += 28

            controls = [
                ("이동 조작", "W, A, S, D 또는 방향키로 4방향 이동"),
                ("사물 상호작용", "[E] 키: 자원 채집, 나무 벌목/흔들기, 수면"),
                ("가방 및 제작", "[TAB] 또는 [I] 키: 인벤토리 & 제작 창 열기"),
                ("일지 다시 열기", "[J] 키: 언제든 이 탐험가의 일지 열람 (시간 정지)"),
                ("긴급 음식 섭취", "[1] 키: 베리 섭취(+20) | [2] 키: 코코넛(+30)"),
                ("재시작", "[R] 키: 조난 사망 시 1일 차부터 새로 시작"),
            ]
            for title, desc in controls:
                book_surf.blit(h2_font.render(f"• {title}", True, (50, 40, 30)), (lx, ly))
                ly += 18
                book_surf.blit(p_font.render(f"   {desc}", True, (80, 70, 60)), (lx, ly))
                ly += 24

            # ---------------- [2페이지: 자원 채집] ----------------
            rx, ry = right_page.x + 16, right_page.y + 16
            book_surf.blit(h1_font.render("◈ 제2조: 섬의 6대 생존 자원", True, (130, 40, 30)), (rx, ry))
            ry += 28

            resources = [
                ("나뭇가지", "지면에 떨어진 잔가지 줍기 또는 야자수 흔들기"),
                ("돌", "해변가 백사장과 바위 지대에 흩어진 돌멩이 줍기"),
                ("식물 섬유", "초원에 무성하게 자란 키 큰 섬유 덤불 채집"),
                ("베리 (식량)", "숲속 붉은 야생 베리 덤불에서 수확 (허기 +20)"),
                ("코코넛 (식량)", "해변에 떨어진 열매 또는 야자수 흔들기 (허기 +30)"),
                ("나무 원목", "★ 반드시 [돌도끼]로 야자수를 벌목해야 획득 가능"),
            ]
            for name, desc in resources:
                col = (160, 40, 30) if "★" in desc else (50, 40, 30)
                book_surf.blit(h2_font.render(f"• {name}", True, col), (rx, ry))
                ry += 18
                book_surf.blit(p_font.render(f"   {desc}", True, (80, 70, 60)), (rx, ry))
                ry += 24

        elif self.current_page == 1:
            # ---------------- [3페이지: 도구 제작] ----------------
            lx, ly = left_page.x + 16, left_page.y + 16
            book_surf.blit(h1_font.render("◈ 제3조: 도구 및 구조물 제작법", True, (130, 40, 30)), (lx, ly))
            ly += 28

            recipes = [
                ("돌도끼", "가지 2 + 돌 2 + 섬유 1", "야자수 벌목용 필수 생존 도구"),
                ("밧줄", "식물 섬유 2", "구조물과 뗏목 결속용 가공품"),
                ("천", "가지 2 + 식물 섬유 3", "거처 차양막과 방수용 직물"),
                ("횃불", "가지 2 + 식물 섬유 1", "밤 시간대 시야 반경 대폭 확장"),
                ("모닥불", "원목 3 + 돌 2", "주변을 밝히고 밤 추위 체온 급속 회복"),
                ("간이 거처", "원목 3 + 밧줄 2 + 돌 3 + 천 1", "밤에 수면하여 체력 15 회복"),
            ]
            for name, mat, note in recipes:
                book_surf.blit(h2_font.render(f"• {name} : {mat}", True, (50, 40, 30)), (lx, ly))
                ly += 18
                book_surf.blit(p_font.render(f"   ({note})", True, (100, 75, 55)), (lx, ly))
                ly += 22

            # ---------------- [4페이지: 생존 및 수면] ----------------
            rx, ry = right_page.x + 16, right_page.y + 16
            book_surf.blit(h1_font.render("◈ 제4조: 생존 수치와 밤/수면 규칙", True, (130, 40, 30)), (rx, ry))
            ry += 28

            survival_rules = [
                ("체력, 허기, 체온 관리", "모든 수치는 최대 100입니다."),
                ("허기 고갈 주의", "허기는 초당 0.25씩 감소하며, 0이 되면 초당 0.5 체력 피해를 입습니다."),
                ("밤의 추위와 저체온증", "밤이 되면 체온이 초당 0.15씩 떨어집니다. 체온이 0이 되면 체력이 감소하므로 [모닥불] 온기를 쬐세요."),
                ("간이 거처와 수면", "거처 앞에서 [E] 키로 잠을 자면 남은 밤이 지나가고 체력 15가 회복됩니다."),
                ("★ 5일 차 절대 규칙", "5일 차 밤에는 거대한 해일이 임박하여 [수면이 불가능]합니다!"),
            ]
            for title, desc in survival_rules:
                col = (180, 40, 30) if "★" in title else (50, 40, 30)
                book_surf.blit(h2_font.render(f"• {title}", True, col), (rx, ry))
                ry += 18
                book_surf.blit(p_font.render(f"   {desc}", True, (80, 70, 60)), (rx, ry))
                ry += 24

        elif self.current_page == 2:
            # ---------------- [5페이지: 멧돼지 위협] ----------------
            lx, ly = left_page.x + 16, left_page.y + 16
            book_surf.blit(h1_font.render("◈ 제5조: 숲속의 위협 - 멧돼지", True, (130, 40, 30)), (lx, ly))
            ly += 28

            boar_notes = [
                ("서식지", "섬 북동쪽 숲 깊은 곳을 순찰하는 야생 멧돼지"),
                ("공격 패턴", "가까이 접근하면 머리 위에 붉은 느낌표를 띄우며 0.8초간 공격을 예고한 후, 직선으로 맹렬히 돌진합니다."),
                ("피해량 (10 피해)", "돌진에 충돌하면 체력 10이 감소하고 뒤로 밀려납니다."),
                ("생존 팁", "멧돼지는 사냥하거나 처치할 수 없습니다! 돌진 궤적에서 비껴서 피하고, 일정 거리 이상 달아나면 원래 구역으로 돌아갑니다."),
            ]
            for title, desc in boar_notes:
                book_surf.blit(h2_font.render(f"• {title}", True, (50, 40, 30)), (lx, ly))
                ly += 18
                book_surf.blit(p_font.render(f"   {desc}", True, (80, 70, 60)), (lx, ly))
                ly += 24

            # ---------------- [6페이지: 뗏목 제작과 탈출 방법] ----------------
            rx, ry = right_page.x + 16, right_page.y + 16
            book_surf.blit(h1_font.render("◈ 제6조: 뗏목 제작과 해일 탈출", True, (130, 40, 30)), (rx, ry))
            ry += 28

            escape_notes = [
                ("5일 카운트다운", "이 섬에는 5일째 밤이 끝나는 순간 섬 전체를 집어삼키는 거대한 해일(Tsunami)이 덮쳐옵니다."),
                ("뗏목 제작 준비", "탈출을 위해 충분한 [나무 원목], [밧줄], [천]을 사전에 비축해 두어야 합니다."),
                ("고지대 피난 거처", "해일 도달 전까지 섬 중앙의 가장 높은 암반 고지대에 견고한 거처와 모닥불 방어선을 구축하세요."),
                ("마지막 밤의 사투", "5일 차에는 수면으로 밤을 넘길 수 없으므로, 비축한 베리와 코코넛, 모닥불을 총동원해 새벽까지 버텨내야 합니다!"),
            ]
            for title, desc in escape_notes:
                book_surf.blit(h2_font.render(f"• {title}", True, (130, 40, 30) if "5일" in title else (50, 40, 30)), (rx, ry))
                ry += 18
                book_surf.blit(p_font.render(f"   {desc}", True, (80, 70, 60)), (rx, ry))
                ry += 24

        # 6. 하단 이전/다음 페이지 버튼
        btn_font = get_font(13, bold=True)
        # 이전 버튼
        if self.current_page > 0:
            pygame.draw.rect(book_surf, (200, 185, 155), (28, self.height - 38, 100, 26), border_radius=4)
            prev_lbl = btn_font.render("◀ 이전 장", True, (50, 35, 25))
            book_surf.blit(prev_lbl, (42, self.height - 34))

        # 다음 버튼
        if self.current_page < 2:
            pygame.draw.rect(book_surf, (200, 185, 155), (self.width - 128, self.height - 38, 100, 26), border_radius=4)
            next_lbl = btn_font.render("다음 장 ▶", True, (50, 35, 25))
            book_surf.blit(next_lbl, (self.width - 114, self.height - 34))

        # 페이지 번호
        page_num_str = f"- {self.current_page + 1} / 3 -"
        num_lbl = get_font(12).render(page_num_str, True, (100, 80, 60))
        book_surf.blit(num_lbl, (mid_x - num_lbl.get_width() // 2, self.height - 32))

        # 화면에 합성
        surface.blit(book_surf, (self.x, self.y))

'''
해일 전 3일 (3 Days Before Tsunami)
탐험가의 일지 (Explorer Journal) 월드 오브젝트 및 책 UI 모듈
'''

import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    COLOR_UI_DARK,
    COLOR_UI_PANEL,
    COLOR_UI_EDGE,
    COLOR_UI_LIGHT,
    COLOR_UI_TEXT,
    COLOR_UI_ACCENT,
    COLOR_SHADOW,
)
from fonts import get_font


class PlacedJournal:
    '''게임 시작 지점에 놓여 있는 탐험가의 일지 월드 오브젝트'''

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.width = 48
        self.height = 42
        self.is_active = True
        self.hitbox = pygame.Rect(x + 5, y + 13, 38, 24)
        self.interaction_radius = 50

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def can_interact(self, player) -> bool:
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        return "[좌클릭] 탐험가의 일지 펼치기 ([J]키)"

    def interact(self, player) -> tuple:
        return True, "journal", 1, "탐험가의 일지를 펼쳤습니다. [J키로 다시 열람 가능]"

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        pygame.draw.ellipse(
            target_surface,
            COLOR_SHADOW,
            (screen_x + 5, screen_y + 33, 38, 9),
        )
        pygame.draw.rect(
            target_surface,
            COLOR_UI_DARK,
            (screen_x + 6, screen_y + 6, 36, 29),
        )
        pygame.draw.rect(
            target_surface,
            (143, 89, 73),
            (screen_x + 8, screen_y + 8, 32, 24),
        )
        pygame.draw.rect(
            target_surface,
            COLOR_UI_EDGE,
            (screen_x + 10, screen_y + 10, 28, 19),
        )
        pygame.draw.rect(
            target_surface,
            (250, 238, 207),
            (screen_x + 11, screen_y + 11, 26, 17),
        )
        pygame.draw.rect(
            target_surface,
            (205, 184, 145),
            (screen_x + 23, screen_y + 12, 2, 15),
        )
        for line_y, line_width in ((14, 7), (18, 9), (23, 6)):
            pygame.draw.rect(
                target_surface,
                (157, 129, 99),
                (screen_x + 13, screen_y + line_y, line_width, 1),
            )
            pygame.draw.rect(
                target_surface,
                (157, 129, 99),
                (screen_x + 28, screen_y + line_y, max(3, 10 - line_width), 1),
            )
        pygame.draw.rect(
            target_surface,
            COLOR_UI_ACCENT,
            (screen_x + 22, screen_y + 17, 4, 5),
        )
        pygame.draw.rect(
            target_surface,
            COLOR_UI_DARK,
            (screen_x + 23, screen_y + 18, 2, 3),
        )


class JournalUI:
    '''
    화면 중앙에 큰 책 형태로 표시되는 탐험가의 일지 뷰어
    - 열람 중에는 게임 시간이 정지됨
    - 월드 오브젝트 좌클릭 또는 J키로 토글
    - 내용: 기본 조작, 자원 채집, 도구 제작, 생존 및 수면, 뗏목 제작과 탈출 방법
    '''

    def __init__(self):
        self.is_open = False
        self.current_page = 0  # 0: 기본조작&자원채집, 1: 도구제작&생존수면, 2: 뗏목과탈출

        # 책 크기 (화면 중앙 배치)
        self.width = 740
        self.height = 460
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2

        # 닫기 버튼 사각형
        self.close_btn_rect = pygame.Rect(self.x + self.width - 34, self.y + 10, 24, 24)
        self.prev_btn_rect = pygame.Rect(self.x + 28, self.y + self.height - 38, 100, 26)
        self.next_btn_rect = pygame.Rect(self.x + self.width - 128, self.y + self.height - 38, 100, 26)

        # 탭 버튼 사각형 캐시
        self.tab_rects = []

    def toggle(self):
        self.is_open = not self.is_open

    def handle_event(self, event: pygame.event.Event) -> bool:
        '''이벤트 처리 (J키 토글, ESC 닫기, 페이지 전환)'''
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_j:
                self.toggle()
                return True
            elif event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True
            elif self.is_open:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    self.current_page = max(0, self.current_page - 1)
                    return True
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.current_page = min(2, self.current_page + 1)
                    return True

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # 닫기 버튼
            if self.close_btn_rect.collidepoint(mouse_pos):
                self.is_open = False
                return True

            # 이전 페이지 버튼
            if self.prev_btn_rect.collidepoint(mouse_pos):
                self.current_page = max(0, self.current_page - 1)
                return True

            # 다음 페이지 버튼
            if self.next_btn_rect.collidepoint(mouse_pos):
                self.current_page = min(2, self.current_page + 1)
                return True

            # 상단 탭 버튼 클릭
            for idx, r in self.tab_rects:
                if r.collidepoint(mouse_pos):
                    self.current_page = idx
                    return True

        # 일지 창 내부 클릭 시 게임 조작 차단
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            window_rect = pygame.Rect(self.x, self.y, self.width, self.height)
            if window_rect.collidepoint(event.pos):
                return True

        return True

    @staticmethod
    def _draw_wrapped_text(
        surface: pygame.Surface,
        text: str,
        font: pygame.font.Font,
        color: tuple,
        x: int,
        y: int,
        max_width: int,
        max_y: int,
        line_gap: int = 3,
    ) -> int:
        '''Draw Korean text within a fixed column and return the next free y.'''
        line_height = font.get_linesize() + line_gap
        paragraphs = text.splitlines() or [""]
        for paragraph in paragraphs:
            words = paragraph.split(" ")
            line = ""
            for word in words:
                candidate = f"{line} {word}".strip()
                if font.size(candidate)[0] <= max_width:
                    line = candidate
                    continue
                if line:
                    if y + line_height > max_y:
                        return y
                    surface.blit(font.render(line, True, color), (x, y))
                    y += line_height
                    line = ""
                for char in word:
                    candidate = line + char
                    if line and font.size(candidate)[0] > max_width:
                        if y + line_height > max_y:
                            return y
                        surface.blit(font.render(line, True, color), (x, y))
                        y += line_height
                        line = char
                    else:
                        line = candidate
            if line:
                if y + line_height > max_y:
                    return y
                surface.blit(font.render(line, True, color), (x, y))
                y += line_height
        return y

    def _draw_note(
        self,
        surface: pygame.Surface,
        title: str,
        text: str,
        x: int,
        y: int,
        width: int,
        max_y: int,
        accent=(126, 67, 43),
    ) -> int:
        heading_font = get_font(14, bold=True)
        body_font = get_font(14)
        surface.blit(heading_font.render(title, True, accent), (x, y))
        y += heading_font.get_linesize() + 3
        return self._draw_wrapped_text(
            surface, text, body_font, (78, 67, 52),
            x, y, width, max_y,
        ) + 7

    @staticmethod
    def _draw_sketch(surface: pygame.Surface, kind: str, rect: pygame.Rect):
        '''Draw a small notebook-style sketch with simple ink strokes.'''
        ink = (74, 66, 52)
        green = (91, 119, 70)
        cx, cy = rect.center

        if kind == "island":
            pygame.draw.ellipse(surface, (197, 177, 130), (cx - 95, cy + 30, 190, 32), 2)
            pygame.draw.ellipse(surface, (122, 147, 91), (cx - 76, cy + 17, 152, 34), 2)
            for palm_x, palm_y in ((cx - 42, cy + 20), (cx + 37, cy + 16)):
                pygame.draw.line(surface, ink, (palm_x, palm_y + 15), (palm_x - 4, palm_y - 26), 3)
                for dx, dy in ((-19, -10), (-11, -20), (3, -23), (17, -15)):
                    pygame.draw.line(surface, green, (palm_x - 4, palm_y - 26), (palm_x - 4 + dx, palm_y - 26 + dy), 3)
            pygame.draw.circle(surface, (191, 133, 71), (cx - 43, cy + 2), 5)
            pygame.draw.circle(surface, (191, 133, 71), (cx + 36, cy - 3), 5)
        elif kind == "fire":
            pygame.draw.line(surface, ink, (cx - 35, cy + 35), (cx + 35, cy + 35), 3)
            pygame.draw.line(surface, ink, (cx - 23, cy + 29), (cx + 23, cy + 39), 4)
            pygame.draw.line(surface, ink, (cx + 23, cy + 29), (cx - 23, cy + 39), 4)
            pygame.draw.polygon(surface, (218, 129, 58), [(cx, cy - 34), (cx + 19, cy + 20), (cx, cy + 12), (cx - 18, cy + 20)])
            pygame.draw.polygon(surface, (240, 197, 91), [(cx, cy - 13), (cx + 9, cy + 17), (cx, cy + 10), (cx - 8, cy + 17)])
        elif kind == "boar":
            pygame.draw.ellipse(surface, (147, 104, 76), (cx - 60, cy - 10, 112, 52), 3)
            pygame.draw.circle(surface, (147, 104, 76), (cx + 47, cy + 5), 22, 3)
            pygame.draw.polygon(surface, ink, [(cx + 34, cy - 12), (cx + 28, cy - 31), (cx + 49, cy - 15)], 2)
            pygame.draw.circle(surface, ink, (cx + 53, cy + 1), 2)
            pygame.draw.ellipse(surface, (174, 133, 99), (cx + 59, cy + 10, 20, 12), 2)
            for leg_x in (cx - 36, cx + 24):
                pygame.draw.line(surface, ink, (leg_x, cy + 31), (leg_x - 3, cy + 48), 3)
            pygame.draw.arc(surface, ink, (cx - 83, cy - 3, 25, 28), 1.2, 5.4, 2)
        elif kind == "snake":
            body_path = [
                (cx - 54, cy + 16), (cx - 43, cy + 11), (cx - 31, cy + 16),
                (cx - 20, cy + 7), (cx - 24, cy - 5), (cx - 11, cy - 12),
                (cx + 1, cy - 8), (cx + 5, cy + 3), (cx + 16, cy + 6),
                (cx + 25, cy - 3), (cx + 24, cy - 13),
            ]
            pygame.draw.lines(surface, ink, False, body_path, 7)
            pygame.draw.lines(surface, (249, 239, 211), False, body_path, 4)
            pygame.draw.lines(
                surface,
                (129, 111, 85),
                False,
                [(x + 1, y + 1) for x, y in body_path[1:-2]],
                1,
            )

            head = pygame.Rect(cx + 13, cy - 23, 27, 21)
            pygame.draw.ellipse(surface, ink, head.inflate(3, 2))
            pygame.draw.ellipse(surface, (249, 239, 211), head)
            pygame.draw.circle(surface, ink, (cx + 28, cy - 18), 4)
            pygame.draw.circle(surface, (194, 56, 68), (cx + 29, cy - 18), 2)
            pygame.draw.circle(surface, ink, (cx + 36, cy - 13), 2)
            pygame.draw.line(surface, ink, (cx + 25, cy - 25), (cx + 32, cy - 27), 2)
            pygame.draw.line(surface, ink, (cx + 35, cy - 21), (cx + 40, cy - 18), 2)
            pygame.draw.lines(
                surface,
                (184, 67, 74),
                False,
                [(cx + 40, cy - 9), (cx + 47, cy - 7), (cx + 51, cy - 10)],
                2,
            )
            pygame.draw.line(surface, (184, 67, 74), (cx + 47, cy - 7), (cx + 52, cy - 4), 2)
            pygame.draw.arc(surface, ink, (cx - 61, cy - 1, 15, 17), 0.5, 5.4, 1)
        elif kind == "raft":
            pygame.draw.polygon(surface, ink, [(cx - 72, cy + 30), (cx + 72, cy + 30), (cx + 58, cy + 48), (cx - 58, cy + 48)], 2)
            for dx in (-45, -23, 0, 23, 45):
                pygame.draw.line(surface, (151, 110, 63), (cx + dx, cy + 31), (cx + dx, cy + 47), 5)
            pygame.draw.line(surface, ink, (cx, cy - 44), (cx, cy + 30), 3)
            pygame.draw.polygon(surface, (237, 228, 202), [(cx + 3, cy - 39), (cx + 48, cy + 15), (cx + 3, cy + 15)], 2)
            pygame.draw.arc(surface, (74, 130, 162), (cx - 85, cy + 48, 170, 20), 0.1, 3.0, 2)
            pygame.draw.arc(surface, (74, 130, 162), (cx - 69, cy + 58, 140, 16), 0.1, 3.0, 2)

    def draw(self, surface: pygame.Surface):
        if not self.is_open:
            return

        # 1. 배경 어둡게 딤 처리
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((5, 10, 15, 180))
        surface.blit(dim, (0, 0))

        # 2. 책 외피 (고급 양장본 가죽 표지)
        book_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(book_surf, COLOR_UI_DARK, (0, 0, self.width, self.height))
        pygame.draw.rect(book_surf, COLOR_UI_EDGE, (3, 3, self.width - 6, self.height - 6), 2)
        pygame.draw.rect(book_surf, COLOR_UI_PANEL, (7, 7, self.width - 14, self.height - 14))

        # 책 중앙 접지선 음영
        mid_x = self.width // 2

        # 3. 양쪽 펼쳐진 양피지 페이지 (크림색 바탕)
        page_margin = 12
        left_page = pygame.Rect(page_margin + 6, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)
        right_page = pygame.Rect(mid_x + 4, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)

        pygame.draw.rect(book_surf, (249, 239, 211), left_page)
        pygame.draw.rect(book_surf, (249, 239, 211), right_page)
        pygame.draw.rect(book_surf, (205, 178, 139), left_page, 1)
        pygame.draw.rect(book_surf, (205, 178, 139), right_page, 1)

        # 가운데 책등 붉은 책갈피 리본
        pygame.draw.line(book_surf, COLOR_UI_DARK, (mid_x, 14), (mid_x, self.height - 10), 4)
        pygame.draw.line(book_surf, COLOR_UI_EDGE, (mid_x - 2, 18), (mid_x - 2, self.height - 14), 1)

        # 4. 상단 챕터 탭 3개
        self.tab_rects.clear()
        tabs = [
            ("제1장: 조작 및 자원", 0),
            ("제2장: 도구 및 생존", 1),
            ("제3장: 뗏목과 탈출", 2),
        ]
        tab_x = 20
        tab_font = get_font(13, bold=True)
        for name, idx in tabs:
            tab_w = 126
            tab_h = 28
            is_active = (self.current_page == idx)
            bg_col = (249, 239, 211) if is_active else COLOR_UI_DARK
            txt_col = (73, 49, 46) if is_active else COLOR_UI_LIGHT
            rect = pygame.Rect(tab_x, 12, tab_w, tab_h)
            pygame.draw.rect(book_surf, bg_col, rect)
            if not is_active:
                pygame.draw.rect(book_surf, COLOR_UI_EDGE, rect, 1)

            lbl = tab_font.render(name, True, txt_col)
            book_surf.blit(lbl, (tab_x + (tab_w - lbl.get_width()) // 2, 18))
            self.tab_rects.append((idx, pygame.Rect(self.x + tab_x, self.y + 12, tab_w, tab_h)))
            tab_x += tab_w + 6

        # 닫기 버튼 [X]
        pygame.draw.rect(book_surf, (143, 74, 64), (self.width - 34, 10, 24, 24))
        pygame.draw.rect(book_surf, COLOR_UI_EDGE, (self.width - 34, 10, 24, 24), 2)
        x_lbl = get_font(14, bold=True).render("X", True, COLOR_UI_TEXT)
        book_surf.blit(x_lbl, (self.width - 27, 13))

        # 5. Short field notes and sketches. Each column wraps within its page.
        heading_font = get_font(17, bold=True)
        small_font = get_font(13)
        ink = (76, 57, 51)
        accent = (146, 69, 57)
        columns = (
            (left_page.x + 17, left_page.y + 17, left_page.width - 34),
            (right_page.x + 17, right_page.y + 17, right_page.width - 34),
        )

        def heading(column, text):
            x, y, width = column
            book_surf.blit(heading_font.render(text, True, accent), (x, y))
            return x, y + 29, width

        def note(column, title, text, max_y, color=ink):
            x, y, width = column
            return self._draw_note(book_surf, title, text, x, y, width, max_y, color)

        left, right = columns
        content_bottom = self.height - 54

        if self.current_page == 0:
            lx, ly, lw = heading(left, "표류 첫날의 메모")
            ly = self._draw_wrapped_text(
                book_surf,
                "파도가 나를 이 섬에 내려놓았다. 구조대는 아직 감감무소식. 일단 살아남고, 틈틈이 탈출선을 만들자!",
                small_font, ink, lx, ly, lw, ly + 88, 4,
            ) + 7
            for title, text in (
                ("움직이기", "WASD 또는 방향키"),
                ("손 쓰기", "마우스 왼쪽 클릭"),
                ("가방 / 제작", "E키 / TAB키"),
                ("이 일지 다시 보기", "J키 (읽는 동안 시간 정지)"),
            ):
                ly = note((lx, ly, lw), title, text, content_bottom)

            rx, ry, rw = heading(right, "섬은 꽤 쓸 만하다")
            ry = self._draw_wrapped_text(
                book_surf, "야자수, 돌, 섬유, 베리... 식탁만 빼고 다 있다.",
                small_font, ink, rx, ry, rw, ry + 42, 4,
            )
            self._draw_sketch(book_surf, "island", pygame.Rect(rx + 2, ry + 8, rw - 4, 150))
            ry += 161
            self._draw_wrapped_text(
                book_surf, "베리는 덤불에서, 코코넛은 야자수에서. 돌도끼로 나무를 쾅! (내 발가락은 조심.)",
                small_font, ink, rx, ry, rw, content_bottom, 4,
            )

        elif self.current_page == 1:
            lx, ly, lw = heading(left, "만들어 두면 든든한 것들")
            ly = self._draw_wrapped_text(
                book_surf, "섬에서 주운 재료는 TAB 제작창에서 쓸 수 있다.",
                small_font, ink, lx, ly, lw, ly + 42, 4,
            )
            for title, text in (
                ("돌도끼", "가지 2 · 돌 2 · 섬유 1"),
                ("밧줄", "식물 섬유 2"),
                ("돛천", "가지 2 · 식물 섬유 3"),
                ("모닥불", "원목 3 · 돌 2"),
                ("간이 거처", "원목 3 · 밧줄 2 · 돌 3 · 돛천 1"),
            ):
                ly = note((lx, ly, lw), title, text, content_bottom)

            rx, ry, rw = heading(right, "밤에는 불빛이 최고")
            ry = self._draw_wrapped_text(
                book_surf, "허기와 체온을 살펴보자. 배가 비거나 꽁꽁 얼면 체력이 줄어든다.",
                small_font, ink, rx, ry, rw, ry + 67, 4,
            )
            self._draw_sketch(book_surf, "fire", pygame.Rect(rx + 30, ry + 8, rw - 60, 127))
            ry += 143
            note(
                (rx, ry, rw),
                "구조물 설치와 야영",
                "모닥불과 간이 거처는 퀵바에서 선택한 뒤, 원하는 곳을 우클릭해 설치한다. 모닥불 곁은 따뜻하고, 거처에서 자면 체력 15 회복 (3일 차 제외).",
                content_bottom,
                accent,
            )

        else:
            lx, ly, lw = heading(left, "숲에서 만난 이웃")
            ly = self._draw_wrapped_text(
                book_surf, "멧돼지와 뱀을 만났다. 둘 다 귀여운 구석은 있지만, 가까이 갈 생각은 접자.",
                small_font, ink, lx, ly, lw, ly + 62, 4,
            )
            sketch_y = ly
            self._draw_sketch(book_surf, "boar", pygame.Rect(lx + 8, sketch_y, 144, 74))
            self._draw_sketch(book_surf, "snake", pygame.Rect(lx + 158, sketch_y, 144, 74))
            ly += 91
            ly = note(
                (lx, ly, lw),
                "멧돼지",
                "느낌표 뒤 곧장 돌진한다. 옆으로 피하자. 잡으려 들지 말 것—내가 져 봤다.",
                content_bottom,
                accent,
            )
            note(
                (lx, ly, lw),
                "오른쪽 풀숲의 뱀",
                "보라 방울에 맞으면 10초간 매초 체력 3 감소. 몸을 말면 독을 뱉을 준비니 옆으로 피하자.",
                content_bottom,
                accent,
            )

            rx, ry, rw = heading(right, "탈출선 조립 순서")
            ry = note((rx, ry, rw), "1. 선체", "원목 10 · 밧줄 4 · 돌 3", content_bottom)
            ry = note((rx, ry, rw), "2. 돛", "원목 2 · 밧줄 2 · 돛천 1", content_bottom)
            self._draw_sketch(book_surf, "raft", pygame.Rect(rx + 27, ry + 2, rw - 54, 118))
            ry += 119
            self._draw_wrapped_text(
                book_surf, "해변 설치 장소에 차례로 놓고, 완성되면 좌클릭 탑승! 섬아, 좋은 추억... 아니, 안녕!",
                small_font, ink, rx, ry, rw, content_bottom, 4,
            )

        # 6. 하단 이전/다음 페이지 버튼
        btn_font = get_font(13, bold=True)
        # 이전 버튼
        if self.current_page > 0:
            pygame.draw.rect(book_surf, COLOR_UI_LIGHT, (28, self.height - 38, 100, 26))
            pygame.draw.rect(book_surf, COLOR_UI_EDGE, (28, self.height - 38, 100, 26), 2)
            prev_lbl = btn_font.render("◀ 이전 장", True, COLOR_UI_DARK)
            book_surf.blit(prev_lbl, (42, self.height - 34))

        # 다음 버튼
        if self.current_page < 2:
            pygame.draw.rect(book_surf, COLOR_UI_LIGHT, (self.width - 128, self.height - 38, 100, 26))
            pygame.draw.rect(book_surf, COLOR_UI_EDGE, (self.width - 128, self.height - 38, 100, 26), 2)
            next_lbl = btn_font.render("다음 장 ▶", True, COLOR_UI_DARK)
            book_surf.blit(next_lbl, (self.width - 114, self.height - 34))

        # 페이지 번호
        page_num_str = f"- {self.current_page + 1} / 3 -"
        num_lbl = get_font(13, bold=True).render(page_num_str, True, COLOR_UI_DARK)
        page_num_rect = pygame.Rect(mid_x - 37, self.height - 38, 74, 20)
        pygame.draw.rect(book_surf, COLOR_UI_LIGHT, page_num_rect)
        book_surf.blit(num_lbl, (mid_x - num_lbl.get_width() // 2, self.height - 32))

        # 화면에 합성
        surface.blit(book_surf, (self.x, self.y))

'''
해일 전 3일 (3 Days Before Tsunami)
탐험가의 일지 (Explorer Journal) 월드 오브젝트 및 책 UI 모듈
'''

import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    COLOR_UI_TEXT,
    COLOR_UI_ACCENT,
    COLOR_SHADOW,
)
from fonts import get_font


class PlacedJournal:
    '''게임 시작 지점에 놓여 있는 탐험가의 일지 월드 오브젝트'''

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.width = 36
        self.height = 32
        self.is_active = True
        self.hitbox = pygame.Rect(x + 4, y + 10, 28, 18)
        self.interaction_radius = 50

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def can_interact(self, player) -> bool:
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        return "[좌클릭] 탐험가의 일지 펼치기 ([J]키)"

    def interact(self, player) -> tuple:
        return True, "journal", 1, "탐험가의 일지를 펼쳤습니다. [J키로 다시 열람 가능]"

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 그림자
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 2, screen_y + 18, 32, 10))

        # 2. 나무 받침대 / 그루터기
        pygame.draw.rect(target_surface, (110, 75, 45), (screen_x + 6, screen_y + 14, 24, 12))
        pygame.draw.rect(target_surface, (75, 50, 30), (screen_x + 6, screen_y + 14, 24, 12), 1)

        # 3. 갈색 가죽 표지의 일지 책
        pygame.draw.rect(target_surface, (140, 50, 40), (screen_x + 4, screen_y + 6, 28, 14), border_radius=2)
        pygame.draw.rect(target_surface, (80, 25, 20), (screen_x + 4, screen_y + 6, 28, 14), 1, border_radius=2)

        # 4. 펼쳐진 양장 종이 단면 & 금빛 나침반 문양
        pygame.draw.rect(target_surface, (245, 235, 210), (screen_x + 7, screen_y + 7, 22, 12))
        pygame.draw.line(target_surface, (190, 160, 60), (screen_x + 18, screen_y + 7), (screen_x + 18, screen_y + 19), 2)
        pygame.draw.circle(target_surface, (230, 190, 70), (screen_x + 18, screen_y + 13), 3)


class JournalUI:
    '''
    화면 중앙에 큰 책 형태로 표시되는 탐험가의 일지 뷰어
    - 열람 중에는 게임 시간이 정지됨
    - 월드 오브젝트 좌클릭 또는 J키로 토글
    - 내용: 기본 조작, 자원 채집, 도구 제작, 생존 및 수면, 뗏목 제작과 탈출 방법
    '''

    def __init__(self):
        self.is_open = False
        self.current_page = 0  # 0: 기본조작&자원채집, 1: 도구제작&생존수면, 2: 뗏목과탈출

        # 책 크기 (화면 중앙 배치)
        self.width = 740
        self.height = 460
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2

        # 닫기 버튼 사각형
        self.close_btn_rect = pygame.Rect(self.x + self.width - 34, self.y + 10, 24, 24)
        self.prev_btn_rect = pygame.Rect(self.x + 28, self.y + self.height - 38, 100, 26)
        self.next_btn_rect = pygame.Rect(self.x + self.width - 128, self.y + self.height - 38, 100, 26)

        # 탭 버튼 사각형 캐시
        self.tab_rects = []

    def toggle(self):
        self.is_open = not self.is_open

    def handle_event(self, event: pygame.event.Event) -> bool:
        '''이벤트 처리 (J키 토글, ESC 닫기, 페이지 전환)'''
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_j:
                self.toggle()
                return True
            elif event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True
            elif self.is_open:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    self.current_page = max(0, self.current_page - 1)
                    return True
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.current_page = min(2, self.current_page + 1)
                    return True

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # 닫기 버튼
            if self.close_btn_rect.collidepoint(mouse_pos):
                self.is_open = False
                return True

            # 이전 페이지 버튼
            if self.prev_btn_rect.collidepoint(mouse_pos):
                self.current_page = max(0, self.current_page - 1)
                return True

            # 다음 페이지 버튼
            if self.next_btn_rect.collidepoint(mouse_pos):
                self.current_page = min(2, self.current_page + 1)
                return True

            # 상단 탭 버튼 클릭
            for idx, r in self.tab_rects:
                if r.collidepoint(mouse_pos):
                    self.current_page = idx
                    return True

        # 일지 창 내부 클릭 시 게임 조작 차단
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            window_rect = pygame.Rect(self.x, self.y, self.width, self.height)
            if window_rect.collidepoint(event.pos):
                return True

        return True

    @staticmethod
    def _draw_wrapped_text(
        surface: pygame.Surface,
        text: str,
        font: pygame.font.Font,
        color: tuple,
        x: int,
        y: int,
        max_width: int,
        max_y: int,
        line_gap: int = 3,
    ) -> int:
        '''Draw Korean text within a fixed column and return the next free y.'''
        line_height = font.get_linesize() + line_gap
        paragraphs = text.splitlines() or [""]
        for paragraph in paragraphs:
            words = paragraph.split(" ")
            line = ""
            for word in words:
                candidate = f"{line} {word}".strip()
                if font.size(candidate)[0] <= max_width:
                    line = candidate
                    continue
                if line:
                    if y + line_height > max_y:
                        return y
                    surface.blit(font.render(line, True, color), (x, y))
                    y += line_height
                    line = ""
                for char in word:
                    candidate = line + char
                    if line and font.size(candidate)[0] > max_width:
                        if y + line_height > max_y:
                            return y
                        surface.blit(font.render(line, True, color), (x, y))
                        y += line_height
                        line = char
                    else:
                        line = candidate
            if line:
                if y + line_height > max_y:
                    return y
                surface.blit(font.render(line, True, color), (x, y))
                y += line_height
        return y

    def _draw_note(
        self,
        surface: pygame.Surface,
        title: str,
        text: str,
        x: int,
        y: int,
        width: int,
        max_y: int,
        accent=(126, 67, 43),
    ) -> int:
        heading_font = get_font(14, bold=True)
        body_font = get_font(14)
        surface.blit(heading_font.render(title, True, accent), (x, y))
        y += heading_font.get_linesize() + 3
        return self._draw_wrapped_text(
            surface, text, body_font, (78, 67, 52),
            x, y, width, max_y,
        ) + 7

    @staticmethod
    def _draw_sketch(surface: pygame.Surface, kind: str, rect: pygame.Rect):
        '''Draw a small notebook-style sketch with simple ink strokes.'''
        ink = (74, 66, 52)
        green = (91, 119, 70)
        cx, cy = rect.center

        if kind == "island":
            pygame.draw.ellipse(surface, (197, 177, 130), (cx - 95, cy + 30, 190, 32), 2)
            pygame.draw.ellipse(surface, (122, 147, 91), (cx - 76, cy + 17, 152, 34), 2)
            for palm_x, palm_y in ((cx - 42, cy + 20), (cx + 37, cy + 16)):
                pygame.draw.line(surface, ink, (palm_x, palm_y + 15), (palm_x - 4, palm_y - 26), 3)
                for dx, dy in ((-19, -10), (-11, -20), (3, -23), (17, -15)):
                    pygame.draw.line(surface, green, (palm_x - 4, palm_y - 26), (palm_x - 4 + dx, palm_y - 26 + dy), 3)
            pygame.draw.circle(surface, (191, 133, 71), (cx - 43, cy + 2), 5)
            pygame.draw.circle(surface, (191, 133, 71), (cx + 36, cy - 3), 5)
        elif kind == "fire":
            pygame.draw.line(surface, ink, (cx - 35, cy + 35), (cx + 35, cy + 35), 3)
            pygame.draw.line(surface, ink, (cx - 23, cy + 29), (cx + 23, cy + 39), 4)
            pygame.draw.line(surface, ink, (cx + 23, cy + 29), (cx - 23, cy + 39), 4)
            pygame.draw.polygon(surface, (218, 129, 58), [(cx, cy - 34), (cx + 19, cy + 20), (cx, cy + 12), (cx - 18, cy + 20)])
            pygame.draw.polygon(surface, (240, 197, 91), [(cx, cy - 13), (cx + 9, cy + 17), (cx, cy + 10), (cx - 8, cy + 17)])
        elif kind == "boar":
            pygame.draw.ellipse(surface, (147, 104, 76), (cx - 60, cy - 10, 112, 52), 3)
            pygame.draw.circle(surface, (147, 104, 76), (cx + 47, cy + 5), 22, 3)
            pygame.draw.polygon(surface, ink, [(cx + 34, cy - 12), (cx + 28, cy - 31), (cx + 49, cy - 15)], 2)
            pygame.draw.circle(surface, ink, (cx + 53, cy + 1), 2)
            pygame.draw.ellipse(surface, (174, 133, 99), (cx + 59, cy + 10, 20, 12), 2)
            for leg_x in (cx - 36, cx + 24):
                pygame.draw.line(surface, ink, (leg_x, cy + 31), (leg_x - 3, cy + 48), 3)
            pygame.draw.arc(surface, ink, (cx - 83, cy - 3, 25, 28), 1.2, 5.4, 2)
        elif kind == "raft":
            pygame.draw.polygon(surface, ink, [(cx - 72, cy + 30), (cx + 72, cy + 30), (cx + 58, cy + 48), (cx - 58, cy + 48)], 2)
            for dx in (-45, -23, 0, 23, 45):
                pygame.draw.line(surface, (151, 110, 63), (cx + dx, cy + 31), (cx + dx, cy + 47), 5)
            pygame.draw.line(surface, ink, (cx, cy - 44), (cx, cy + 30), 3)
            pygame.draw.polygon(surface, (237, 228, 202), [(cx + 3, cy - 39), (cx + 48, cy + 15), (cx + 3, cy + 15)], 2)
            pygame.draw.arc(surface, (74, 130, 162), (cx - 85, cy + 48, 170, 20), 0.1, 3.0, 2)
            pygame.draw.arc(surface, (74, 130, 162), (cx - 69, cy + 58, 140, 16), 0.1, 3.0, 2)

    def draw(self, surface: pygame.Surface):
        if not self.is_open:
            return

        # 1. 배경 어둡게 딤 처리
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((5, 10, 15, 180))
        surface.blit(dim, (0, 0))

        # 2. 책 외피 (고급 양장본 가죽 표지)
        book_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(book_surf, (85, 45, 30), (0, 0, self.width, self.height), border_radius=10)
        pygame.draw.rect(book_surf, (55, 28, 18), (0, 0, self.width, self.height), 3, border_radius=10)

        # 책 중앙 접지선 음영
        mid_x = self.width // 2

        # 3. 양쪽 펼쳐진 양피지 페이지 (크림색 바탕)
        page_margin = 12
        left_page = pygame.Rect(page_margin + 6, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)
        right_page = pygame.Rect(mid_x + 4, page_margin + 36, mid_x - page_margin - 10, self.height - page_margin * 2 - 46)

        pygame.draw.rect(book_surf, (244, 236, 214), left_page, border_radius=4)
        pygame.draw.rect(book_surf, (244, 236, 214), right_page, border_radius=4)
        pygame.draw.rect(book_surf, (205, 192, 165), left_page, 1, border_radius=4)
        pygame.draw.rect(book_surf, (205, 192, 165), right_page, 1, border_radius=4)

        # 가운데 책등 붉은 책갈피 리본
        pygame.draw.line(book_surf, (180, 40, 35), (mid_x, 14), (mid_x, self.height - 10), 3)

        # 4. 상단 챕터 탭 3개
        self.tab_rects.clear()
        tabs = [
            ("제1장: 조작 및 자원", 0),
            ("제2장: 도구 및 생존", 1),
            ("제3장: 뗏목과 탈출", 2),
        ]
        tab_x = 20
        tab_font = get_font(13, bold=True)
        for name, idx in tabs:
            tab_w = 126
            tab_h = 28
            is_active = (self.current_page == idx)
            bg_col = (244, 236, 214) if is_active else (60, 32, 22)
            txt_col = (50, 35, 25) if is_active else (200, 180, 160)
            rect = pygame.Rect(tab_x, 12, tab_w, tab_h)
            pygame.draw.rect(book_surf, bg_col, rect, border_top_left_radius=4, border_top_right_radius=4)
            if not is_active:
                pygame.draw.rect(book_surf, (100, 60, 40), rect, 1, border_top_left_radius=4, border_top_right_radius=4)

            lbl = tab_font.render(name, True, txt_col)
            book_surf.blit(lbl, (tab_x + (tab_w - lbl.get_width()) // 2, 18))
            self.tab_rects.append((idx, pygame.Rect(self.x + tab_x, self.y + 12, tab_w, tab_h)))
            tab_x += tab_w + 6

        # 닫기 버튼 [X]
        pygame.draw.rect(book_surf, (180, 60, 60), (self.width - 34, 10, 24, 24), border_radius=4)
        x_lbl = get_font(14, bold=True).render("X", True, (255, 255, 255))
        book_surf.blit(x_lbl, (self.width - 27, 13))

        # 5. Short field notes and sketches. Each column wraps within its page.
        heading_font = get_font(17, bold=True)
        small_font = get_font(13)
        ink = (77, 65, 48)
        accent = (130, 53, 38)
        columns = (
            (left_page.x + 17, left_page.y + 17, left_page.width - 34),
            (right_page.x + 17, right_page.y + 17, right_page.width - 34),
        )

        def heading(column, text):
            x, y, width = column
            book_surf.blit(heading_font.render(text, True, accent), (x, y))
            return x, y + 29, width

        def note(column, title, text, max_y, color=ink):
            x, y, width = column
            return self._draw_note(book_surf, title, text, x, y, width, max_y, color)

        left, right = columns
        content_bottom = self.height - 54

        if self.current_page == 0:
            lx, ly, lw = heading(left, "표류 첫날의 메모")
            ly = self._draw_wrapped_text(
                book_surf,
                "파도가 나를 이 섬에 내려놓았다. 구조대는 아직 감감무소식. 일단 살아남고, 틈틈이 탈출선을 만들자!",
                small_font, ink, lx, ly, lw, ly + 88, 4,
            ) + 7
            for title, text in (
                ("움직이기", "WASD 또는 방향키"),
                ("손 쓰기", "마우스 왼쪽 클릭"),
                ("가방 / 제작", "E키 / TAB키"),
                ("이 일지 다시 보기", "J키 (읽는 동안 시간 정지)"),
            ):
                ly = note((lx, ly, lw), title, text, content_bottom)

            rx, ry, rw = heading(right, "섬은 꽤 쓸 만하다")
            ry = self._draw_wrapped_text(
                book_surf, "야자수, 돌, 섬유, 베리... 식탁만 빼고 다 있다.",
                small_font, ink, rx, ry, rw, ry + 42, 4,
            )
            self._draw_sketch(book_surf, "island", pygame.Rect(rx + 2, ry + 8, rw - 4, 150))
            ry += 161
            self._draw_wrapped_text(
                book_surf, "베리는 덤불에서, 코코넛은 야자수에서. 돌도끼로 나무를 쾅! (내 발가락은 조심.)",
                small_font, ink, rx, ry, rw, content_bottom, 4,
            )

        elif self.current_page == 1:
            lx, ly, lw = heading(left, "만들어 두면 든든한 것들")
            ly = self._draw_wrapped_text(
                book_surf, "섬에서 주운 재료는 TAB 제작창에서 쓸 수 있다.",
                small_font, ink, lx, ly, lw, ly + 42, 4,
            )
            for title, text in (
                ("돌도끼", "가지 2 · 돌 2 · 섬유 1"),
                ("밧줄", "식물 섬유 2"),
                ("돛천", "가지 2 · 식물 섬유 3"),
                ("모닥불", "원목 3 · 돌 2"),
                ("간이 거처", "원목 3 · 밧줄 2 · 돌 3 · 돛천 1"),
            ):
                ly = note((lx, ly, lw), title, text, content_bottom)

            rx, ry, rw = heading(right, "밤에는 불빛이 최고")
            ry = self._draw_wrapped_text(
                book_surf, "허기와 체온을 살펴보자. 배가 비거나 꽁꽁 얼면 체력이 줄어든다.",
                small_font, ink, rx, ry, rw, ry + 67, 4,
            )
            self._draw_sketch(book_surf, "fire", pygame.Rect(rx + 30, ry + 8, rw - 60, 127))
            ry += 143
            note((rx, ry, rw), "내 야영 규칙", "모닥불 곁에서 몸을 녹이고, 거처에서 자면 체력 15 회복. 단, 3일 차 밤잠은 해일이 깨운다!", content_bottom, accent)

        else:
            lx, ly, lw = heading(left, "숲에서 만난 이웃")
            ly = self._draw_wrapped_text(
                book_surf, "멧돼지와 눈이 마주쳤다. 녀석은 인사 대신 돌진 예고를 한다.",
                small_font, ink, lx, ly, lw, ly + 62, 4,
            )
            self._draw_sketch(book_surf, "boar", pygame.Rect(lx + 15, ly + 3, lw - 30, 112))
            ly += 125
            note((lx, ly, lw), "가까이 오면", "느낌표가 뜬 뒤 곧장 달려든다. 옆으로 피하자. 잡으려 들지 말 것—내가 져 봤다.", content_bottom, accent)

            rx, ry, rw = heading(right, "탈출선 조립 순서")
            ry = note((rx, ry, rw), "1. 선체", "원목 10 · 밧줄 4 · 돌 3", content_bottom)
            ry = note((rx, ry, rw), "2. 돛", "원목 2 · 밧줄 2 · 돛천 1", content_bottom)
            self._draw_sketch(book_surf, "raft", pygame.Rect(rx + 27, ry + 2, rw - 54, 118))
            ry += 119
            self._draw_wrapped_text(
                book_surf, "해변 설치 장소에 차례로 놓고, 완성되면 좌클릭 탑승! 섬아, 좋은 추억... 아니, 안녕!",
                small_font, ink, rx, ry, rw, content_bottom, 4,
            )

        # 6. 하단 이전/다음 페이지 버튼
        btn_font = get_font(13, bold=True)
        # 이전 버튼
        if self.current_page > 0:
            pygame.draw.rect(book_surf, (200, 185, 155), (28, self.height - 38, 100, 26), border_radius=4)
            prev_lbl = btn_font.render("◀ 이전 장", True, (50, 35, 25))
            book_surf.blit(prev_lbl, (42, self.height - 34))

        # 다음 버튼
        if self.current_page < 2:
            pygame.draw.rect(book_surf, (200, 185, 155), (self.width - 128, self.height - 38, 100, 26), border_radius=4)
            next_lbl = btn_font.render("다음 장 ▶", True, (50, 35, 25))
            book_surf.blit(next_lbl, (self.width - 114, self.height - 34))

        # 페이지 번호
        page_num_str = f"- {self.current_page + 1} / 3 -"
        num_lbl = get_font(13, bold=True).render(page_num_str, True, (100, 80, 60))
        page_num_rect = pygame.Rect(mid_x - 37, self.height - 38, 74, 20)
        pygame.draw.rect(book_surf, (244, 236, 214), page_num_rect)
        book_surf.blit(num_lbl, (mid_x - num_lbl.get_width() // 2, self.height - 32))

        # 화면에 합성
        surface.blit(book_surf, (self.x, self.y))

"""
해일 전 5일 (5 Days Before Tsunami)
생존 수치 시스템 (체력, 허기, 체온 관리)
"""

from settings import (
    MAX_HEALTH,
    MAX_HUNGER,
    MAX_WARMTH,
    INITIAL_HEALTH,
    INITIAL_HUNGER,
    INITIAL_WARMTH,
    HUNGER_DECAY_RATE,
    NIGHT_WARMTH_DECAY_RATE,
    DAY_WARMTH_RECOVER_RATE,
    CAMPFIRE_WARMTH_RECOVER_RATE,
    HEALTH_DECAY_HUNGER_ZERO,
    HEALTH_DECAY_WARMTH_ZERO,
    BERRY_HUNGER_RECOVER,
    COCONUT_HUNGER_RECOVER,
    SHELTER_SLEEP_HEALTH_RECOVER,
)


class SurvivalStats:
    """체력(Health), 허기(Hunger), 체온(Warmth) 상태를 관리하는 생존 시스템"""

    def __init__(self):
        self.max_health = MAX_HEALTH
        self.max_hunger = MAX_HUNGER
        self.max_warmth = MAX_WARMTH

        self.health = float(INITIAL_HEALTH)
        self.hunger = float(INITIAL_HUNGER)
        self.warmth = float(INITIAL_WARMTH)

        self.is_dead = False
        self._hunger_zero_alerted = False
        self._warmth_zero_alerted = False

    def update(self, dt: float, is_night: bool, near_campfire: bool) -> list:
        """
        시간 경과에 따른 수치 감소 및 페널티 계산
        반환: 경고/상태 알림 메시지 목록 [(타입, 텍스트), ...]
        """
        alerts = []
        if self.is_dead:
            return alerts

        # 1. 허기 감소 (초당 0.25 감소)
        self.hunger = max(0.0, self.hunger - HUNGER_DECAY_RATE * dt)

        # 2. 체온 변동
        if near_campfire:
            # 모닥불 주변에서 체온 회복
            self.warmth = min(self.max_warmth, self.warmth + CAMPFIRE_WARMTH_RECOVER_RATE * dt)
        elif is_night:
            # 밤에는 체온 초당 0.15 감소
            self.warmth = max(0.0, self.warmth - NIGHT_WARMTH_DECAY_RATE * dt)
        else:
            # 낮에는 온화한 날씨로 체온이 서서히 정상화
            self.warmth = min(self.max_warmth, self.warmth + DAY_WARMTH_RECOVER_RATE * dt)

        # 3. 체력 페널티 (허기 0 또는 체온 0일 때 초당 0.5 감소)
        damage = 0.0
        if self.hunger <= 0.0:
            damage += HEALTH_DECAY_HUNGER_ZERO * dt
            if not self._hunger_zero_alerted:
                alerts.append(("HUNGER_ZERO", "배고픔에 지쳐 체력이 감소하고 있습니다! 음식을 섭취하세요."))
                self._hunger_zero_alerted = True
        else:
            self._hunger_zero_alerted = False

        if self.warmth <= 0.0:
            damage += HEALTH_DECAY_WARMTH_ZERO * dt
            if not self._warmth_zero_alerted:
                alerts.append(("WARMTH_ZERO", "극심한 추위로 저체온증이 발생했습니다! 모닥불을 찾으세요."))
                self._warmth_zero_alerted = True
        else:
            self._warmth_zero_alerted = False

        if damage > 0.0:
            self.health = max(0.0, self.health - damage)

        # 사망 판정
        if self.health <= 0.0:
            self.is_dead = True
            alerts.append(("DEATH", "생명력을 모두 소진하여 쓰러졌습니다... (게임 오버)"))

        return alerts

    def eat(self, item_id: str) -> tuple:
        """
        음식(베리, 코코넛) 섭취 시 허기 회복
        반환: (성공여부: bool, 회복량: float, 메시지: str)
        """
        if item_id == "berry":
            recover = BERRY_HUNGER_RECOVER
            name = "베리"
        elif item_id == "coconut":
            recover = COCONUT_HUNGER_RECOVER
            name = "코코넛"
        else:
            return False, 0.0, "섭취할 수 없는 아이템입니다."

        if self.hunger >= self.max_hunger:
            return False, 0.0, "이미 배가 부릅니다."

        old_hunger = self.hunger
        self.hunger = min(self.max_hunger, self.hunger + recover)
        gained = int(self.hunger - old_hunger)
        return True, recover, f"{name} 섭취 완료! (+{gained} 허기 회복)"

    def apply_sleep_recovery(self) -> float:
        """거처 수면 시 체력 +15 회복"""
        old_health = self.health
        self.health = min(self.max_health, self.health + SHELTER_SLEEP_HEALTH_RECOVER)
        return self.health - old_health

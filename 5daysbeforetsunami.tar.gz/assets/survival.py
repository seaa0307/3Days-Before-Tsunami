'''
해일 전 3일 (3 Days Before Tsunami)
생존 수치 시스템 (체력, 허기, 체온 관리)
'''

from settings import (
    MAX_HEALTH,
    MAX_HUNGER,
    MAX_WARMTH,
    INITIAL_HEALTH,
    INITIAL_HUNGER,
    INITIAL_WARMTH,
    HUNGER_DECAY_RATE,
    WARMTH_DECAY_RATES,
    CAMPFIRE_WARMTH_RECOVER_RATE,
    HEALTH_DECAY_HUNGER_ZERO,
    WARMTH_DAMAGE_MILD_THRESHOLD,
    WARMTH_DAMAGE_MODERATE_THRESHOLD,
    WARMTH_DAMAGE_SEVERE_THRESHOLD,
    HEALTH_DECAY_WARMTH_MILD,
    HEALTH_DECAY_WARMTH_MODERATE,
    HEALTH_DECAY_WARMTH_SEVERE,
    BERRY_HUNGER_RECOVER,
    COCONUT_HUNGER_RECOVER,
    SHELTER_SLEEP_HEALTH_RECOVER,
    SNAKE_POISON_DAMAGE_PER_SECOND,
    SNAKE_POISON_DURATION,
)


class SurvivalStats:
    '''체력, 허기, 체온 및 독 상태를 관리하는 생존 시스템'''

    def __init__(self):
        self.max_health = MAX_HEALTH
        self.max_hunger = MAX_HUNGER
        self.max_warmth = MAX_WARMTH

        self.health = float(INITIAL_HEALTH)
        self.hunger = float(INITIAL_HUNGER)
        self.warmth = float(INITIAL_WARMTH)

        self.is_dead = False
        self._hunger_zero_alerted = False
        self._low_warmth_alerted = False
        self.poison_remaining = 0.0
        self.poison_damage_per_second = 0.0

    def apply_poison(
        self,
        duration: float = SNAKE_POISON_DURATION,
        damage_per_second: float = SNAKE_POISON_DAMAGE_PER_SECOND,
    ):
        '''Apply or refresh a poison effect without stacking its damage rate.'''
        self.poison_remaining = max(self.poison_remaining, duration)
        self.poison_damage_per_second = max(
            self.poison_damage_per_second,
            damage_per_second,
        )

    def update(
        self,
        dt: float,
        is_night: bool,
        near_campfire: bool,
        current_day: int,
        torch_equipped: bool = False,
    ) -> list:
        '''
        시간 경과에 따른 수치 감소 및 페널티 계산
        반환: 경고/상태 알림 메시지 목록 [(타입, 텍스트), ...]
        '''
        alerts = []
        if self.is_dead:
            return alerts

        # 1. 허기 감소 (초당 0.5 감소)
        self.hunger = max(0.0, self.hunger - HUNGER_DECAY_RATE * dt)

        # 2. 체온 변동
        if near_campfire or torch_equipped:
            self.warmth = min(self.max_warmth, self.warmth + CAMPFIRE_WARMTH_RECOVER_RATE * dt)
        else:
            phase = "night" if is_night else "day"
            decay_rate = WARMTH_DECAY_RATES.get(current_day, WARMTH_DECAY_RATES[3])[phase]
            self.warmth = max(0.0, self.warmth - decay_rate * dt)

        # 3. 허기, 저체온, 독 상태에 따른 체력 감소
        damage = 0.0
        if self.hunger <= 0.0:
            damage += HEALTH_DECAY_HUNGER_ZERO * dt
            if not self._hunger_zero_alerted:
                alerts.append(("HUNGER_ZERO", "배고픔에 지쳐 체력이 감소하고 있습니다! 음식을 섭취하세요."))
                self._hunger_zero_alerted = True
        else:
            self._hunger_zero_alerted = False

        if self.warmth <= WARMTH_DAMAGE_SEVERE_THRESHOLD:
            damage += HEALTH_DECAY_WARMTH_SEVERE * dt
        elif self.warmth < WARMTH_DAMAGE_MODERATE_THRESHOLD:
            damage += HEALTH_DECAY_WARMTH_MODERATE * dt
        elif self.warmth < WARMTH_DAMAGE_MILD_THRESHOLD:
            damage += HEALTH_DECAY_WARMTH_MILD * dt

        poison_dt = min(dt, self.poison_remaining)
        if poison_dt > 0:
            damage += self.poison_damage_per_second * poison_dt
            self.poison_remaining = max(0.0, self.poison_remaining - dt)
            if self.poison_remaining == 0:
                self.poison_damage_per_second = 0.0

        if self.warmth < WARMTH_DAMAGE_MILD_THRESHOLD:
            if not self._low_warmth_alerted:
                alerts.append(("WARMTH_LOW", "체온이 낮아 체력이 감소하고 있습니다! 횃불을 들거나 모닥불 곁으로 가세요."))
                self._low_warmth_alerted = True
        else:
            self._low_warmth_alerted = False

        if damage > 0.0:
            self.health = max(0.0, self.health - damage)

        # 사망 판정
        if self.health <= 0.0:
            self.is_dead = True
            alerts.append(("DEATH", "생명력을 모두 소진하여 쓰러졌습니다... (게임 오버)"))

        return alerts

    def eat(self, item_id: str) -> tuple:
        '''
        음식(베리, 코코넛) 섭취 시 허기 회복
        반환: (성공여부: bool, 회복량: float, 메시지: str)
        '''
        if item_id == "berry":
            recover = BERRY_HUNGER_RECOVER
            name = "베리"
        elif item_id == "coconut":
            recover = COCONUT_HUNGER_RECOVER
            name = "코코넛"
        else:
            return False, 0.0, "섭취할 수 없는 아이템입니다."

        if self.hunger >= self.max_hunger:
            return False, 0.0, "이미 배가 부릅니다."

        old_hunger = self.hunger
        self.hunger = min(self.max_hunger, self.hunger + recover)
        gained = int(self.hunger - old_hunger)
        return True, recover, f"{name} 섭취 완료! (+{gained} 허기 회복)"

    def apply_sleep_recovery(self) -> float:
        '''거처 수면 시 체력 +15 회복'''
        old_health = self.health
        self.health = min(self.max_health, self.health + SHELTER_SLEEP_HEALTH_RECOVER)
        return self.health - old_health

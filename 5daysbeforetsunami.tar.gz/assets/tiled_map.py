'''Loader for finite orthogonal Tiled JSON maps.'''

import json
from pathlib import Path
from typing import Optional

import pygame

from image_assets import get_tileset_tile, resolve_image_path


TILE_DEEP_WATER = 0
TILE_SAND = 2
TILE_GRASS = 3

_GID_MASK = 0x0FFFFFFF
_GID_FLIP_H = 0x80000000
_GID_FLIP_V = 0x40000000
_GID_FLAG_MASK = 0xF0000000

_TILESET_FILENAME_ALIASES = {
    "타일셋.png": "tileset.png",
    "타일셋 2.png": "tileset_2.png",
    "타일셋 3.png": "tileset_3.png",
    "타일셋 4.png": "tileset_4.png",
}


class TiledMap:
    def __init__(self, path: Path, render_tile_size: int):
        self.path = path
        try:
            map_data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Unable to read Tiled map '{path}': {exc}") from exc

        if map_data.get("orientation") != "orthogonal" or map_data.get("infinite"):
            raise ValueError(f"Unsupported Tiled map format in '{path}'.")

        self.cols = self._positive_int(map_data, "width", path)
        self.rows = self._positive_int(map_data, "height", path)
        self.tile_width = self._positive_int(map_data, "tilewidth", path)
        self.tile_height = self._positive_int(map_data, "tileheight", path)
        if render_tile_size % self.tile_width or render_tile_size % self.tile_height:
            raise ValueError("The rendered tile size must be an integer multiple of the Tiled tile size.")
        if self.tile_width != self.tile_height:
            raise ValueError("Non-square Tiled cells are not supported.")

        self.render_scale = render_tile_size // self.tile_width
        self._tilesets = self._load_tilesets(map_data.get("tilesets", []), path)
        layers = map_data.get("layers", [])
        if not layers:
            raise ValueError(f"Tiled map '{path}' contains no layers.")

        self._tile_cache = {}
        full_tile_rect = (pygame.Rect(0, 0, render_tile_size, render_tile_size),)
        self.ground_surfaces = [
            [self._ocean_surface(render_tile_size) for _ in range(self.cols)]
            for _ in range(self.rows)
        ]
        self.terrain = [[TILE_DEEP_WATER for _ in range(self.cols)] for _ in range(self.rows)]
        self.tile_colliders = [
            [full_tile_rect for _ in range(self.cols)]
            for _ in range(self.rows)
        ]
        self.object_layers: dict[str, list[dict]] = {}

        for layer in layers:
            if not layer.get("visible", True):
                continue
            layer_type = layer.get("type")
            if layer_type == "tilelayer":
                self._draw_tile_layer(layer, render_tile_size)
            elif layer_type == "objectgroup":
                self._parse_object_layer(layer)
            else:
                raise ValueError(
                    f"Unsupported visible layer '{layer.get('name', '')}' "
                    f"of type '{layer_type}' in '{path}'."
                )

    @staticmethod
    def _positive_int(data: dict, key: str, path: Path) -> int:
        value = data.get(key)
        if not isinstance(value, int) or value <= 0:
            raise ValueError(f"Invalid '{key}' in Tiled map '{path}'.")
        return value

    @staticmethod
    def _ocean_surface(render_tile_size: int) -> pygame.Surface:
        return pygame.transform.scale(
            get_tileset_tile(5, 5), (render_tile_size, render_tile_size)
        )

    @staticmethod
    def _resolve_tileset_image_path(raw_image: str, map_path: Path) -> Path:
        raw_path = (map_path.parent / raw_image).resolve()
        if raw_path.is_file():
            return raw_path
        filename = Path(raw_image).name
        direct = resolve_image_path(filename)
        if direct.is_file():
            return direct
        alias = _TILESET_FILENAME_ALIASES.get(filename)
        if alias:
            return resolve_image_path(alias)
        return direct

    @classmethod
    def _load_tilesets(cls, tilesets: list, map_path: Path) -> list:
        loaded = []
        for definition in sorted(tilesets, key=lambda tileset: tileset.get("firstgid", 0)):
            if "image" in definition:
                image_path = cls._resolve_tileset_image_path(definition["image"], map_path)
                try:
                    image = pygame.image.load(str(image_path))
                except (OSError, pygame.error) as exc:
                    raise RuntimeError(
                        f"Unable to load tileset image '{image_path}' "
                        f"referenced by '{map_path}': {exc}"
                    ) from exc

                expected_size = (definition.get("imagewidth"), definition.get("imageheight"))
                if image.get_size() != expected_size:
                    raise ValueError(
                        f"Tileset image '{image_path}' has size {image.get_size()}, "
                        f"expected {expected_size}."
                    )
                if image.get_masks()[3] == 0 and definition.get("transparentcolor"):
                    image.set_colorkey(pygame.Color(definition["transparentcolor"]))

                loaded.append({
                    "firstgid": definition["firstgid"],
                    "tilecount": definition["tilecount"],
                    "columns": definition["columns"],
                    "tilewidth": definition["tilewidth"],
                    "tileheight": definition["tileheight"],
                    "margin": definition.get("margin", 0),
                    "spacing": definition.get("spacing", 0),
                    "image": image,
                })
            elif "tiles" in definition:
                collection_tiles = {}
                for tile_def in definition["tiles"]:
                    tile_image_name = tile_def.get("image")
                    if not tile_image_name:
                        continue
                    image_path = cls._resolve_tileset_image_path(tile_image_name, map_path)
                    try:
                        tile_image = pygame.image.load(str(image_path))
                    except (OSError, pygame.error) as exc:
                        raise RuntimeError(
                            f"Unable to load tile image '{image_path}' "
                            f"referenced by '{map_path}': {exc}"
                        ) from exc
                    collection_tiles[tile_def["id"]] = {
                        "image": tile_image,
                        "image_name": Path(tile_image_name).name,
                    }
                loaded.append({
                    "firstgid": definition["firstgid"],
                    "tilecount": definition.get("tilecount", len(collection_tiles)),
                    "tiles": collection_tiles,
                })
        if not loaded:
            raise ValueError(f"Tiled map '{map_path}' contains no tilesets.")
        return loaded

    def _find_tileset(self, tile_gid: int) -> Optional[dict]:
        for item in reversed(self._tilesets):
            if tile_gid < item["firstgid"]:
                continue
            local_id = tile_gid - item["firstgid"]
            if "tiles" in item:
                if local_id in item["tiles"]:
                    return item
            elif local_id < item["tilecount"]:
                return item
        return None

    def _get_tile(self, gid: int, render_tile_size: int) -> tuple[pygame.Surface, pygame.Surface, tuple[pygame.Rect, ...]]:
        if gid & _GID_FLAG_MASK:
            raise ValueError(f"Flipped tile GIDs are not supported (GID {gid}).")
        tile_gid = gid & _GID_MASK
        if tile_gid in self._tile_cache:
            return self._tile_cache[tile_gid]

        tileset = self._find_tileset(tile_gid)
        if tileset is None:
            raise ValueError(f"Tiled map contains GID {tile_gid} with no matching tileset.")

        local_id = tile_gid - tileset["firstgid"]
        if "tiles" in tileset:
            source = tileset["tiles"][local_id]["image"]
            result = (
                source,
                pygame.transform.scale(source, (render_tile_size, render_tile_size)),
                self._compute_tile_colliders(source, self.render_scale),
            )
            self._tile_cache[tile_gid] = result
            return result

        column = local_id % tileset["columns"]
        row = local_id // tileset["columns"]
        x = tileset["margin"] + column * (tileset["tilewidth"] + tileset["spacing"])
        y = tileset["margin"] + row * (tileset["tileheight"] + tileset["spacing"])
        source = tileset["image"].subsurface(
            (x, y, tileset["tilewidth"], tileset["tileheight"])
        ).copy()
        result = (
            source,
            pygame.transform.scale(source, (render_tile_size, render_tile_size)),
            self._compute_tile_colliders(source, self.render_scale),
        )
        self._tile_cache[tile_gid] = result
        return result

    @staticmethod
    def _is_ocean_boundary_pixel(color: pygame.Color) -> bool:
        return color.a < 128 or (color.g > color.b > color.r and color.b >= 140)

    @classmethod
    def _compute_tile_colliders(cls, tile: pygame.Surface, scale: int) -> tuple[pygame.Rect, ...]:
        width, height = tile.get_size()
        has_transparent = any(
            tile.get_at((x, y)).a < 128
            for y in range(height)
            for x in range(width)
        )
        if not has_transparent:
            return ()

        active_runs: dict[tuple[int, int], list[int]] = {}
        rects: list[pygame.Rect] = []
        for y in range(height):
            runs: list[tuple[int, int]] = []
            x = 0
            while x < width:
                if cls._is_ocean_boundary_pixel(tile.get_at((x, y))):
                    x0 = x
                    while x < width and cls._is_ocean_boundary_pixel(tile.get_at((x, y))):
                        x += 1
                    runs.append((x0, x))
                else:
                    x += 1

            next_active: dict[tuple[int, int], list[int]] = {}
            for run in runs:
                if run in active_runs:
                    y0, _ = active_runs[run]
                    next_active[run] = [y0, y + 1]
                else:
                    next_active[run] = [y, y + 1]
            for run, (y0, y1) in active_runs.items():
                if run not in next_active:
                    rects.append(
                        pygame.Rect(run[0] * scale, y0 * scale, (run[1] - run[0]) * scale, (y1 - y0) * scale)
                    )
            active_runs = next_active

        for run, (y0, y1) in active_runs.items():
            rects.append(
                pygame.Rect(run[0] * scale, y0 * scale, (run[1] - run[0]) * scale, (y1 - y0) * scale)
            )
        return tuple(rects)

    @staticmethod
    def _terrain_for_tile(tile: pygame.Surface) -> int:
        width, height = tile.get_size()
        total = width * height
        water = 0
        grass = 0
        sand = 0
        for y in range(height):
            for x in range(width):
                color = tile.get_at((x, y))
                if color.a < 128 or (color.b > color.g and color.b > color.r and color.r < 100):
                    water += 1
                elif color.g > color.r and color.g > color.b and color.b < 120:
                    grass += 1
                elif color.r >= color.g and color.a >= 128:
                    sand += 1

        if water > total // 2:
            return TILE_DEEP_WATER
        if grass > sand:
            return TILE_GRASS
        return TILE_SAND

    def _draw_tile_layer(self, layer: dict, render_tile_size: int):
        layer_width = layer.get("width", self.cols)
        layer_height = layer.get("height", self.rows)
        data = layer.get("data")
        if not isinstance(data, list) or len(data) != layer_width * layer_height:
            raise ValueError(f"Invalid tile data in layer '{layer.get('name', '')}'.")

        offset_x = layer.get("x", 0)
        offset_y = layer.get("y", 0)
        opacity = max(0.0, min(1.0, float(layer.get("opacity", 1.0))))
        for index, gid in enumerate(data):
            if not gid:
                continue
            source, tile_surface, colliders = self._get_tile(gid, render_tile_size)
            if opacity < 1.0:
                tile_surface.set_alpha(round(255 * opacity))

            column = index % layer_width + offset_x
            row = index // layer_width + offset_y
            if not (0 <= column < self.cols and 0 <= row < self.rows):
                continue
            self.ground_surfaces[row][column].blit(tile_surface, (0, 0))
            self.terrain[row][column] = self._terrain_for_tile(source)
            self.tile_colliders[row][column] = colliders

    def _parse_object_layer(self, layer: dict):
        layer_name = layer.get("name", "")
        parsed_objects = []
        for obj in layer.get("objects", []):
            if not obj.get("visible", True):
                continue
            raw_gid = obj.get("gid", 0)
            tile_gid = raw_gid & _GID_MASK
            flip_x = bool(raw_gid & _GID_FLIP_H)
            flip_y = bool(raw_gid & _GID_FLIP_V)
            image = None
            image_name = None
            if tile_gid:
                tileset = self._find_tileset(tile_gid)
                if tileset and "tiles" in tileset:
                    tile_entry = tileset["tiles"][tile_gid - tileset["firstgid"]]
                    image = tile_entry["image"]
                    image_name = tile_entry["image_name"]
            parsed_objects.append({
                "id": obj.get("id"),
                "name": obj.get("name", ""),
                "type": obj.get("type", ""),
                "gid": tile_gid,
                "flip_x": flip_x,
                "flip_y": flip_y,
                "x": float(obj.get("x", 0.0)),
                "y": float(obj.get("y", 0.0)),
                "width": float(obj.get("width", 0.0)),
                "height": float(obj.get("height", 0.0)),
                "image": image,
                "image_name": image_name,
            })
        self.object_layers[layer_name] = parsed_objects

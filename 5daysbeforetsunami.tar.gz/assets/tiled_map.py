'''Loader for finite orthogonal Tiled JSON maps.'''

import json
from pathlib import Path

import pygame

from image_assets import get_tileset_tile, resolve_image_path


TILE_DEEP_WATER = 0
TILE_SAND = 2
TILE_GRASS = 3

_GID_MASK = 0x0FFFFFFF
_GID_FLAG_MASK = 0xF0000000


class TiledMap:
    def __init__(self, path: Path, render_tile_size: int):
        self.path = path
        try:
            map_data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Unable to read Tiled map '{path}': {exc}") from exc

        if map_data.get("orientation") != "orthogonal" or map_data.get("infinite"):
            raise ValueError(f"Unsupported Tiled map format in '{path}'.")

        self.cols = self._positive_int(map_data, "width", path)
        self.rows = self._positive_int(map_data, "height", path)
        self.tile_width = self._positive_int(map_data, "tilewidth", path)
        self.tile_height = self._positive_int(map_data, "tileheight", path)
        if render_tile_size % self.tile_width or render_tile_size % self.tile_height:
            raise ValueError("The rendered tile size must be an integer multiple of the Tiled tile size.")
        if self.tile_width != self.tile_height:
            raise ValueError("Non-square Tiled cells are not supported.")

        self._tilesets = self._load_tilesets(map_data.get("tilesets", []), path)
        layers = map_data.get("layers", [])
        if not layers:
            raise ValueError(f"Tiled map '{path}' contains no layers.")

        self._tile_cache = {}
        self.ground_surfaces = [
            [self._ocean_surface(render_tile_size) for _ in range(self.cols)]
            for _ in range(self.rows)
        ]
        self.terrain = [[TILE_DEEP_WATER for _ in range(self.cols)] for _ in range(self.rows)]

        for layer in layers:
            if not layer.get("visible", True):
                continue
            if layer.get("type") != "tilelayer":
                raise ValueError(
                    f"Unsupported visible layer '{layer.get('name', '')}' "
                    f"of type '{layer.get('type')}' in '{path}'."
                )
            self._draw_tile_layer(layer, render_tile_size)

    @staticmethod
    def _positive_int(data: dict, key: str, path: Path) -> int:
        value = data.get(key)
        if not isinstance(value, int) or value <= 0:
            raise ValueError(f"Invalid '{key}' in Tiled map '{path}'.")
        return value

    @staticmethod
    def _ocean_surface(render_tile_size: int) -> pygame.Surface:
        return pygame.transform.scale(
            get_tileset_tile(5, 5), (render_tile_size, render_tile_size)
        )

    @staticmethod
    def _load_tilesets(tilesets: list, map_path: Path) -> list:
        loaded = []
        for definition in sorted(tilesets, key=lambda tileset: tileset.get("firstgid", 0)):
            raw_path = (map_path.parent / definition["image"]).resolve()
            if raw_path.is_file():
                image_path = raw_path
            else:
                image_path = resolve_image_path(Path(definition["image"]).name)

            try:
                image = pygame.image.load(str(image_path))
            except (OSError, pygame.error) as exc:
                raise RuntimeError(
                    f"Unable to load tileset image '{image_path}' "
                    f"referenced by '{map_path}': {exc}"
                ) from exc

            expected_size = (definition.get("imagewidth"), definition.get("imageheight"))
            if image.get_size() != expected_size:
                raise ValueError(
                    f"Tileset image '{image_path}' has size {image.get_size()}, "
                    f"expected {expected_size}."
                )
            if image.get_masks()[3] == 0 and definition.get("transparentcolor"):
                image.set_colorkey(pygame.Color(definition["transparentcolor"]))

            loaded.append({
                "firstgid": definition["firstgid"],
                "tilecount": definition["tilecount"],
                "columns": definition["columns"],
                "tilewidth": definition["tilewidth"],
                "tileheight": definition["tileheight"],
                "margin": definition.get("margin", 0),
                "spacing": definition.get("spacing", 0),
                "image": image,
            })
        if not loaded:
            raise ValueError(f"Tiled map '{map_path}' contains no tilesets.")
        return loaded

    def _get_tile(self, gid: int, render_tile_size: int) -> tuple[pygame.Surface, pygame.Surface]:
        if gid & _GID_FLAG_MASK:
            raise ValueError(f"Flipped tile GIDs are not supported (GID {gid}).")
        tile_gid = gid & _GID_MASK
        if tile_gid in self._tile_cache:
            return self._tile_cache[tile_gid]

        tileset = next(
            (
                item for item in reversed(self._tilesets)
                if item["firstgid"] <= tile_gid
                and tile_gid - item["firstgid"] < item["tilecount"]
            ),
            None,
        )
        if tileset is None:
            raise ValueError(f"Tiled map contains GID {tile_gid} with no matching tileset.")

        local_id = tile_gid - tileset["firstgid"]
        column = local_id % tileset["columns"]
        row = local_id // tileset["columns"]
        x = tileset["margin"] + column * (tileset["tilewidth"] + tileset["spacing"])
        y = tileset["margin"] + row * (tileset["tileheight"] + tileset["spacing"])
        source = tileset["image"].subsurface(
            (x, y, tileset["tilewidth"], tileset["tileheight"])
        ).copy()
        result = source, pygame.transform.scale(source, (render_tile_size, render_tile_size))
        self._tile_cache[tile_gid] = result
        return result

    @staticmethod
    def _terrain_for_tile(tile: pygame.Surface) -> int:
        center = tile.get_at((tile.get_width() // 2, tile.get_height() // 2))
        if center.a < 128 or center.b > center.g:
            return TILE_DEEP_WATER
        if center.g > center.r and center.g > center.b:
            return TILE_GRASS
        return TILE_SAND

    def _draw_tile_layer(self, layer: dict, render_tile_size: int):
        layer_width = layer.get("width", self.cols)
        layer_height = layer.get("height", self.rows)
        data = layer.get("data")
        if not isinstance(data, list) or len(data) != layer_width * layer_height:
            raise ValueError(f"Invalid tile data in layer '{layer.get('name', '')}'.")

        offset_x = layer.get("x", 0)
        offset_y = layer.get("y", 0)
        opacity = max(0.0, min(1.0, float(layer.get("opacity", 1.0))))
        for index, gid in enumerate(data):
            if not gid:
                continue
            source, tile_surface = self._get_tile(gid, render_tile_size)
            if opacity < 1.0:
                tile_surface.set_alpha(round(255 * opacity))

            column = index % layer_width + offset_x
            row = index // layer_width + offset_y
            if not (0 <= column < self.cols and 0 <= row < self.rows):
                continue
            self.ground_surfaces[row][column].blit(tile_surface, (0, 0))
            self.terrain[row][column] = self._terrain_for_tile(source)

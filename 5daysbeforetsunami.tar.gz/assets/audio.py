'''Procedurally generated, original sound effects for the game.'''

from array import array
import math
from pathlib import Path

import pygame


class SoundEffects:
    def __init__(self):
        mixer_format = pygame.mixer.get_init()
        if mixer_format is None:
            print("Audio is unavailable; sound effects are disabled.")
            self.enabled = False
            self.sounds = {}
            self._step_timer = 0.0
            return

        self.enabled = True
        self.sample_rate = mixer_format[0]
        self.output_channels = mixer_format[2]
        pygame.mixer.set_num_channels(16)
        pygame.mixer.set_reserved(2)
        self.sounds = {
            "ui": self._make_sound(0.055, self._ui_sample),
            "pickup": self._make_sound(0.22, self._pickup_sample),
            "chop": self._make_sound(0.17, self._chop_sample),
            "hurt": self._make_sound(0.26, self._hurt_sample),
            "eat": self._make_sound(0.13, self._eat_sample),
            "footstep": self._make_sound(0.09, self._footstep_sample),
            "build": self._make_sound(0.29, self._build_sample),
            "launch": self._make_sound(0.65, self._launch_sample),
            "minigame_success": self._make_sound(0.42, self._minigame_success_sample),
            "minigame_failure": self._make_sound(0.38, self._minigame_failure_sample),
        }
        self.sounds["footstep"].set_volume(0.35)
        self._step_timer = 0.0

    def _make_sound(self, duration: float, sample_function) -> pygame.mixer.Sound:
        sample_count = int(self.sample_rate * duration)
        samples = array("h")
        for index in range(sample_count):
            time = index / self.sample_rate
            progress = index / sample_count
            sample = max(-1.0, min(1.0, sample_function(time, progress)))
            pcm_sample = int(sample * 32767)
            for _ in range(self.output_channels):
                samples.append(pcm_sample)
        return pygame.mixer.Sound(buffer=samples.tobytes())

    def _noise(self, time: float, seed: int) -> float:
        value = (int(time * self.sample_rate) + seed) & 0xFFFFFFFF
        value = (value ^ (value >> 16)) * 0x7FEB352D & 0xFFFFFFFF
        value = (value ^ (value >> 15)) * 0x846CA68B & 0xFFFFFFFF
        value ^= value >> 16
        return (value / 0xFFFFFFFF) * 2.0 - 1.0

    def _ui_sample(self, time: float, progress: float) -> float:
        envelope = (1.0 - progress) ** 4
        return math.sin(2.0 * math.pi * 1250.0 * time) * envelope * 0.24

    def _pickup_sample(self, time: float, progress: float) -> float:
        envelope = (1.0 - progress) ** 2
        first = math.sin(2.0 * math.pi * 740.0 * time)
        second = math.sin(2.0 * math.pi * 1110.0 * time)
        return (first + second * 0.55) * envelope * 0.2

    def _chop_sample(self, time: float, progress: float) -> float:
        noise = self._noise(time, 17)
        transient = noise * math.exp(-time * 42.0) * 0.48
        body = math.sin(2.0 * math.pi * (125.0 - 38.0 * progress) * time)
        return transient + body * (1.0 - progress) * 0.32

    def _hurt_sample(self, time: float, progress: float) -> float:
        noise = self._noise(time, 31)
        frequency = 190.0 - 105.0 * progress
        thud = math.sin(2.0 * math.pi * frequency * time) * (1.0 - progress) ** 1.5
        return thud * 0.42 + noise * math.exp(-time * 28.0) * 0.13

    def _eat_sample(self, time: float, progress: float) -> float:
        noise = self._noise(time, 53)
        crunch = noise * (1.0 - progress) ** 2
        soft_tone = math.sin(2.0 * math.pi * 460.0 * time) * (1.0 - progress)
        return crunch * 0.18 + soft_tone * 0.1

    def _footstep_sample(self, time: float, progress: float) -> float:
        noise = self._noise(time, 71)
        envelope = (1.0 - progress) ** 3
        low_thump = math.sin(2.0 * math.pi * 105.0 * time)
        return envelope * (noise * 0.22 + low_thump * 0.16)

    def _build_sample(self, time: float, progress: float) -> float:
        envelope = (1.0 - progress) ** 1.8
        tones = (
            math.sin(2.0 * math.pi * 520.0 * time)
            + math.sin(2.0 * math.pi * 780.0 * time) * 0.65
            + math.sin(2.0 * math.pi * 1040.0 * time) * 0.35
        )
        return tones * envelope * 0.16

    def _launch_sample(self, time: float, progress: float) -> float:
        envelope = min(1.0, progress * 8.0) * (1.0 - progress) ** 0.7
        chord = (
            math.sin(2.0 * math.pi * 392.0 * time)
            + math.sin(2.0 * math.pi * 587.0 * time) * 0.7
            + math.sin(2.0 * math.pi * 784.0 * time) * 0.45
        )
        swell = math.sin(math.pi * progress)
        return chord * envelope * swell * 0.2

    def _minigame_success_sample(self, time: float, progress: float) -> float:
        frequency = 660.0 if progress < 0.45 else 880.0
        envelope = min(1.0, progress * 24.0) * (1.0 - progress) ** 1.8
        tone = math.sin(2.0 * math.pi * frequency * time)
        overtone = math.sin(2.0 * math.pi * frequency * 2.0 * time) * 0.2
        return (tone + overtone) * envelope * 0.22

    def _minigame_failure_sample(self, time: float, progress: float) -> float:
        frequency = 310.0 - 140.0 * progress
        envelope = (1.0 - progress) ** 1.5
        tone = math.sin(2.0 * math.pi * frequency * time)
        lower_tone = math.sin(2.0 * math.pi * frequency * 0.5 * time) * 0.3
        return (tone + lower_tone) * envelope * 0.2

    def play(self, effect: str):
        if self.enabled and effect in self.sounds:
            self.sounds[effect].play()

    def update(self, dt: float, walking: bool):
        if not self.enabled:
            return
        if not walking:
            self._step_timer = 0.0
            return
        self._step_timer += dt
        if self._step_timer >= 0.42:
            self._step_timer %= 0.42
            self.play("footstep")


class BackgroundMusic:
    '''Stream and crossfade the supplied background music tracks.'''

    TRACKS = {
        "title": "04 8am _ Towballs Crossing.ogg",
        "survival": "06 The Tax Office.ogg",
        "departure": "04 Island Life (Loopable Version).ogg",
    }

    def __init__(self):
        mixer_format = pygame.mixer.get_init()
        self.enabled = mixer_format is not None
        self.sound_directory = Path(__file__).parent / "assets" / "sound"
        self.current_track = None
        self.pending_track = None
        self.pending_fade_ms = 0
        self.waiting_for_fade = False
        self.retry_timer = 0.0
        self.volume = 0.16
        if self.enabled:
            pygame.mixer.music.set_volume(self.volume)

    def play(self, track: str, fade_ms: int = 1800):
        if not self.enabled or track not in self.TRACKS:
            return
        if (
            track == self.current_track
            and self.pending_track is None
            and pygame.mixer.music.get_busy()
        ):
            return

        self.pending_track = track
        self.pending_fade_ms = max(0, fade_ms)
        if pygame.mixer.music.get_busy() and fade_ms > 0:
            pygame.mixer.music.fadeout(fade_ms)
            self.waiting_for_fade = True
        else:
            self._start_pending_track()

    def _start_pending_track(self):
        if self.pending_track is None:
            return
        filename = self.TRACKS[self.pending_track]
        pygame.mixer.music.load(str(self.sound_directory / filename))
        pygame.mixer.music.set_volume(self.volume)
        pygame.mixer.music.play(loops=-1, fade_ms=self.pending_fade_ms)
        self.current_track = self.pending_track
        self.pending_track = None
        self.waiting_for_fade = False

    def update(self, dt: float = 0.0):
        self.retry_timer = max(0.0, self.retry_timer - dt)
        if (
            self.enabled
            and self.waiting_for_fade
            and not pygame.mixer.music.get_busy()
        ):
            self._start_pending_track()

    def ensure_playing(self, track: str):
        if not self.enabled or self.pending_track is not None:
            return
        if track != self.current_track:
            self.play(track, fade_ms=0)
        elif not pygame.mixer.music.get_busy() and self.retry_timer <= 0.0:
            self.play(track, fade_ms=0)
            self.retry_timer = 0.75

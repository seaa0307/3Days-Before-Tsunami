'''Sprite-sheet loading helpers for the game image assets.'''

from functools import lru_cache
from pathlib import Path
from typing import Optional, Union

import pygame


IMAGE_DIRS = [
    Path(__file__).parent / "assets" / "images",
    Path(__file__).parent / "assets" / "fonts" / "images",
]
IMAGE_DIR = IMAGE_DIRS[0] if IMAGE_DIRS[0].is_dir() else IMAGE_DIRS[1]


def resolve_image_path(filename: str) -> Path:
    '''Resolve an image filename across candidate asset directories.'''
    for directory in IMAGE_DIRS:
        candidate = directory / filename
        if candidate.is_file():
            return candidate
    return IMAGE_DIR / filename


@lru_cache(maxsize=None)
def load_image(filename: str) -> pygame.Surface:
    '''Load an image from the project image asset directory.'''
    path = resolve_image_path(filename)
    return pygame.image.load(str(path))


@lru_cache(maxsize=None)
def get_sprite_frames(
    filename: str,
    frame_width: int,
    frame_height: int,
    spacing: int = 0,
) -> tuple[pygame.Surface, ...]:
    '''Slice a uniform sprite sheet into frames.'''
    if frame_width <= 0 or frame_height <= 0 or spacing < 0:
        raise ValueError("Frame dimensions must be positive and spacing cannot be negative.")

    image = load_image(filename)
    columns = (image.get_width() + spacing) // (frame_width + spacing)
    rows = (image.get_height() + spacing) // (frame_height + spacing)
    if columns < 1 or rows < 1:
        raise ValueError(f"{filename} is smaller than the requested sprite frame.")
    if (
        (columns - 1) * (frame_width + spacing) + frame_width != image.get_width()
        or (rows - 1) * (frame_height + spacing) + frame_height != image.get_height()
    ):
        raise ValueError(f"{filename} dimensions do not match the requested sprite layout.")

    frames = []
    for row in range(rows):
        for column in range(columns):
            x = column * (frame_width + spacing)
            y = row * (frame_height + spacing)
            if x + frame_width <= image.get_width() and y + frame_height <= image.get_height():
                frames.append(image.subsurface((x, y, frame_width, frame_height)).copy())
    return tuple(frames)


# =========================================================================
# 타일셋 로딩: 106x106 이미지에서 16x16 타일 (spacing=2, 6x6=36개)
# =========================================================================

@lru_cache(maxsize=None)
def get_tileset_frames(filename: str = "tileset.png") -> tuple[pygame.Surface, ...]:
    '''Get all 36 (6x6) 16x16 tiles from a tileset image with 2px spacing.'''
    return get_sprite_frames(filename, 16, 16, spacing=2)


def get_tileset_tile(
    column: int,
    row: int,
    filename: str = "tileset.png",
) -> pygame.Surface:
    '''Get one 16x16 tile from a tileset sheet (6x6 layout with 2px spacing).'''
    if not (0 <= column < 6 and 0 <= row < 6):
        raise IndexError(f"Tileset coordinates ({column}, {row}) must be between 0 and 5.")
    return get_tileset_frames(filename)[row * 6 + column]


# =========================================================================
# 아이템 스프라이트: items.png 내 실제 픽셀 좌표 바운딩 렉트
# =========================================================================

ITEM_SPRITE_RECTS: dict[str, pygame.Rect] = {
    # 덤불 및 식물
    "berry_bush": pygame.Rect(0, 0, 16, 16),
    "berry_bush_empty": pygame.Rect(18, 0, 16, 16),
    "berry": pygame.Rect(36, 2, 14, 12),
    "plant_fiber": pygame.Rect(54, 2, 13, 12),
    "plant_fiber_alt": pygame.Rect(70, 2, 13, 12),
    # 돌 변종
    "stone": pygame.Rect(86, 4, 10, 7),
    "stone_2": pygame.Rect(100, 4, 11, 8),
    "stone_3": pygame.Rect(115, 3, 11, 9),
    # 자원 및 도구
    "wood_log": pygame.Rect(0, 19, 16, 15),
    "branch": pygame.Rect(21, 21, 12, 10),
    "coconut": pygame.Rect(37, 20, 12, 12),
    "torch": pygame.Rect(52, 20, 12, 13),
    "stone_axe": pygame.Rect(68, 20, 16, 13),
    "rope": pygame.Rect(86, 18, 16, 15),
    "cloth": pygame.Rect(107, 18, 16, 15),
    # 큰 구조물 및 야자수
    "palm_tree": pygame.Rect(1, 37, 30, 41),
    "palm_tree_coconut": pygame.Rect(33, 38, 30, 41),
    "shelter": pygame.Rect(97, 57, 30, 24),
    "stump": pygame.Rect(74, 67, 16, 13),
    "stump_alt": pygame.Rect(73, 111, 16, 13),
    "sea_item": pygame.Rect(74, 67, 16, 13),
}

# 기존 그리드 셀 좌표 호환 매핑: (col, row) -> key
_CELL_TO_KEY: dict[tuple[int, int], str] = {
    (0, 0): "berry_bush",
    (1, 0): "berry_bush_empty",
    (2, 0): "berry",
    (3, 0): "plant_fiber",
    (4, 0): "plant_fiber_alt",
    (5, 0): "stone",
    (6, 0): "stone_2",
    (7, 0): "stone_3",
    (0, 1): "wood_log",
    (1, 1): "branch",
    (2, 1): "coconut",
    (3, 1): "torch",
    (4, 1): "stone_axe",
    (5, 1): "rope",
    (7, 1): "cloth",
}


@lru_cache(maxsize=None)
def get_item_surface(
    name: str,
    centered_16x16: bool = True,
) -> pygame.Surface:
    '''
    Load an individual item sprite cleanly without pixel bleeding from adjacent items.
    If centered_16x16 is True and the sprite fits within 16x16, returns a 16x16 Surface
    with the item centered.
    '''
    if name == "campfire":
        return get_campfire_frames()[0]

    rect = ITEM_SPRITE_RECTS.get(name)
    if rect is None:
        raise KeyError(f"Unknown item sprite: '{name}'. Available: {list(ITEM_SPRITE_RECTS.keys())}")

    image = load_image("items.png")
    sub = image.subsurface(rect).copy()

    # 작은 아이템의 경우 16x16 규격 투명 캔버스 중앙에 정렬하여 반환
    if centered_16x16 and rect.width <= 16 and rect.height <= 16:
        canvas = pygame.Surface((16, 16), pygame.SRCALPHA)
        ox = (16 - rect.width) // 2
        oy = (16 - rect.height) // 2
        canvas.blit(sub, (ox, oy))
        return canvas

    return sub


def get_item_sprite(
    column_or_key: Union[int, str],
    row: int = 0,
    width_cells: int = 1,
    height_cells: int = 1,
) -> pygame.Surface:
    '''
    Get an item sprite by key or by legacy grid coordinates.
    Maintains backwards compatibility while eliminating pixel bleeding.
    '''
    if isinstance(column_or_key, str):
        return get_item_surface(column_or_key)

    column = column_or_key
    # 야자수 (col 0, row 2, w 2, h 3 or col 2, row 2, w 2, h 3)
    if row == 2 and width_cells == 2 and height_cells == 3:
        return get_item_surface("palm_tree_coconut" if column == 0 else "palm_tree", centered_16x16=False)

    # 간이 거처 (col 6, row 3, w 2, h 2)
    if (column, row) == (6, 3) and width_cells == 2 and height_cells == 2:
        return get_item_surface("shelter", centered_16x16=False)

    # 일반 셀 좌표 매핑 확인
    key = _CELL_TO_KEY.get((column, row))
    if key:
        return get_item_surface(key)

    # fallback: safe clamp within items.png
    image = load_image("items.png")
    x = max(0, min(image.get_width() - 16, column * 16))
    y = max(0, min(image.get_height() - 16, row * 16))
    w = min(width_cells * 16, image.get_width() - x)
    h = min(height_cells * 16, image.get_height() - y)
    return image.subsurface((x, y, w, h)).copy()


# =========================================================================
# 모닥불 애니메이션: campfire.png (52x16 -> 3프레임 각 16x16, spacing=2)
# =========================================================================

@lru_cache(maxsize=None)
def get_campfire_frames() -> tuple[pygame.Surface, ...]:
    '''Get the 3 animation frames (16x16 each, 2px spacing) from campfire.png.'''
    return get_sprite_frames("campfire.png", 16, 16, spacing=2)


# =========================================================================
# 플레이어 스프라이트: 64x17 (4프레임 각 16x17, 방향별)
# =========================================================================

@lru_cache(maxsize=None)
def get_player_frames(direction: str) -> tuple[pygame.Surface, ...]:
    '''Get the walking frames (16x17 each) for a player direction.'''
    filenames = {
        "down": "player_front.png",
        "up": "player_back.png",
        "left": "player_right.png",
        "right": "player_left.png",
    }
    if direction not in filenames:
        raise ValueError(f"Unknown direction '{direction}'. Expected one of {list(filenames.keys())}")
    return get_sprite_frames(filenames[direction], 16, 17)


# =========================================================================
# 도끼질(Axe chopping) 애니메이션: Axe_front, back, left, right (24x24 프레임)
# =========================================================================

@lru_cache(maxsize=None)
def get_axe_frames(direction: str) -> tuple[pygame.Surface, ...]:
    '''
    Get the axe chopping animation frames (24x24 each) for a player direction.
    Only non-empty active frames are returned.
    '''
    filenames = {
        "down": "Axe_front.png",
        "up": "Axe_back.png",
        "left": "Axe_left.png",
        "right": "Axe_right.png",
    }
    if direction not in filenames:
        raise ValueError(f"Unknown direction '{direction}'. Expected one of {list(filenames.keys())}")

    image = load_image(filenames[direction])
    frame_width = 24
    frame_height = 24
    frames = []
    columns = image.get_width() // frame_width
    for col in range(columns):
        sub = image.subsurface((col * frame_width, 0, frame_width, frame_height))
        # 4번째 등 완전히 비어있는 투명 프레임은 건너뜀
        if sub.get_bounding_rect().width > 0:
            frames.append(sub.copy())

    if not frames:
        frames.append(pygame.Surface((24, 24), pygame.SRCALPHA))
    return tuple(frames)


# =========================================================================
# 비율 보존 스케일링 헬퍼
# =========================================================================

def scale_pixel_art(surface: pygame.Surface, factor: int = 3) -> pygame.Surface:
    '''Scale a pixel art surface by an integer factor using nearest-neighbor.'''
    if factor == 1:
        return surface
    return pygame.transform.scale(
        surface,
        (surface.get_width() * factor, surface.get_height() * factor),
    )


def fit_sprite(sprite: pygame.Surface, size: tuple[int, int]) -> pygame.Surface:
    '''
    Fit a sprite within a given canvas size while strictly preserving its original aspect ratio.
    Centers the sprite without distortion.
    '''
    if sprite.get_width() == 0 or sprite.get_height() == 0:
        return pygame.Surface(size, pygame.SRCALPHA)

    # 원본 종횡비 유지 스케일 계산
    scale = min(size[0] / sprite.get_width(), size[1] / sprite.get_height())
    new_w = max(1, round(sprite.get_width() * scale))
    new_h = max(1, round(sprite.get_height() * scale))

    scaled = pygame.transform.scale(sprite, (new_w, new_h))
    fitted = pygame.Surface(size, pygame.SRCALPHA)
    fitted.blit(scaled, ((size[0] - new_w) // 2, (size[1] - new_h) // 2))
    return fitted

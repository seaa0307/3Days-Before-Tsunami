"""
해일 전 5일 (5 Days Before Tsunami)
설치형 생존 구조물 (모닥불, 간이 거처) 모듈
"""

import math
import random
import pygame
from settings import (
    COLOR_SHADOW,
    COLOR_TREE_TRUNK,
    CAMPFIRE_WARMTH_RADIUS,
    CAMPFIRE_LIGHT_RADIUS,
    SHELTER_SLEEP_HEALTH_RECOVER,
    SLEEP_DISABLED_DAY,
)


class PlacedCampfire:
    """월드에 설치되어 빛을 밝히고 주변 체온을 회복시켜 주는 모닥불"""

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.width = 44
        self.height = 36
        self.warmth_radius = CAMPFIRE_WARMTH_RADIUS
        self.light_radius = CAMPFIRE_LIGHT_RADIUS
        self.is_active = True

        # 작은 충돌 박스
        self.hitbox = pygame.Rect(x + 8, y + 14, 28, 18)
        self.anim_timer = 0.0

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def is_player_near(self, player) -> bool:
        """플레이어가 온기를 느낄 수 있는 반경 안에 있는지 검사"""
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.warmth_radius

    def can_interact(self, player) -> bool:
        return self.is_player_near(player)

    def get_prompt(self, player) -> str:
        return "[모닥불] 따뜻한 온기가 느껴집니다. (체온 회복 중)"

    def interact(self, player) -> tuple:
        return False, "", 0, "모닥불이 따뜻하게 타오르고 있습니다."

    def update(self, dt: float):
        self.anim_timer += dt * 8.0

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 바닥 그림자 및 돌 둘레
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 2, screen_y + 18, 40, 14))

        # 2. 둘러싼 돌멩이들
        stones = [(6, 22), (14, 26), (24, 26), (32, 22), (28, 14), (10, 14)]
        for sx, sy in stones:
            pygame.draw.circle(target_surface, (110, 115, 125), (screen_x + sx, screen_y + sy), 4)
            pygame.draw.circle(target_surface, (80, 85, 95), (screen_x + sx, screen_y + sy), 4, 1)

        # 3. 십자 장작
        pygame.draw.line(target_surface, (90, 60, 40), (screen_x + 10, screen_y + 16), (screen_x + 32, screen_y + 26), 4)
        pygame.draw.line(target_surface, (110, 75, 45), (screen_x + 12, screen_y + 26), (screen_x + 30, screen_y + 16), 4)

        # 4. 활활 타오르는 불꽃 애니메이션
        flicker_h = int(math.sin(self.anim_timer) * 3)
        flame_pts = [
            (screen_x + 22, screen_y + 6 + flicker_h),
            (screen_x + 32, screen_y + 22),
            (screen_x + 22, screen_y + 20),
            (screen_x + 12, screen_y + 22),
        ]
        pygame.draw.polygon(target_surface, (245, 90, 30), flame_pts)
        inner_flame = [
            (screen_x + 22, screen_y + 10 + flicker_h),
            (screen_x + 28, screen_y + 21),
            (screen_x + 16, screen_y + 21),
        ]
        pygame.draw.polygon(target_surface, (255, 215, 60), inner_flame)


class PlacedShelter:
    """
    월드에 설치되어 비바람을 막고 밤 동안 잠을 잘 수 있는 간이 거처
    - 밤에 수면 시: 남은 밤을 건너뛰고 다음 날 아침으로 진행 + 체력 15 회복
    - 5일 차에는 해일 임박으로 수면 불가
    """

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.width = 64
        self.height = 54
        self.is_active = True

        # 고체 충돌 히트박스 (거처 바닥면)
        self.hitbox = pygame.Rect(x + 6, y + 22, 52, 28)
        self.interaction_radius = 65

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def can_interact(self, player) -> bool:
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player, time_system) -> str:
        if time_system.current_day >= SLEEP_DISABLED_DAY:
            return "[간이 거처] 5일 차에는 해일이 다가와 잠을 잘 수 없습니다!"
        if time_system.is_night:
            return "[E] 간이 거처에서 잠자기 (남은 밤 넘기기, 체력 +15)"
        else:
            return "[간이 거처] 밤에만 잠을 잘 수 있습니다."

    def interact(self, player, time_system) -> tuple:
        """
        [E] 상호작용 시 수면 로직 실행
        반환: (성공여부: bool, 결과메시지: str)
        """
        if time_system.current_day >= SLEEP_DISABLED_DAY:
            return False, "5일 차에는 해일이 임박하여 잠을 잘 수 없습니다!"

        if not time_system.is_night:
            return False, "아직 낮입니다. 밤에만 잠을 잘 수 있습니다."

        # 밤 넘기기 실행
        success, msg = time_system.skip_night()
        if success:
            healed = player.survival.apply_sleep_recovery()
            return True, f"잠을 자고 일어났습니다! [다음 날 아침, 체력 +{int(healed)} 회복]"
        return False, msg

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 바닥 그림자
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 4, screen_y + 36, 56, 16))

        # 2. A자형 나무 기둥 프레임
        pygame.draw.line(target_surface, (90, 60, 35), (screen_x + 32, screen_y + 6), (screen_x + 8, screen_y + 44), 5)
        pygame.draw.line(target_surface, (90, 60, 35), (screen_x + 32, screen_y + 6), (screen_x + 56, screen_y + 44), 5)
        pygame.draw.line(target_surface, (120, 80, 50), (screen_x + 10, screen_y + 42), (screen_x + 54, screen_y + 42), 4)

        # 3. 직물/천 지붕 (삼각형 텐트 차양)
        tent_pts = [
            (screen_x + 32, screen_y + 8),
            (screen_x + 54, screen_y + 40),
            (screen_x + 10, screen_y + 40),
        ]
        pygame.draw.polygon(target_surface, (190, 175, 150), tent_pts)
        pygame.draw.polygon(target_surface, (225, 215, 195), [
            (screen_x + 32, screen_y + 9),
            (screen_x + 52, screen_y + 39),
            (screen_x + 32, screen_y + 39),
        ])

        # 4. 거처 입구 (어두운 실내)
        door_pts = [
            (screen_x + 32, screen_y + 18),
            (screen_x + 42, screen_y + 40),
            (screen_x + 22, screen_y + 40),
        ]
        pygame.draw.polygon(target_surface, (35, 28, 22), door_pts)

        # 5. 밧줄 묶음 표현
        pygame.draw.circle(target_surface, (180, 150, 100), (screen_x + 32, screen_y + 8), 3)

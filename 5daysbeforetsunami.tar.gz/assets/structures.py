'''
해일 전 3일 (3 Days Before Tsunami)
설치형 생존 구조물 (모닥불, 간이 거처) 모듈
'''

import math
import random
import pygame
from image_assets import get_campfire_frames, get_item_surface, scale_pixel_art
from settings import (
    COLOR_SHADOW,
    CAMPFIRE_WARMTH_RADIUS,
    CAMPFIRE_LIGHT_RADIUS,
    SHELTER_SLEEP_HEALTH_RECOVER,
    SLEEP_DISABLED_DAY,
)


class PlacedCampfire:
    '''월드에 설치되어 빛을 밝히고 주변 체온을 회복시켜 주는 모닥불 (스프라이트 애니메이션)'''

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        # 원본 16x16 픽셀을 3배 정수 스케일하여 48x48 픽셀로 구성
        self.width = 48
        self.height = 48
        self.warmth_radius = CAMPFIRE_WARMTH_RADIUS
        self.light_radius = CAMPFIRE_LIGHT_RADIUS
        self.is_active = True

        # 바닥 히트박스
        self.hitbox = pygame.Rect(x + 6, y + 20, 36, 24)
        self.anim_timer = 0.0
        self.frame_index = 0

        # campfire.png의 3개 16x16 프레임을 3배 정수 확대
        self.frames = tuple(scale_pixel_art(frame, 3) for frame in get_campfire_frames())

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def is_player_near(self, player) -> bool:
        '''플레이어가 온기를 느낄 수 있는 반경 안에 있는지 검사'''
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.warmth_radius

    def can_interact(self, player) -> bool:
        return self.is_player_near(player)

    def get_prompt(self, player) -> str:
        return "[모닥불] 따뜻한 온기가 느껴집니다. (체온 회복 중)"

    def interact(self, player) -> tuple:
        return False, "", 0, "모닥불이 따뜻하게 타오르고 있습니다."

    def update(self, dt: float):
        '''모닥불 불꽃 애니메이션 프레임 갱신 (초당 6프레임)'''
        self.anim_timer += dt * 6.0
        self.frame_index = int(self.anim_timer) % len(self.frames)

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 바닥 그림자
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 4, screen_y + 24, 40, 18))

        # 2. 애니메이션 프레임 스프라이트 렌더링
        frame = self.frames[self.frame_index]
        target_surface.blit(frame, (screen_x, screen_y))


class PlacedShelter:
    '''
    월드에 설치되어 비바람을 막고 밤 동안 잠을 잘 수 있는 간이 거처
    - 밤에 수면 시: 남은 밤을 건너뛰고 다음 날 아침으로 진행 + 체력 15 회복
    - 3일 차에는 해일 임박으로 수면 불가
    '''

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        # 원본 30x24 픽셀을 3배 정수 스케일하여 90x72 픽셀로 구성 (비율 보존)
        self.width = 90
        self.height = 72
        self.is_active = True

        # 고체 충돌 히트박스 (거처 바닥면)
        self.hitbox = pygame.Rect(x + 10, y + 36, 70, 32)
        self.interaction_radius = 75
        self.surface = scale_pixel_art(get_item_surface("shelter"), 3)

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def can_interact(self, player) -> bool:
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player, time_system) -> str:
        if time_system.current_day >= SLEEP_DISABLED_DAY:
            return "[간이 거처] 3일 차에는 해일이 다가와 잠을 잘 수 없습니다!"
        if time_system.is_night:
            return "[좌클릭] 간이 거처에서 잠자기 (남은 밤 넘기기, 체력 +15)"
        else:
            return "[간이 거처] 밤에만 잠을 잘 수 있습니다."

    def interact(self, player, time_system) -> tuple:
        '''
        마우스 왼쪽 클릭 시 수면 로직 실행
        반환: (성공여부: bool, 결과메시지: str)
        '''
        if time_system.current_day >= SLEEP_DISABLED_DAY:
            return False, "3일 차에는 해일이 임박하여 잠을 잘 수 없습니다!"

        if not time_system.is_night:
            return False, "아직 낮입니다. 밤에만 잠을 잘 수 있습니다."

        # 밤 넘기기 실행
        success, msg = time_system.skip_night()
        if success:
            healed = player.survival.apply_sleep_recovery()
            return True, f"잠을 자고 일어났습니다! [다음 날 아침, 체력 +{int(healed)} 회복]"
        return False, msg

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))

'''Final raft construction, boarding, and escape ending.'''

import math
import pygame
from typing import Optional

from fonts import get_font
from image_assets import load_image, scale_pixel_art
from settings import SCREEN_HEIGHT, SCREEN_WIDTH


def _draw_raft_with_sail(
    surface: pygame.Surface,
    raft_surface: pygame.Surface,
    sail_surface: pygame.Surface,
    raft_x: int,
    raft_y: int,
    sail_reveal: float = 1.0,
):
    '''Draw the sail so the mast foot meets the center of the raft.'''
    surface.blit(raft_surface, (raft_x, raft_y))
    if sail_reveal <= 0:
        return

    scale = sail_surface.get_width() / 48
    mast_foot_x = round(24 * scale)
    mast_foot_y = round(46 * scale)
    mast_target_x = raft_x + raft_surface.get_width() // 2
    mast_target_y = raft_y + raft_surface.get_height() // 2
    sail_x = mast_target_x - mast_foot_x
    sail_y = mast_target_y - mast_foot_y

    reveal_height = round(sail_surface.get_height() * min(1.0, sail_reveal))
    if reveal_height:
        surface.blit(
            sail_surface,
            (sail_x, sail_y),
            pygame.Rect(0, 0, sail_surface.get_width(), reveal_height),
        )


class RaftSlipway:
    '''A fixed south-coast build site for the raft and its sail.'''

    WIDTH = 84
    HEIGHT = 72

    def __init__(self, x: int, y: int):
        self.x = float(x)
        self.y = float(y)
        self.width = self.WIDTH
        self.height = self.HEIGHT
        self.has_base_raft = False
        self.has_sail = False
        self.is_departed = False
        self.wave_timer = 0.0
        self.interaction_radius = 86
        self.hitbox = pygame.Rect(int(x), int(y), self.width, self.height)
        self.raft_surface = scale_pixel_art(load_image("raft.png"), 2)
        self.sail_surface = scale_pixel_art(load_image("sail.png"), 2)

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width / 2, self.y + self.height / 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    @property
    def is_fully_assembled(self) -> bool:
        return self.has_base_raft and self.has_sail

    def can_interact(self, player) -> bool:
        if self.is_departed:
            return False
        player_center = pygame.Vector2(player.hitbox.center)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        if self.is_departed:
            return ""
        if not self.has_base_raft:
            if player.inventory.has_item("base_raft"):
                return "[퀵슬롯에서 기본 뗏목 선택 후 좌클릭으로 설치]"
            return "[뗏목 설치 장소] 기본 뗏목 제작 필요 (원목 10, 밧줄 4, 돌 3)"
        if not self.has_sail:
            if player.inventory.has_item("sail"):
                return "[퀵슬롯에서 돛 선택 후 좌클릭으로 장착]"
            return "[뗏목 설치 장소] 돛 제작 필요 (원목 2, 밧줄 2, 돛천 1)"
        return "[좌클릭] 완성된 뗏목에 탑승하여 출항하기"

    def interact(self, player, selected_item: Optional[str] = None) -> tuple[bool, str, str]:
        if self.is_departed:
            return False, "DEPARTED", "뗏목은 이미 출항했습니다."

        if not self.has_base_raft:
            if selected_item != "base_raft":
                return False, "SELECT_BASE", "퀵슬롯에서 기본 뗏목을 선택한 뒤 설치 장소를 클릭하세요."
            if not player.inventory.remove_item("base_raft"):
                return False, "MISSING_BASE", "기본 뗏목을 먼저 제작해야 합니다."
            self.has_base_raft = True
            return True, "INSTALL_BASE", "기본 뗏목을 바다 앞 설치 장소에 설치했습니다."

        if not self.has_sail:
            if selected_item != "sail":
                return False, "SELECT_SAIL", "퀵슬롯에서 돛을 선택한 뒤 뗏목을 클릭하세요."
            if not player.inventory.remove_item("sail"):
                return False, "MISSING_SAIL", "돛을 먼저 제작해야 합니다."
            self.has_sail = True
            return True, "INSTALL_SAIL", "돛을 장착했습니다. 이제 뗏목에 탑승할 수 있습니다!"

        self.is_departed = True
        return True, "BOARD_ESCAPE", "뗏목에 탑승했습니다. 바다를 향해 출항합니다!"

    def update(self, dt: float):
        self.wave_timer += dt * 3.0

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        bob = int(math.sin(self.wave_timer) * 2)

        if not self.has_base_raft:
            for offset in (12, 31, 50):
                pygame.draw.line(
                    target_surface,
                    (120, 83, 48),
                    (screen_x + 8, screen_y + offset),
                    (screen_x + self.width - 8, screen_y + offset),
                    4,
                )
            return

        raft_x = screen_x + (self.width - self.raft_surface.get_width()) // 2
        raft_y = screen_y + (self.height - self.raft_surface.get_height()) // 2 + bob
        if self.has_sail:
            _draw_raft_with_sail(
                target_surface,
                self.raft_surface,
                self.sail_surface,
                raft_x,
                raft_y,
            )
        else:
            target_surface.blit(self.raft_surface, (raft_x, raft_y))


class RaftEscapeCutscene:
    '''A short animated departure that ends on a permanent victory screen.'''

    DURATION = 16.0

    def __init__(self):
        self.is_active = False
        self.timer = 0.0
        self.is_finished = False
        self.raft_surface = scale_pixel_art(load_image("raft.png"), 3)
        self.sail_surface = scale_pixel_art(load_image("sail.png"), 3)

    def start(self):
        self.is_active = True
        self.is_finished = False
        self.timer = 0.0

    def update(self, dt: float):
        if not self.is_active:
            return
        self.timer = min(self.DURATION, self.timer + dt)
        self.is_finished = self.timer >= self.DURATION

    def _draw_ocean(self, surface: pygame.Surface):
        surface.fill((24, 76, 112))
        for row in range(10):
            y = 28 + row * 54
            color = (42, 105, 145) if row % 2 == 0 else (34, 91, 132)
            for x in range(-30, SCREEN_WIDTH + 30, 90):
                wave_x = x + int(math.sin(self.timer * 1.4 + row) * 18)
                wave_y = y + int(math.sin(self.timer * 2.0 + x * 0.02) * 5)
                pygame.draw.arc(surface, color, (wave_x, wave_y, 54, 18), 0.2, 2.8, 3)

    def _draw_island(self, surface: pygame.Surface):
        '''Paint the island behind the raft so the tsunami can visibly engulf it.'''
        island = pygame.Surface((350, 180), pygame.SRCALPHA)
        pygame.draw.ellipse(island, (28, 63, 76), (10, 74, 330, 100))
        pygame.draw.ellipse(island, (217, 190, 119), (18, 63, 314, 106))
        pygame.draw.ellipse(island, (83, 133, 69), (42, 75, 266, 80))

        for x, y, height in ((101, 105, 34), (175, 82, 49), (247, 106, 32)):
            pygame.draw.line(island, (106, 73, 43), (x, y + height), (x - 4, y), 5)
            crown_x, crown_y = x - 4, y
            for dx, dy in ((-23, -12), (-17, -21), (-5, -24), (10, -21), (23, -12)):
                pygame.draw.line(
                    island,
                    (44, 105, 57),
                    (crown_x, crown_y),
                    (crown_x + dx, crown_y + dy),
                    6,
                )
                pygame.draw.line(
                    island,
                    (101, 157, 72),
                    (crown_x, crown_y),
                    (crown_x + dx, crown_y + dy),
                    2,
                )

        pygame.draw.polygon(island, (101, 75, 53), [(147, 120), (175, 91), (203, 120)])
        pygame.draw.polygon(island, (220, 205, 165), [(153, 117), (175, 97), (197, 117)])
        pygame.draw.rect(island, (92, 63, 43), (171, 109, 9, 12))
        pygame.draw.ellipse(island, (93, 143, 69), (72, 126, 19, 9))
        pygame.draw.ellipse(island, (93, 143, 69), (255, 131, 23, 8))
        surface.blit(island, ((SCREEN_WIDTH - island.get_width()) // 2, 18))

    def _draw_tsunami(self, surface: pygame.Surface):
        '''Move the tsunami down from the top of the screen and over the island.'''
        progress = min(1.0, max(0.0, (self.timer - 8.5) / 5.0))
        front_y = int(-80 + progress * 350)
        wave_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)

        crest_points = []
        for x in range(-24, SCREEN_WIDTH + 25, 24):
            crest_y = front_y + int(math.sin(x * 0.035 + self.timer * 4.5) * 12)
            crest_points.append((x, crest_y))

        water_shape = [(0, 0), (SCREEN_WIDTH, 0)] + list(reversed(crest_points))
        pygame.draw.polygon(wave_surface, (15, 70, 111, 244), water_shape)

        # Deep bands, foam, and spray make the advancing edge read as a wave.
        band_y = max(0, front_y - 34)
        pygame.draw.line(wave_surface, (31, 102, 143, 210), (0, band_y), (SCREEN_WIDTH, band_y + 4), 12)
        for x, crest_y in crest_points:
            pygame.draw.ellipse(
                wave_surface,
                (219, 242, 239, 245),
                (x - 15, crest_y - 5, 33, 14),
            )
            pygame.draw.ellipse(
                wave_surface,
                (104, 187, 207, 225),
                (x - 9, crest_y + 3, 25, 8),
            )

        spray_phase = self.timer * 31
        for index in range(34):
            x = (index * 83 + int(spray_phase * (1 + index % 3))) % SCREEN_WIDTH
            y = front_y - 12 - (index * 29 % 70)
            radius = 2 + index % 4
            pygame.draw.circle(wave_surface, (226, 246, 245, 220), (x, y), radius)

        surface.blit(wave_surface, (0, 0))

    def draw(self, surface: pygame.Surface, camera=None):
        if not self.is_active:
            return

        self._draw_ocean(surface)
        title_font = get_font(28, bold=True)
        subtitle_font = get_font(16)

        if self.timer < 13.5:
            travel = min(1.0, self.timer / 13.5)
            raft_x = (SCREEN_WIDTH - self.raft_surface.get_width()) // 2
            raft_y = int(SCREEN_HEIGHT * 0.35 + travel * 95 + math.sin(self.timer * 4) * 4)

            if self.timer < 4.5:
                surface.blit(self.raft_surface, (raft_x, raft_y))
                title, subtitle = "뗏목 출항", "섬을 뒤로하고 바다를 향해 나아갑니다."
            elif self.timer < 8.5:
                unfurl = min(1.0, (self.timer - 4.5) / 2.5)
                _draw_raft_with_sail(
                    surface,
                    self.raft_surface,
                    self.sail_surface,
                    raft_x,
                    raft_y,
                    sail_reveal=unfurl,
                )
                title, subtitle = "돛을 펼치다", "바람을 받은 돛이 뗏목을 앞으로 밀어줍니다."
            else:
                self._draw_island(surface)
                storm_dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
                storm_dim.fill((14, 28, 49, 70))
                surface.blit(storm_dim, (0, 0))
                self._draw_tsunami(surface)

                _draw_raft_with_sail(
                    surface,
                    self.raft_surface,
                    self.sail_surface,
                    raft_x,
                    raft_y,
                )
                title, subtitle = "해일을 벗어나다", "섬을 덮치는 해일을 뒤로하고 반대 방향으로 나아갑니다."

            banner = pygame.Rect(40, SCREEN_HEIGHT - 104, SCREEN_WIDTH - 80, 68)
            pygame.draw.rect(surface, (10, 20, 32), banner, border_radius=8)
            pygame.draw.rect(surface, (140, 200, 235), banner, 2, border_radius=8)
            title = title_font.render(title, True, (255, 220, 115))
            subtitle = subtitle_font.render(subtitle, True, (240, 245, 250))
            surface.blit(title, (banner.x + 18, banner.y + 8))
            surface.blit(subtitle, (banner.x + 18, banner.y + 42))
            return

        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((6, 18, 35, 225))
        surface.blit(overlay, (0, 0))

        panel = pygame.Rect(150, 105, SCREEN_WIDTH - 300, 330)
        pygame.draw.rect(surface, (20, 32, 50), panel, border_radius=12)
        pygame.draw.rect(surface, (245, 200, 75), panel, 2, border_radius=12)
        title = title_font.render("해일 전 3일 - 탈출 성공!", True, (255, 215, 80))
        surface.blit(title, (panel.centerx - title.get_width() // 2, panel.y + 38))

        lines = (
            "완성한 뗏목과 돛으로 거대한 해일을 피해",
            "섬을 벗어나 안전한 바다로 탈출했습니다.",
            "",
            "생존 성공",
        )
        body_font = get_font(18, bold=True)
        for index, line in enumerate(lines):
            if line:
                text = body_font.render(line, True, (230, 238, 248))
                surface.blit(text, (panel.centerx - text.get_width() // 2, panel.y + 112 + index * 38))
        hint_font = get_font(14, bold=True)
        hint = hint_font.render("Enter 또는 클릭: 타이틀 화면으로", True, (245, 220, 150))
        surface.blit(hint, (panel.centerx - hint.get_width() // 2, panel.bottom - 34))

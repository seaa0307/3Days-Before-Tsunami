'''Final raft construction, boarding, and escape ending.'''

import math
import pygame
from typing import Optional

from fonts import get_font
from image_assets import get_tileset_tile, load_image, scale_pixel_art
from settings import (
    COLOR_UI_ACCENT,
    COLOR_UI_DARK,
    COLOR_UI_EDGE,
    COLOR_UI_LIGHT,
    COLOR_UI_TEXT,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    TILE_SIZE,
)


def _draw_raft_with_sail(
    surface: pygame.Surface,
    raft_surface: pygame.Surface,
    sail_surface: pygame.Surface,
    raft_x: int,
    raft_y: int,
    sail_reveal: float = 1.0,
):
    '''Draw the sail so the mast foot meets the center of the raft.'''
    surface.blit(raft_surface, (raft_x, raft_y))
    if sail_reveal <= 0:
        return

    scale = sail_surface.get_width() / 48
    mast_foot_x = round(24 * scale)
    mast_foot_y = round(46 * scale)
    mast_target_x = raft_x + raft_surface.get_width() // 2
    mast_target_y = raft_y + raft_surface.get_height() // 2
    sail_x = mast_target_x - mast_foot_x
    sail_y = mast_target_y - mast_foot_y

    reveal_height = round(sail_surface.get_height() * min(1.0, sail_reveal))
    if reveal_height:
        surface.blit(
            sail_surface,
            (sail_x, sail_y),
            pygame.Rect(0, 0, sail_surface.get_width(), reveal_height),
        )


class RaftSlipway:
    '''A fixed build site at the southern beach cove.'''

    WIDTH = 84
    HEIGHT = 72

    def __init__(self, x: int, y: int):
        self.x = float(x)
        self.y = float(y)
        self.width = self.WIDTH
        self.height = self.HEIGHT
        self.has_base_raft = False
        self.has_sail = False
        self.is_departed = False
        self.wave_timer = 0.0
        self.interaction_radius = 86
        self.hitbox = pygame.Rect(int(x), int(y), self.width, self.height)
        self.raft_surface = scale_pixel_art(load_image("raft.png"), 2)
        self.sail_surface = scale_pixel_art(load_image("sail.png"), 2)
        self.minigame: Optional[str] = None
        self.minigame_timer = 0.0
        self.minigame_successes = 0
        self.minigame_misses = 0
        self.minigame_feedback = ""
        self.mast_tilt = 0.45
        self.mast_left = False
        self.mast_right = False

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width / 2, self.y + self.height / 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    @property
    def is_fully_assembled(self) -> bool:
        return self.has_base_raft and self.has_sail

    @property
    def minigame_active(self) -> bool:
        return self.minigame is not None

    def can_interact(self, player) -> bool:
        if self.is_departed:
            return False
        player_center = pygame.Vector2(player.hitbox.center)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        if self.is_departed:
            return ""
        if not self.has_base_raft:
            if player.inventory.has_item("base_raft"):
                return "[기본 뗏목 선택 후 좌클릭: 설치 도전 (실패 시 재료 소모)]"
            return "[뗏목 설치 장소] 기본 뗏목 제작 필요 (원목 10, 밧줄 4, 돌 3)"
        if not self.has_sail:
            if player.inventory.has_item("sail"):
                return "[돛 선택 후 좌클릭: 마스트 세우기 (실패 시 재료 소모)]"
            return "[뗏목 설치 장소] 돛 제작 필요 (원목 2, 밧줄 2, 돛천 1)"
        return "[좌클릭] 완성된 뗏목에 탑승하여 출항하기"

    def interact(self, player, selected_item: Optional[str] = None) -> tuple[bool, str, str]:
        if self.is_departed or self.minigame_active:
            return False, "DEPARTED", "뗏목은 이미 출항했습니다."

        if not self.has_base_raft:
            if selected_item != "base_raft":
                return False, "SELECT_BASE", "퀵슬롯에서 기본 뗏목을 선택한 뒤 설치 장소를 클릭하세요."
            if not player.inventory.remove_item("base_raft"):
                return False, "MISSING_BASE", "기본 뗏목을 먼저 제작해야 합니다."
            self._start_minigame("raft")
            return True, "MINIGAME_STARTED", "파도에 맞춰 스페이스바를 눌러 밧줄을 당기세요. 실패하면 기본 뗏목 재료를 잃습니다."

        if not self.has_sail:
            if selected_item != "sail":
                return False, "SELECT_SAIL", "퀵슬롯에서 돛을 선택한 뒤 뗏목을 클릭하세요."
            if not player.inventory.remove_item("sail"):
                return False, "MISSING_SAIL", "돛을 먼저 제작해야 합니다."
            self._start_minigame("mast")
            return True, "MINIGAME_STARTED", "A/D로 마스트 균형을 잡고 스페이스바로 고정하세요. 실패하면 돛 재료를 잃습니다."

        self.is_departed = True
        return True, "BOARD_ESCAPE", "뗏목에 탑승했습니다. 바다를 향해 출항합니다!"

    def _start_minigame(self, minigame: str):
        self.minigame = minigame
        self.minigame_timer = 0.0
        self.minigame_successes = 0
        self.minigame_misses = 0
        self.minigame_feedback = ""
        self.mast_tilt = 0.45
        self.mast_left = False
        self.mast_right = False

    def _finish_minigame(self, success: bool) -> tuple[bool, str, str]:
        finished_minigame = self.minigame
        self.minigame = None
        self.mast_left = False
        self.mast_right = False

        if success and finished_minigame == "raft":
            self.has_base_raft = True
            return True, "INSTALL_BASE", "기본 뗏목을 설치했습니다."
        if success and finished_minigame == "mast":
            self.has_sail = True
            return True, "INSTALL_SAIL", "마스트를 세우고 돛을 장착했습니다."

        lost_item = "기본 뗏목" if finished_minigame == "raft" else "돛"
        return False, "MINIGAME_FAILED", f"설치에 실패했습니다. {lost_item} 재료를 잃었습니다."

    def _record_minigame_miss(self) -> Optional[tuple[bool, str, str]]:
        self.minigame_misses += 1
        reason = "마스트가 흔들려 고정 실패" if self.minigame == "mast" else "타이밍 실패"
        self.minigame_feedback = f"{reason}! 실수 {self.minigame_misses}/3"
        if self.minigame_misses >= 3:
            return self._finish_minigame(False)
        return None

    def handle_minigame_event(self, event) -> Optional[tuple[bool, str, str]]:
        if not self.minigame_active:
            return None

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return self._finish_minigame(False)
            if self.minigame == "raft" and event.key == pygame.K_SPACE:
                phase = (self.minigame_timer * 0.75) % 2.0
                marker = phase if phase <= 1.0 else 2.0 - phase
                if 0.42 <= marker <= 0.58:
                    self.minigame_successes += 1
                    self.minigame_feedback = "좋아요! 밧줄을 단단히 당겼습니다."
                    if self.minigame_successes >= 3:
                        return self._finish_minigame(True)
                else:
                    return self._record_minigame_miss()
            elif self.minigame == "mast" and event.key in (pygame.K_a, pygame.K_LEFT):
                self.mast_left = True
            elif self.minigame == "mast" and event.key in (pygame.K_d, pygame.K_RIGHT):
                self.mast_right = True
            elif self.minigame == "mast" and event.key == pygame.K_SPACE:
                if self.minigame_timer >= 0.5 and abs(self.mast_tilt) <= 0.16:
                    return self._finish_minigame(True)
                return self._record_minigame_miss()

        elif event.type == pygame.KEYUP and self.minigame == "mast":
            if event.key in (pygame.K_a, pygame.K_LEFT):
                self.mast_left = False
            elif event.key in (pygame.K_d, pygame.K_RIGHT):
                self.mast_right = False
        return None

    def update_minigame(self, dt: float) -> Optional[tuple[bool, str, str]]:
        if not self.minigame_active:
            return None

        self.minigame_timer += dt
        if self.minigame == "raft" and self.minigame_timer >= 30.0:
            return self._finish_minigame(False)
        if self.minigame == "mast":
            wind = 0.26 + math.sin(self.minigame_timer * 2.4) * 0.22
            correction = float(self.mast_right) - float(self.mast_left)
            self.mast_tilt += (wind + correction * 1.6 - self.mast_tilt * 0.08) * dt
            self.mast_tilt = max(-1.0, min(1.0, self.mast_tilt))
            if abs(self.mast_tilt) >= 0.98 or self.minigame_timer >= 20.0:
                return self._finish_minigame(False)
        return None

    def draw_minigame(self, target_surface: pygame.Surface):
        if not self.minigame_active:
            return

        overlay = pygame.Surface(target_surface.get_size(), pygame.SRCALPHA)
        overlay.fill((12, 19, 24, 178))
        target_surface.blit(overlay, (0, 0))

        panel_width, panel_height = (560, 350) if self.minigame == "raft" else (560, 390)
        panel = pygame.Rect(
            (SCREEN_WIDTH - panel_width) // 2,
            (SCREEN_HEIGHT - panel_height) // 2,
            panel_width,
            panel_height,
        )
        pygame.draw.rect(target_surface, (47, 34, 30), panel.inflate(12, 12))
        pygame.draw.rect(target_surface, (108, 72, 48), panel.inflate(6, 6))
        pygame.draw.rect(target_surface, (222, 194, 139), panel)
        pygame.draw.rect(target_surface, (78, 53, 38), panel, 4)
        pygame.draw.rect(target_surface, (244, 222, 174), panel.inflate(-12, -12), 2)

        title_font = get_font(22, bold=True)
        body_font = get_font(16, bold=True)
        small_font = get_font(13)
        title = (
            "파도 사이에 밧줄 묶기"
            if self.minigame == "raft"
            else "흔들리는 마스트 세우기"
        )
        title_surface = title_font.render(title, True, (67, 45, 34))
        target_surface.blit(
            title_surface,
            (panel.centerx - title_surface.get_width() // 2, panel.y + 18),
        )

        if self.minigame == "raft":
            self._draw_raft_minigame(target_surface, panel, body_font, small_font)
        else:
            self._draw_mast_minigame(target_surface, panel, body_font, small_font)

    def _draw_raft_minigame(
        self,
        surface: pygame.Surface,
        panel: pygame.Rect,
        body_font: pygame.font.Font,
        small_font: pygame.font.Font,
    ):
        center_x = panel.centerx
        log_y = panel.y + 91
        for offset in (-13, 0, 13):
            log = pygame.Rect(center_x - 104, log_y + offset, 208, 12)
            pygame.draw.rect(surface, (74, 47, 34), log)
            pygame.draw.rect(surface, (159, 104, 57), log.inflate(-4, -4))
            pygame.draw.line(
                surface,
                (205, 151, 87),
                (log.x + 7, log.y + 4),
                (log.right - 7, log.y + 4),
                2,
            )
        for offset in (-62, 0, 62):
            pygame.draw.rect(
                surface,
                (68, 47, 41),
                pygame.Rect(center_x + offset - 3, log_y - 9, 6, 49),
            )
            pygame.draw.rect(
                surface,
                (177, 123, 69),
                pygame.Rect(center_x + offset - 1, log_y - 7, 2, 45),
            )
        for wave_x in range(panel.x + 46, panel.right - 40, 48):
            pygame.draw.line(
                surface,
                (93, 150, 161),
                (wave_x, log_y + 51),
                (wave_x + 19, log_y + 51),
                3,
            )
            pygame.draw.line(
                surface,
                (93, 150, 161),
                (wave_x + 24, log_y + 51),
                (wave_x + 42, log_y + 51),
                3,
            )

        label = body_font.render(
            f"밧줄 묶기 {self.minigame_successes}/3     실수 {self.minigame_misses}/3",
            True,
            (67, 45, 34),
        )
        surface.blit(label, (panel.centerx - label.get_width() // 2, panel.y + 155))

        bar = pygame.Rect(panel.x + 74, panel.y + 190, panel.width - 148, 26)
        pygame.draw.rect(surface, (57, 43, 35), bar.inflate(8, 8))
        pygame.draw.rect(surface, (126, 91, 56), bar)
        inner = bar.inflate(-4, -4)
        surface.fill((195, 161, 105), inner)
        safe_start = inner.x + round(inner.width * 0.42)
        safe_width = round(inner.width * 0.16)
        pygame.draw.rect(
            surface,
            (111, 143, 78),
            pygame.Rect(safe_start, inner.y, safe_width, inner.height),
        )
        phase = (self.minigame_timer * 0.75) % 2.0
        marker = phase if phase <= 1.0 else 2.0 - phase
        marker_x = inner.x + round(marker * inner.width)
        pygame.draw.rect(
            surface,
            (247, 231, 173),
            pygame.Rect(marker_x - 4, bar.y - 5, 8, bar.height + 10),
        )
        pygame.draw.rect(
            surface,
            (77, 52, 35),
            pygame.Rect(marker_x - 4, bar.y - 5, 8, bar.height + 10),
            2,
        )

        feedback = self.minigame_feedback or "초록 구간에 표시가 왔을 때 스페이스바!"
        feedback_surface = small_font.render(feedback, True, (67, 45, 34))
        surface.blit(
            feedback_surface,
            (panel.centerx - feedback_surface.get_width() // 2, panel.y + 238),
        )
        hint = small_font.render(
            "스페이스바: 밧줄 당기기     ESC: 포기 (실패 시 재료 소모)",
            True,
            (83, 58, 42),
        )
        surface.blit(hint, (panel.centerx - hint.get_width() // 2, panel.y + 292))

    def _draw_mast_minigame(
        self,
        surface: pygame.Surface,
        panel: pygame.Rect,
        body_font: pygame.font.Font,
        small_font: pygame.font.Font,
    ):
        base = pygame.Vector2(panel.centerx, panel.y + 238)
        angle = self.mast_tilt * math.radians(24)
        mast_direction = pygame.Vector2(math.sin(angle), -math.cos(angle))
        sail_side = pygame.Vector2(math.cos(angle), math.sin(angle))
        top = base + mast_direction * 112
        sail_points = [
            top,
            top + sail_side * 82,
            base + sail_side * 18,
            base,
        ]
        rounded_sail = [(round(point.x), round(point.y)) for point in sail_points]
        pygame.draw.polygon(surface, (72, 48, 36), rounded_sail)
        inset_sail = [
            top + sail_side * 6,
            top + sail_side * 73 + mast_direction * 4,
            base + sail_side * 13 + mast_direction * 7,
            base + mast_direction * 7,
        ]
        pygame.draw.polygon(
            surface,
            (229, 218, 180),
            [(round(point.x), round(point.y)) for point in inset_sail],
        )
        pygame.draw.line(
            surface,
            (67, 43, 32),
            (round(base.x), round(base.y)),
            (round(top.x), round(top.y)),
            11,
        )
        pygame.draw.line(
            surface,
            (168, 115, 63),
            (round(base.x), round(base.y)),
            (round(top.x), round(top.y)),
            6,
        )
        for offset in (-76, -38, 0, 38, 76):
            log = pygame.Rect(round(base.x) + offset - 29, round(base.y) + 7, 58, 12)
            pygame.draw.rect(surface, (72, 47, 34), log)
            pygame.draw.rect(surface, (157, 101, 57), log.inflate(-4, -4))

        left_hint = small_font.render("A: 왼쪽", True, (67, 45, 34))
        right_hint = small_font.render("D: 오른쪽", True, (67, 45, 34))
        surface.blit(left_hint, (panel.x + 58, panel.y + 190))
        surface.blit(right_hint, (panel.right - 58 - right_hint.get_width(), panel.y + 190))

        bar = pygame.Rect(panel.x + 96, panel.y + 270, panel.width - 192, 22)
        pygame.draw.rect(surface, (57, 43, 35), bar.inflate(8, 8))
        inner = bar.inflate(-4, -4)
        surface.fill((195, 161, 105), inner)
        safe_start = inner.x + round(inner.width * 0.42)
        safe_width = round(inner.width * 0.16)
        pygame.draw.rect(
            surface,
            (111, 143, 78),
            pygame.Rect(safe_start, inner.y, safe_width, inner.height),
        )
        marker_x = inner.centerx + round(self.mast_tilt * inner.width / 2)
        pygame.draw.rect(
            surface,
            (247, 231, 173),
            pygame.Rect(marker_x - 5, bar.y - 5, 10, bar.height + 10),
        )
        pygame.draw.rect(
            surface,
            (77, 52, 35),
            pygame.Rect(marker_x - 5, bar.y - 5, 10, bar.height + 10),
            2,
        )

        feedback = self.minigame_feedback or "초록 구간에서 스페이스바로 마스트를 고정하세요."
        feedback_surface = body_font.render(feedback, True, (67, 45, 34))
        surface.blit(
            feedback_surface,
            (panel.centerx - feedback_surface.get_width() // 2, panel.y + 307),
        )
        hint = small_font.render(
            "A/D: 균형 잡기     스페이스바: 고정     ESC: 포기 (실패 시 재료 소모)",
            True,
            (83, 58, 42),
        )
        surface.blit(hint, (panel.centerx - hint.get_width() // 2, panel.y + 348))

    def update(self, dt: float):
        self.wave_timer += dt * 3.0

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        bob = int(math.sin(self.wave_timer) * 2)

        if not self.has_base_raft:
            for offset in (25, 45):
                plank = pygame.Rect(screen_x + 6, screen_y + offset, self.width - 12, 5)
                pygame.draw.rect(target_surface, (66, 43, 38), plank)
                pygame.draw.rect(target_surface, (153, 101, 59), plank.inflate(-2, -2))
            return

        raft_x = screen_x + (self.width - self.raft_surface.get_width()) // 2
        raft_y = screen_y + (self.height - self.raft_surface.get_height()) // 2 + bob
        if self.has_sail:
            _draw_raft_with_sail(
                target_surface,
                self.raft_surface,
                self.sail_surface,
                raft_x,
                raft_y,
            )
        else:
            target_surface.blit(self.raft_surface, (raft_x, raft_y))


class RaftEscapeCutscene:
    '''A short animated departure that ends on a permanent victory screen.'''

    DURATION = 16.0

    def __init__(self):
        self.is_active = False
        self.timer = 0.0
        self.is_finished = False
        self.raft_surface = scale_pixel_art(load_image("raft.png"), 3)
        self.sail_surface = scale_pixel_art(load_image("sail.png"), 3)
        self.ocean_surface = pygame.transform.scale(
            get_tileset_tile(5, 5), (TILE_SIZE, TILE_SIZE)
        )

    def start(self):
        self.is_active = True
        self.is_finished = False
        self.timer = 0.0

    def update(self, dt: float):
        if not self.is_active:
            return
        self.timer = min(self.DURATION, self.timer + dt)
        self.is_finished = self.timer >= self.DURATION

    def _draw_ocean(self, surface: pygame.Surface):
        offset_x = round(math.sin(self.timer * 0.7) * 2)
        offset_y = int(self.timer * 1.5) % TILE_SIZE
        for y in range(-TILE_SIZE + offset_y, SCREEN_HEIGHT, TILE_SIZE):
            for x in range(-TILE_SIZE + offset_x, SCREEN_WIDTH, TILE_SIZE):
                surface.blit(self.ocean_surface, (x, y))

    def _draw_island(self, surface: pygame.Surface, distance: float = 0.0):
        '''Paint the island behind the raft so the tsunami can visibly engulf it.'''
        island = pygame.Surface((350, 180), pygame.SRCALPHA)
        pygame.draw.ellipse(island, (28, 63, 76), (10, 74, 330, 100))
        pygame.draw.ellipse(island, (217, 190, 119), (18, 63, 314, 106))
        pygame.draw.ellipse(island, (83, 133, 69), (42, 75, 266, 80))

        for x, y, height in ((101, 105, 34), (175, 82, 49), (247, 106, 32)):
            pygame.draw.line(island, (106, 73, 43), (x, y + height), (x - 4, y), 5)
            crown_x, crown_y = x - 4, y
            for dx, dy in ((-23, -12), (-17, -21), (-5, -24), (10, -21), (23, -12)):
                pygame.draw.line(
                    island,
                    (44, 105, 57),
                    (crown_x, crown_y),
                    (crown_x + dx, crown_y + dy),
                    6,
                )
                pygame.draw.line(
                    island,
                    (101, 157, 72),
                    (crown_x, crown_y),
                    (crown_x + dx, crown_y + dy),
                    2,
                )

        pygame.draw.polygon(island, (101, 75, 53), [(147, 120), (175, 91), (203, 120)])
        pygame.draw.polygon(island, (220, 205, 165), [(153, 117), (175, 97), (197, 117)])
        pygame.draw.rect(island, (92, 63, 43), (171, 109, 9, 12))
        pygame.draw.ellipse(island, (93, 143, 69), (72, 126, 19, 9))
        pygame.draw.ellipse(island, (93, 143, 69), (255, 131, 23, 8))
        scale = 1.0 - 0.22 * distance
        island = pygame.transform.scale(
            island,
            (round(island.get_width() * scale), round(island.get_height() * scale)),
        )
        island_y = 18 - round(distance * 34)
        surface.blit(island, ((SCREEN_WIDTH - island.get_width()) // 2, island_y))

    def _draw_tsunami(self, surface: pygame.Surface):
        '''Move the tsunami down from the top of the screen and over the island.'''
        progress = min(1.0, max(0.0, (self.timer - 8.5) / 5.0))
        front_y = int(-80 + progress * 350)
        wave_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)

        crest_points = []
        for x in range(-24, SCREEN_WIDTH + 25, 24):
            crest_y = front_y + int(math.sin(x * 0.035 + self.timer * 4.5) * 12)
            crest_points.append((x, crest_y))

        water_shape = [(0, 0), (SCREEN_WIDTH, 0)] + list(reversed(crest_points))
        pygame.draw.polygon(wave_surface, (28, 111, 126, 244), water_shape)

        # Deep bands, foam, and spray make the advancing edge read as a wave.
        band_y = max(0, front_y - 34)
        pygame.draw.line(wave_surface, (39, 143, 153, 220), (0, band_y), (SCREEN_WIDTH, band_y + 4), 12)
        for x, crest_y in crest_points:
            pygame.draw.ellipse(
                wave_surface,
                (205, 241, 220, 245),
                (x - 15, crest_y - 5, 33, 14),
            )
            pygame.draw.ellipse(
                wave_surface,
                (128, 216, 168, 225),
                (x - 9, crest_y + 3, 25, 8),
            )

        spray_phase = self.timer * 31
        for index in range(34):
            x = (index * 83 + int(spray_phase * (1 + index % 3))) % SCREEN_WIDTH
            y = front_y - 12 - (index * 29 % 70)
            radius = 2 + index % 4
            pygame.draw.circle(wave_surface, (224, 247, 230, 220), (x, y), radius)

        surface.blit(wave_surface, (0, 0))

    def draw(self, surface: pygame.Surface, camera=None):
        if not self.is_active:
            return

        self._draw_ocean(surface)
        title_font = get_font(28, bold=True)
        subtitle_font = get_font(16)

        if self.timer < 13.5:
            travel = min(1.0, self.timer / 13.5)
            raft_surface = self.raft_surface
            sail_surface = self.sail_surface
            departure_progress = 0.0
            if self.timer >= 8.5:
                departure_progress = min(1.0, (self.timer - 8.5) / 5.0)
                departure_progress = departure_progress**2 * (3 - 2 * departure_progress)
                scale = 1.0 + departure_progress * 0.35
                raft_surface = pygame.transform.scale(
                    self.raft_surface,
                    (
                        round(self.raft_surface.get_width() * scale),
                        round(self.raft_surface.get_height() * scale),
                    ),
                )
                sail_surface = pygame.transform.scale(
                    self.sail_surface,
                    (
                        round(self.sail_surface.get_width() * scale),
                        round(self.sail_surface.get_height() * scale),
                    ),
                )
            raft_x = (SCREEN_WIDTH - raft_surface.get_width()) // 2
            raft_x += round(math.sin(self.timer * 1.3) * departure_progress * 7)
            raft_y = int(
                SCREEN_HEIGHT * 0.35
                + travel * 95
                + departure_progress * 24
                + math.sin(self.timer * 4) * 4
            )

            self._draw_island(surface, travel)

            if self.timer < 4.5:
                surface.blit(raft_surface, (raft_x, raft_y))
                title, subtitle = "뗏목 출항", "섬을 뒤로하고 바다를 향해 나아갑니다."
            elif self.timer < 8.5:
                unfurl = min(1.0, (self.timer - 4.5) / 2.5)
                _draw_raft_with_sail(
                    surface,
                    raft_surface,
                    sail_surface,
                    raft_x,
                    raft_y,
                    sail_reveal=unfurl,
                )
                title, subtitle = "돛을 펼치다", "바람을 받은 돛이 뗏목을 앞으로 밀어줍니다."
            else:
                storm_dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
                storm_dim.fill((16, 62, 69, 55))
                surface.blit(storm_dim, (0, 0))
                self._draw_tsunami(surface)

                _draw_raft_with_sail(
                    surface,
                    raft_surface,
                    sail_surface,
                    raft_x,
                    raft_y,
                )
                title, subtitle = "해일을 벗어나다", "뗏목이 파도를 가르며 멀어지고, 섬은 해일 아래로 사라집니다."

            banner = pygame.Rect(40, SCREEN_HEIGHT - 104, SCREEN_WIDTH - 80, 68)
            banner_alpha = round(255 * (1.0 - departure_progress))
            banner_surface = pygame.Surface(banner.size, pygame.SRCALPHA)
            pygame.draw.rect(
                banner_surface,
                (*COLOR_UI_DARK, banner_alpha),
                banner_surface.get_rect(),
            )
            pygame.draw.rect(
                banner_surface,
                (*COLOR_UI_EDGE, banner_alpha),
                banner_surface.get_rect().inflate(-4, -4),
            )
            pygame.draw.rect(
                banner_surface,
                (30, 111, 124, banner_alpha),
                banner_surface.get_rect().inflate(-10, -10),
            )
            pygame.draw.line(
                banner_surface,
                (*COLOR_UI_LIGHT, banner_alpha),
                (8, 7),
                (banner.width - 9, 7),
                2,
            )
            pygame.draw.line(
                banner_surface,
                (128, 216, 168, banner_alpha),
                (8, banner.height - 8),
                (banner.width - 9, banner.height - 8),
                2,
            )
            title = title_font.render(title, True, COLOR_UI_ACCENT)
            subtitle = subtitle_font.render(subtitle, True, COLOR_UI_TEXT)
            title.set_alpha(banner_alpha)
            subtitle.set_alpha(banner_alpha)
            surface.blit(banner_surface, banner)
            surface.blit(title, (banner.x + 18, banner.y + 8))
            surface.blit(subtitle, (banner.x + 18, banner.y + 42))
            return

        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((6, 18, 35, 225))
        surface.blit(overlay, (0, 0))

        panel = pygame.Rect(150, 105, SCREEN_WIDTH - 300, 330)
        pygame.draw.rect(surface, (20, 32, 50), panel, border_radius=12)
        pygame.draw.rect(surface, (245, 200, 75), panel, 2, border_radius=12)
        title = title_font.render("해일 전 3일 - 탈출 성공!", True, (255, 215, 80))
        surface.blit(title, (panel.centerx - title.get_width() // 2, panel.y + 38))

        lines = (
            "완성한 뗏목과 돛으로 거대한 해일을 피해",
            "섬을 벗어나 안전한 바다로 탈출했습니다.",
            "",
            "생존 성공",
        )
        body_font = get_font(18, bold=True)
        for index, line in enumerate(lines):
            if line:
                text = body_font.render(line, True, (230, 238, 248))
                surface.blit(text, (panel.centerx - text.get_width() // 2, panel.y + 112 + index * 38))
        hint_font = get_font(14, bold=True)
        hint = hint_font.render("Enter 또는 클릭: 타이틀 화면으로", True, (245, 220, 150))
        surface.blit(hint, (panel.centerx - hint.get_width() // 2, panel.bottom - 34))

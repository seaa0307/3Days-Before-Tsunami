"""
해일 전 5일 (5 Days Before Tsunami)
최종 뗏목 건조, 비상식량 적재 및 탈출 엔딩 컷씬 모듈
"""

import math
import random
import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    COLOR_SHADOW,
    COLOR_UI_ACCENT,
    COLOR_TREE_TRUNK,
)
from fonts import get_font


class RaftSlipway:
    """
    해변의 지정된 장소에 위치한 뗏목 건조대 및 최종 탈출 뗏목
    - 1단계: 기본 뗏목 설치 (원목 10, 밧줄 4, 돌 3)
    - 2단계: 노 장착 (원목 3, 밧줄 2, 돌 2)
    - 3단계: 돛 장착 (원목 2, 밧줄 2, 돛천 1)
    - 4단계: 비상식량 적재 (베리 5개, 코코넛 3개)
    - 5단계: 탑승 및 엔딩 컷씬 시작
    """

    def __init__(self, x: int, y: int):
        self.x = float(x)
        self.y = float(y)
        self.width = 68
        self.height = 56

        # 상태 플래그
        self.has_base_raft = False
        self.has_oar = False
        self.has_sail = False
        self.has_rations = False
        self.is_departed = False

        self.hitbox = pygame.Rect(int(x + 4), int(y + 14), 60, 36)
        self.interaction_radius = 65

        # 뗏목 물결 출렁임 애니메이션
        self.wave_timer = 0.0

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    @property
    def is_fully_assembled(self) -> bool:
        """모든 탈출 조건(기본 뗏목, 노, 돛, 비상식량) 충족 여부"""
        return self.has_base_raft and self.has_oar and self.has_sail and self.has_rations

    def can_interact(self, player) -> bool:
        if self.is_departed:
            return False
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        return player_center.distance_to(self.center) <= self.interaction_radius

    def get_prompt(self, player) -> str:
        """플레이어 상태 및 장착 진행도에 따른 최적 툴팁 반환"""
        if self.is_departed:
            return ""

        if not self.has_base_raft:
            if player.inventory.has_item("base_raft"):
                return "[E] 기본 뗏목 건조대에 설치하기 (기본 뗏목 보유 중)"
            return "[해변 뗏목 건조대] 기본 뗏목 제작 필요 (원목 10, 밧줄 4, 돌 3)"

        # 뗏목 설치 후 장착/적재 가능 항목 우선 안내
        if not self.has_oar and player.inventory.has_item("oar"):
            return "[E] 뗏목에 노 장착하기 (노 보유 중)"

        if not self.has_sail and player.inventory.has_item("sail"):
            return "[E] 뗏목에 돛 장착하기 (돛 보유 중)"

        if not self.has_rations and player.inventory.get_count("berry") >= 5 and player.inventory.get_count("coconut") >= 3:
            return "[E] 비상식량 적재하기 (베리 5개, 코코넛 3개)"

        # 모든 준비 완료 시
        if self.is_fully_assembled:
            return "[E] 완성된 뗏목에 탑승하여 섬 탈출하기!"

        # 아직 필요한 항목 요약 안내
        missing = []
        if not self.has_oar:
            missing.append("노")
        if not self.has_sail:
            missing.append("돛")
        if not self.has_rations:
            b = player.inventory.get_count("berry")
            c = player.inventory.get_count("coconut")
            missing.append(f"비상식량(베리 {b}/5, 코코넛 {c}/3)")

        return f"[뗏목 준비 중] 필요: {', '.join(missing)}"

    def interact(self, player) -> tuple:
        """
        [E] 키 상호작용 처리
        반환: (성공여부: bool, 이벤트타입: str, 메시지: str)
        """
        if self.is_departed:
            return False, "DEPARTED", "이미 뗏목이 출항했습니다."

        # 1. 기본 뗏목 미설치 상태
        if not self.has_base_raft:
            if player.inventory.has_item("base_raft"):
                player.inventory.remove_item("base_raft", 1)
                self.has_base_raft = True
                return True, "INSTALL_BASE", "기본 뗏목을 해변 건조대에 설치했습니다! 노, 돛, 비상식량을 준비하세요."
            else:
                return False, "MISSING_BASE", "기본 뗏목이 필요합니다. [가방에서 원목 10, 밧줄 4, 돌 3으로 제작]"

        # 2. 노 장착
        if not self.has_oar and player.inventory.has_item("oar"):
            player.inventory.remove_item("oar", 1)
            self.has_oar = True
            return True, "EQUIP_OAR", "뗏목에 항해용 노를 장착했습니다!"

        # 3. 돛 장착
        if not self.has_sail and player.inventory.has_item("sail"):
            player.inventory.remove_item("sail", 1)
            self.has_sail = True
            return True, "EQUIP_SAIL", "뗏목에 바람을 탈 돛을 장착했습니다!"

        # 4. 비상식량 적재 (베리 5개, 코코넛 3개)
        if not self.has_rations and player.inventory.get_count("berry") >= 5 and player.inventory.get_count("coconut") >= 3:
            player.inventory.remove_item("berry", 5)
            player.inventory.remove_item("coconut", 3)
            self.has_rations = True
            return True, "LOAD_RATIONS", "뗏목에 비상식량(베리 5개, 코코넛 3개)을 성공적으로 적재했습니다!"

        # 5. 모든 조건 충족 시 최종 탈출 탑승!
        if self.is_fully_assembled:
            self.is_departed = True
            return True, "BOARD_ESCAPE", "뗏목에 탑승했습니다! 출항을 시작합니다!"

        # 아직 부족한 상태인 경우 사유 안내
        missing = []
        if not self.has_oar:
            missing.append("노 1개")
        if not self.has_sail:
            missing.append("돛 1개")
        if not self.has_rations:
            missing.append("비상식량(베리 5개, 코코넛 3개)")

        return False, "INCOMPLETE", f"탈출 준비가 덜 되었습니다. 필요: {', '.join(missing)}"

    def update(self, dt: float):
        self.wave_timer += dt * 3.0

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 건조대 바닥 말뚝 / 도크 프레임 (항상 표시)
        pygame.draw.line(target_surface, (80, 50, 30), (screen_x + 4, screen_y + 8), (screen_x + 4, screen_y + 44), 4)
        pygame.draw.line(target_surface, (80, 50, 30), (screen_x + self.width - 4, screen_y + 8), (screen_x + self.width - 4, screen_y + 44), 4)
        pygame.draw.circle(target_surface, (190, 160, 110), (screen_x + 4, screen_y + 8), 4)
        pygame.draw.circle(target_surface, (190, 160, 110), (screen_x + self.width - 4, screen_y + 8), 4)

        # 출항했거나 기본 뗏목이 아직 없을 때: 비어 있는 슬립웨이 나무 받침대
        if self.is_departed or not self.has_base_raft:
            pygame.draw.line(target_surface, (110, 75, 45), (screen_x + 8, screen_y + 24), (screen_x + self.width - 8, screen_y + 24), 3)
            pygame.draw.line(target_surface, (110, 75, 45), (screen_x + 8, screen_y + 36), (screen_x + self.width - 8, screen_y + 36), 3)
            return

        # 2. 기본 뗏목 본체 (5개의 통나무 엮음)
        wave_bob = int(math.sin(self.wave_timer) * 2)
        ry = screen_y + wave_bob

        # 그림자
        pygame.draw.ellipse(target_surface, COLOR_SHADOW, (screen_x + 6, ry + 36, self.width - 12, 14))

        # 통나무 5줄
        log_colors = [(110, 70, 40), (135, 90, 55), (110, 70, 40), (135, 90, 55), (110, 70, 40)]
        for i, col in enumerate(log_colors):
            lx = screen_x + 8 + i * 10
            pygame.draw.rect(target_surface, col, (lx, ry + 16, 9, 32), border_radius=3)
            pygame.draw.rect(target_surface, (70, 45, 25), (lx, ry + 16, 9, 32), 1, border_radius=3)

        # 뗏목 가로 결속 밧줄 2줄
        pygame.draw.line(target_surface, (190, 160, 100), (screen_x + 6, ry + 22), (screen_x + self.width - 6, ry + 22), 2)
        pygame.draw.line(target_surface, (190, 160, 100), (screen_x + 6, ry + 40), (screen_x + self.width - 6, ry + 40), 2)

        # 3. 비상식량 적재 시 (왼쪽 바구니에 베리와 코코넛 표시)
        if self.has_rations:
            basket_x = screen_x + 12
            basket_y = ry + 26
            pygame.draw.ellipse(target_surface, (150, 110, 60), (basket_x, basket_y, 14, 10))
            pygame.draw.circle(target_surface, (220, 50, 60), (basket_x + 4, basket_y + 3), 3)  # 베리
            pygame.draw.circle(target_surface, (220, 50, 60), (basket_x + 8, basket_y + 4), 3)  # 베리
            pygame.draw.circle(target_surface, (120, 80, 40), (basket_x + 6, basket_y + 6), 4)  # 코코넛

        # 4. 노 장착 시 (우측에 걸쳐진 나무 노)
        if self.has_oar:
            oar_x = screen_x + self.width - 12
            pygame.draw.line(target_surface, (120, 80, 50), (oar_x - 6, ry + 16), (oar_x + 6, ry + 46), 3)
            pygame.draw.ellipse(target_surface, (160, 110, 60), (oar_x + 3, ry + 40, 6, 10))

        # 5. 돛 장착 시 (뗏목 중앙 마스트와 돛)
        if self.has_sail:
            mast_x = screen_x + self.width // 2
            # 돛대 기둥
            pygame.draw.line(target_surface, (90, 60, 35), (mast_x, ry + 4), (mast_x, ry + 36), 4)
            # 가로 돛대
            pygame.draw.line(target_surface, (110, 75, 45), (mast_x - 14, ry + 10), (mast_x + 14, ry + 10), 3)
            # 흰색 삼각 돛천
            sail_pts = [
                (mast_x, ry + 6),
                (mast_x + 14, ry + 24),
                (mast_x - 14, ry + 24),
            ]
            pygame.draw.polygon(target_surface, (240, 235, 220), sail_pts)
            pygame.draw.polygon(target_surface, (180, 175, 160), sail_pts, 1)


class RaftEscapeCutscene:
    """
    탈출 엔딩 컷씬 컨트롤러
    재생 순서:
    1. 뗏목 출항 (Raft Departure, 0~4.5초): 뗏목이 바다로 출항하며 노를 저음
    2. 돛 펼치기 (Sail Unfurling, 4.5~8.5초): 바람을 타고 돛이 활짝 펼쳐지며 가속
    3. 해일 발생 (Tsunami Strikes Island, 8.5~13.5초): 거대한 해일이 섬을 덮침, 진동
    4. 탈출 성공 문구 (Escape Success Epilogue, 13.5초~): 승리 서사 및 [R] 재시작
    """

    def __init__(self):
        self.is_active = False
        self.timer = 0.0
        self.raft_pos = pygame.Vector2(0, 0)
        self.screen_shake = 0.0
        self.wind_particles = []

    def start(self, raft_x: float, raft_y: float):
        self.is_active = True
        self.timer = 0.0
        self.raft_pos = pygame.Vector2(raft_x, raft_y)
        self.screen_shake = 0.0
        self.wind_particles = []
        for _ in range(25):
            self.wind_particles.append({
                "x": random.randint(0, SCREEN_WIDTH),
                "y": random.randint(0, SCREEN_HEIGHT),
                "speed": random.uniform(200, 450),
                "len": random.randint(15, 35)
            })

    @property
    def can_restart(self) -> bool:
        """엔딩 컷씬 완료 후 [R] 키로 재시작 가능 여부"""
        return self.is_active and self.timer >= 13.5

    def update(self, dt: float):
        if not self.is_active:
            return

        self.timer += dt

        # 1. 뗏목 출항 단계 (바다 남쪽으로 노를 저으며 서서히 전진)
        if self.timer < 4.5:
            self.raft_pos.y += 24.0 * dt
            self.screen_shake = 0.0
        # 2. 돛 펼치기 단계 (순풍을 받아 빠른 속도로 가속 전진)
        elif self.timer < 8.5:
            self.raft_pos.y += 52.0 * dt
            self.raft_pos.x += 10.0 * dt
            self.screen_shake = 0.0
        # 3. 해일 발생 단계 (거대한 파도가 섬을 덮침, 강한 화면 진동)
        elif self.timer < 13.5:
            self.raft_pos.y += 65.0 * dt
            self.raft_pos.x += 12.0 * dt
            self.screen_shake = math.sin(self.timer * 35.0) * 7.0
        else:
            self.screen_shake = 0.0
            self.raft_pos.y += 18.0 * dt

        # 바람 파티클 업데이트
        for p in self.wind_particles:
            p["x"] += p["speed"] * dt
            p["y"] += p["speed"] * 0.3 * dt
            if p["x"] > SCREEN_WIDTH:
                p["x"] = -30
                p["y"] = random.randint(0, SCREEN_HEIGHT)

    def draw_departing_raft(self, surface: pygame.Surface, camera):
        """바다를 항해하는 뗏목과 플레이어 캐릭터 렌더링"""
        rx = int(self.raft_pos.x - camera.x)
        ry = int(self.raft_pos.y - camera.y)
        bob = int(math.sin(self.timer * 4.0) * 2.5)
        dry = ry + bob

        # 1. 물결 흔적 (Raft Wake)
        wake_color = (200, 235, 255)
        for offset_y in (10, 24, 38):
            trail_y = dry - offset_y
            wake_w = int(24 + offset_y * 1.2)
            pygame.draw.ellipse(surface, (180, 220, 245, 120), (rx + 34 - wake_w // 2, trail_y, wake_w, 6), 2)

        # 2. 뗏목 그림자
        pygame.draw.ellipse(surface, COLOR_SHADOW, (rx + 6, dry + 36, 56, 14))

        # 3. 통나무 5줄
        log_colors = [(110, 70, 40), (135, 90, 55), (110, 70, 40), (135, 90, 55), (110, 70, 40)]
        for i, col in enumerate(log_colors):
            lx = rx + 8 + i * 10
            pygame.draw.rect(surface, col, (lx, dry + 16, 9, 32), border_radius=3)
            pygame.draw.rect(surface, (70, 45, 25), (lx, dry + 16, 9, 32), 1, border_radius=3)

        # 결속 밧줄
        pygame.draw.line(surface, (190, 160, 100), (rx + 6, dry + 22), (rx + 62, dry + 22), 2)
        pygame.draw.line(surface, (190, 160, 100), (rx + 6, dry + 40), (rx + 62, dry + 40), 2)

        # 4. 비상식량 바구니
        basket_x = rx + 12
        basket_y = dry + 28
        pygame.draw.ellipse(surface, (150, 110, 60), (basket_x, basket_y, 14, 10))
        pygame.draw.circle(surface, (220, 50, 60), (basket_x + 4, basket_y + 3), 3)
        pygame.draw.circle(surface, (220, 50, 60), (basket_x + 8, basket_y + 4), 3)
        pygame.draw.circle(surface, (120, 80, 40), (basket_x + 6, basket_y + 6), 4)

        # 5. 플레이어 캐릭터 (뗏목 위에 탑승)
        px = rx + 24
        py = dry + 14
        # 몸통
        pygame.draw.rect(surface, (220, 185, 120), (px + 4, py + 8, 12, 14), border_radius=2)
        # 머리
        pygame.draw.circle(surface, (235, 195, 160), (px + 10, py + 4), 6)
        # 머리카락
        pygame.draw.arc(surface, (90, 55, 30), (px + 4, py - 2, 12, 10), 0.2, 3.0, 3)
        # 바지
        pygame.draw.rect(surface, (45, 60, 85), (px + 4, py + 22, 12, 8), border_radius=1)

        # 6. 노 (Oar) 애니메이션
        oar_base_x = rx + 56
        if self.timer < 4.5:
            # 1단계 출항 중: 힘차게 노 젓기
            row_rot = math.sin(self.timer * 5.0) * 12
            pygame.draw.line(surface, (120, 80, 50), (oar_base_x - 6, dry + 20), (oar_base_x + 10 + int(row_rot), dry + 44), 3)
            pygame.draw.ellipse(surface, (160, 110, 60), (oar_base_x + 6 + int(row_rot), dry + 38, 8, 12))
        else:
            # 2~4단계: 노는 측면에 기대어 고정
            pygame.draw.line(surface, (120, 80, 50), (oar_base_x - 6, dry + 16), (oar_base_x + 6, dry + 46), 3)
            pygame.draw.ellipse(surface, (160, 110, 60), (oar_base_x + 3, dry + 40, 6, 10))

        # 7. 마스트 기둥 및 돛
        mast_x = rx + 34
        pygame.draw.line(surface, (90, 60, 35), (mast_x, dry - 8), (mast_x, dry + 32), 4)

        if self.timer < 4.5:
            # 1단계: 아직 돛을 접어둔 상태 (가로대에 천이 돌돌 말려 있음)
            pygame.draw.line(surface, (110, 75, 45), (mast_x - 16, dry + 2), (mast_x + 16, dry + 2), 3)
            pygame.draw.rect(surface, (230, 225, 210), (mast_x - 14, dry + 1, 28, 5), border_radius=2)
            pygame.draw.line(surface, (150, 120, 70), (mast_x - 7, dry + 1), (mast_x - 7, dry + 6), 1)
            pygame.draw.line(surface, (150, 120, 70), (mast_x + 7, dry + 1), (mast_x + 7, dry + 6), 1)
        elif self.timer < 8.5:
            # 2단계: 돛 펼치기 (서서히 아래로 활짝 펄럭이며 펼쳐짐)
            unfurl = min(1.0, (self.timer - 4.5) / 2.5)
            sail_h = int(6 + unfurl * 26)
            sail_w = int(6 + unfurl * 14)
            pygame.draw.line(surface, (110, 75, 45), (mast_x - sail_w, dry - 2), (mast_x + sail_w, dry - 2), 3)

            sail_pts = [
                (mast_x, dry - 6),
                (mast_x + sail_w, dry - 6 + sail_h),
                (mast_x - sail_w, dry - 6 + sail_h),
            ]
            pygame.draw.polygon(surface, (245, 240, 225), sail_pts)
            pygame.draw.polygon(surface, (180, 175, 160), sail_pts, 2)
        else:
            # 3, 4단계: 순풍을 머금고 웅장하게 펼쳐진 흰색 돛
            billow = math.sin(self.timer * 6.0) * 3
            pygame.draw.line(surface, (110, 75, 45), (mast_x - 16, dry - 4), (mast_x + 16, dry - 4), 3)
            sail_pts = [
                (mast_x, dry - 8),
                (mast_x + 17 + int(billow), dry + 24),
                (mast_x - 17 + int(billow), dry + 24),
            ]
            pygame.draw.polygon(surface, (245, 240, 225), sail_pts)
            pygame.draw.polygon(surface, (180, 175, 160), sail_pts, 2)
            # 바람 주름선
            pygame.draw.line(surface, (215, 210, 195), (mast_x, dry - 4), (mast_x + int(billow), dry + 22), 2)

    def draw(self, surface: pygame.Surface, camera):
        if not self.is_active:
            return

        title_font = get_font(28, bold=True)
        sub_font = get_font(18, bold=True)
        body_font = get_font(15)

        # 항해 중인 뗏목 렌더링 (1 ~ 3단계)
        if self.timer < 14.5:
            self.draw_departing_raft(surface, camera)

        # ----------------------------------------------------
        # 1단계: 뗏목 출항 (0 ~ 4.5초)
        # ----------------------------------------------------
        if self.timer < 4.5:
            self._draw_banner(
                surface,
                "1. 뗏목 출항",
                "모든 생존 준비를 마치고 뗏목에 올라타 고립되었던 섬을 떠나 바다로 나아갑니다...",
                (140, 200, 255),
            )

        # ----------------------------------------------------
        # 2단계: 돛 펼치기 (4.5 ~ 8.5초)
        # ----------------------------------------------------
        elif self.timer < 8.5:
            # 바람 선 렌더링
            for p in self.wind_particles:
                pygame.draw.line(surface, (220, 240, 255, 160), (p["x"], p["y"]), (p["x"] + p["len"], p["y"] + p["len"] * 0.3), 2)

            self._draw_banner(
                surface,
                "2. 돛 펼치기",
                "거센 바닷바람을 머금고 거대한 돛이 활짝 펼쳐지며 뗏목이 파도를 가르고 속도를 높입니다!",
                (255, 230, 100),
            )

        # ----------------------------------------------------
        # 3단계: 해일 발생 (8.5 ~ 13.5초)
        # ----------------------------------------------------
        elif self.timer < 13.5:
            # 짙은 먹구름과 하늘빛 어두움
            storm_dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            storm_dim.fill((10, 20, 45, 140))
            surface.blit(storm_dim, (0, 0))

            # 뒤편 섬 방향에 솟구치는 거대한 해일 벽 표현
            tsunami_progress = min(1.0, (self.timer - 8.5) / 3.0)
            tsunami_h = int(tsunami_progress * 240)

            wave_surf = pygame.Surface((SCREEN_WIDTH, tsunami_h), pygame.SRCALPHA)
            # 층층의 해일 파도
            pygame.draw.rect(wave_surf, (15, 55, 95, 220), (0, 0, SCREEN_WIDTH, tsunami_h))
            pygame.draw.rect(wave_surf, (25, 90, 140, 200), (0, 15, SCREEN_WIDTH, tsunami_h - 15))

            # 파도 거품 라인 (상단 물보라)
            for wx in range(0, SCREEN_WIDTH + 30, 20):
                wave_offset = int(math.sin(self.timer * 15.0 + wx * 0.1) * 8)
                pygame.draw.circle(wave_surf, (230, 248, 255), (wx, 12 + wave_offset), 14)

            surface.blit(wave_surf, (0, 30))

            self._draw_banner(
                surface,
                "3. 대재앙의 해일 발생!",
                "하늘을 집어삼킬 듯한 거대한 해일이 섬 전체를 무자비하게 덮쳐오며 모든 것을 삼켜버립니다!",
                (255, 90, 80),
            )

        # ----------------------------------------------------
        # 4단계: 탈출 성공 문구 (13.5초 ~ )
        # ----------------------------------------------------
        else:
            # 평화로운 새벽 햇살 오버레이
            end_bg = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            end_bg.fill((8, 20, 40, 235))
            surface.blit(end_bg, (0, 0))

            # 황금빛 승리 패널
            panel_w = 640
            panel_h = 320
            px = (SCREEN_WIDTH - panel_w) // 2
            py = (SCREEN_HEIGHT - panel_h) // 2

            pygame.draw.rect(surface, (20, 32, 50), (px, py, panel_w, panel_h), border_radius=10)
            pygame.draw.rect(surface, (245, 200, 75), (px, py, panel_w, panel_h), 2, border_radius=10)

            # 탈출 성공 큰 타이틀
            t1 = title_font.render("해일 전 5일 - 탈출 성공!", True, (255, 215, 80))
            surface.blit(t1, (px + (panel_w - t1.get_width()) // 2, py + 30))

            lines = [
                "당신은 5일간의 철저한 생존 준비와 뗏목 건조 끝에",
                "섬을 집어삼킨 거대한 해일로부터 무사히 탈출했습니다.",
                "",
                "적재한 비상식량과 단단한 뗏목으로 폭풍우를 뚫고 나와",
                "마침내 평온한 수평선 너머 새로운 대륙을 마주합니다.",
            ]
            line_y = py + 86
            for l in lines:
                if l:
                    txt = body_font.render(l, True, (230, 235, 245))
                    surface.blit(txt, (px + (panel_w - txt.get_width()) // 2, line_y))
                line_y += 26

            # 재시작 안내 (부드러운 깜빡임)
            blink = int(math.sin(pygame.time.get_ticks() / 250.0) * 40 + 215)
            r_hint = sub_font.render("[R] 키를 눌러 다시 플레이하기", True, (blink, 215, 80))
            surface.blit(r_hint, (px + (panel_w - r_hint.get_width()) // 2, py + panel_h - 45))

    def _draw_banner(self, surface: pygame.Surface, title: str, subtitle: str, color: tuple):
        """컷씬 하단 자막 배너"""
        title_font = get_font(18, bold=True)
        sub_font = get_font(14)

        bw = SCREEN_WIDTH - 80
        bh = 72
        bx = 40
        by = SCREEN_HEIGHT - 95

        bar_surf = pygame.Surface((bw, bh), pygame.SRCALPHA)
        pygame.draw.rect(bar_surf, (10, 18, 30, 230), (0, 0, bw, bh), border_radius=8)
        pygame.draw.rect(bar_surf, color, (0, 0, bw, bh), 2, border_radius=8)

        t_surf = title_font.render(title, True, color)
        s_surf = sub_font.render(subtitle, True, (240, 245, 250))

        bar_surf.blit(t_surf, (20, 10))
        bar_surf.blit(s_surf, (20, 38))

        surface.blit(bar_surf, (bx, by))

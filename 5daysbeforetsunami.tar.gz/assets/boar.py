'''
해일 전 3일 (3 Days Before Tsunami)
숲의 멧돼지 (Wild Boar) AI 및 돌진 공격 모듈
'''

import math
import random
import pygame
from settings import (
    COLOR_SHADOW,
    COLOR_BOAR_BODY,
    COLOR_BOAR_DARK,
    COLOR_BOAR_TUSK,
    COLOR_BOAR_EYE_ANGRY,
    BOAR_ATTACK_DAMAGE,
    BOAR_TELEGRAPH_TIME,
    BOAR_PATROL_SPEED,
    BOAR_CHARGE_SPEED,
    BOAR_AGGRO_RADIUS,
    BOAR_DEAGGRO_RADIUS,
    BOAR_TERRITORY_RADIUS,
    BOAR_HIT_COOLDOWN,
)
from fonts import get_font


class WildBoar:
    '''
    숲의 특정 구역을 순찰하는 야생 멧돼지
    - 플레이어 접근 시 0.8초간 공격 예고 후 고속 돌진
    - 공격력: 20
    - 일정 거리 이상 멀어지면 원래 서식지로 복귀
    - 사냥/처치 불가 (불가침 환경 위협 개체)
    '''

    def __init__(self, home_x: float, home_y: float):
        self.home_x = float(home_x)
        self.home_y = float(home_y)
        self.x = float(home_x)
        self.y = float(home_y)

        # 플레이어(48x51)와 비슷한 크기로 확대 (54x44)
        self.width = 54
        self.height = 44

        # 상태 머신: "PATROL", "TELEGRAPH", "CHARGE", "RETURNING"
        self.state = "PATROL"
        self.facing = "left"

        # AI 타이머
        self.state_timer = 0.0
        self.telegraph_timer = 0.0
        self.patrol_wait_timer = random.uniform(1.0, 3.0)
        self.target_patrol_pos = pygame.Vector2(self.home_x, self.home_y)
        self.charge_dir = pygame.Vector2(0, 0)
        self.charge_duration = 0.0
        self.hit_cooldown = 0.0

        # 스프라이트 표면 캐시
        self._create_surfaces()

    @property
    def hitbox(self) -> pygame.Rect:
        return pygame.Rect(int(self.x + 6), int(self.y + 16), 42, 24)

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + self.width // 2, self.y + self.height // 2)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def _create_surfaces(self):
        '''방향별 멧돼지 픽셀 스프라이트 생성 (54x44 크기)'''
        self.surfaces = {}
        for direction in ("left", "right"):
            surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)

            # 1. 몸통 (뚱뚱한 타원/둥근 직사각형)
            body_rect = pygame.Rect(8, 8, 38, 26)
            pygame.draw.ellipse(surf, COLOR_BOAR_BODY, body_rect)
            pygame.draw.ellipse(surf, COLOR_BOAR_DARK, body_rect, 2)

            # 2. 등 갈기/털 (거친 픽셀 브러시)
            pygame.draw.line(surf, COLOR_BOAR_DARK, (16, 7), (36, 7), 3)
            pygame.draw.line(surf, COLOR_BOAR_DARK, (20, 5), (32, 5), 3)

            # 3. 다리 4개
            pygame.draw.rect(surf, COLOR_BOAR_DARK, (12, 28, 6, 12))
            pygame.draw.rect(surf, COLOR_BOAR_DARK, (20, 28, 6, 12))
            pygame.draw.rect(surf, COLOR_BOAR_DARK, (30, 28, 6, 12))
            pygame.draw.rect(surf, COLOR_BOAR_DARK, (38, 28, 6, 12))

            # 4. 머리, 코 및 엄니 (방향별)
            if direction == "left":
                # 주둥이
                pygame.draw.ellipse(surf, COLOR_BOAR_BODY, (2, 14, 18, 18))
                pygame.draw.rect(surf, (55, 35, 25), (2, 18, 4, 8))  # 콧구멍
                # 엄니 (위로 솟은 흰색 뿔)
                pygame.draw.line(surf, COLOR_BOAR_TUSK, (8, 23), (5, 15), 3)
                # 눈
                pygame.draw.circle(surf, (20, 15, 10), (16, 15), 3)
                # 귀
                pygame.draw.polygon(surf, COLOR_BOAR_DARK, [(21, 9), (27, 4), (27, 12)])
            else:
                # 우측 주둥이
                pygame.draw.ellipse(surf, COLOR_BOAR_BODY, (34, 14, 18, 18))
                pygame.draw.rect(surf, (55, 35, 25), (48, 18, 4, 8))
                # 엄니
                pygame.draw.line(surf, COLOR_BOAR_TUSK, (46, 23), (49, 15), 3)
                # 눈
                pygame.draw.circle(surf, (20, 15, 10), (38, 15), 3)
                # 귀
                pygame.draw.polygon(surf, COLOR_BOAR_DARK, [(33, 9), (27, 4), (27, 12)])

            self.surfaces[direction] = surf

        # 바닥 그림자
        self.shadow_surf = pygame.Surface((self.width, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow_surf, COLOR_SHADOW, (2, 1, self.width - 4, 12))

    def update(self, dt: float, player, world) -> tuple:
        '''
        멧돼지 AI 상태 머신 및 돌진/공격 판정
        반환: (공격성공여부: bool, 피해량: float, 알림메시지: str)
        '''
        if self.hit_cooldown > 0:
            self.hit_cooldown -= dt

        attack_hit = False
        damage_dealt = 0.0
        msg = ""

        pos = pygame.Vector2(self.x, self.y)
        player_center = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)
        dist_to_player = self.center.distance_to(player_center)
        dist_to_home = self.center.distance_to(pygame.Vector2(self.home_x, self.home_y))

        # ==========================================
        # 1. 상태 전이 및 로직
        # ==========================================
        if self.state == "PATROL":
            # 플레이어가 가까이 오면 공격 예고 상태로 전이
            if dist_to_player <= BOAR_AGGRO_RADIUS:
                self.state = "TELEGRAPH"
                self.telegraph_timer = BOAR_TELEGRAPH_TIME
                self.facing = "left" if player_center.x < self.center.x else "right"
            else:
                # 서식지 구역 내 무작위 순찰
                self.patrol_wait_timer -= dt
                if self.patrol_wait_timer <= 0:
                    # 새로운 순찰 목적지 선택
                    angle = random.uniform(0, math.pi * 2)
                    dist = random.uniform(20, BOAR_TERRITORY_RADIUS)
                    self.target_patrol_pos = pygame.Vector2(
                        self.home_x + math.cos(angle) * dist,
                        self.home_y + math.sin(angle) * dist,
                    )
                    self.patrol_wait_timer = random.uniform(3.0, 6.0)

                # 목적지로 이동
                dir_vec = self.target_patrol_pos - self.center
                if dir_vec.length_squared() > 100:
                    dir_vec = dir_vec.normalize()
                    self.x += dir_vec.x * BOAR_PATROL_SPEED * dt
                    self.y += dir_vec.y * BOAR_PATROL_SPEED * dt
                    self.facing = "left" if dir_vec.x < 0 else "right"

        elif self.state == "TELEGRAPH":
            # 0.8초간 공격 예고 (발을 구르고 붉은 느낌표 표시)
            self.facing = "left" if player_center.x < self.center.x else "right"
            self.telegraph_timer -= dt

            # 플레이어가 너무 멀어지면 어그로 해제
            if dist_to_player > BOAR_DEAGGRO_RADIUS:
                self.state = "RETURNING"
            elif self.telegraph_timer <= 0:
                # 0.8초 예고 종료 -> 플레이어 방향으로 돌진 개시!
                self.state = "CHARGE"
                self.charge_dir = (player_center - self.center)
                if self.charge_dir.length_squared() > 0:
                    self.charge_dir = self.charge_dir.normalize()
                else:
                    self.charge_dir = pygame.Vector2(-1, 0)
                self.charge_duration = 1.1

        elif self.state == "CHARGE":
            # 돌진 이동
            self.x += self.charge_dir.x * BOAR_CHARGE_SPEED * dt
            self.y += self.charge_dir.y * BOAR_CHARGE_SPEED * dt
            self.facing = "left" if self.charge_dir.x < 0 else "right"
            self.charge_duration -= dt

            # 플레이어 충돌 공격 판정 (공격력 10)
            if self.hitbox.colliderect(player.hitbox) and self.hit_cooldown <= 0:
                attack_hit = True
                damage_dealt = BOAR_ATTACK_DAMAGE
                player.survival.health = max(0.0, player.survival.health - damage_dealt)
                self.hit_cooldown = BOAR_HIT_COOLDOWN
                msg = f"멧돼지의 돌진에 부딪혔습니다! 체력 -{int(damage_dealt)}"

                # 플레이어 밀쳐내기 (넉백)
                knockback = self.charge_dir * 18
                player.x += knockback.x
                player.y += knockback.y

            # 돌진 종료 시
            if self.charge_duration <= 0 or dist_to_home > BOAR_TERRITORY_RADIUS * 1.5:
                # 플레이어가 여전히 사정거리 내에 있고 가까우면 재돌진 예고, 멀면 복귀
                if dist_to_player <= BOAR_AGGRO_RADIUS:
                    self.state = "TELEGRAPH"
                    self.telegraph_timer = BOAR_TELEGRAPH_TIME
                else:
                    self.state = "RETURNING"

        elif self.state == "RETURNING":
            # 원래 서식지로 복귀
            home_vec = pygame.Vector2(self.home_x, self.home_y) - self.center
            if home_vec.length_squared() > 200:
                dir_vec = home_vec.normalize()
                self.x += dir_vec.x * (BOAR_PATROL_SPEED * 1.3) * dt
                self.y += dir_vec.y * (BOAR_PATROL_SPEED * 1.3) * dt
                self.facing = "left" if dir_vec.x < 0 else "right"
            else:
                self.state = "PATROL"
                self.patrol_wait_timer = 2.0

        return attack_hit, damage_dealt, msg

    def draw(self, target_surface: pygame.Surface, camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 1. 그림자
        target_surface.blit(self.shadow_surf, (screen_x, screen_y + self.height - 8))

        # 2. 본체 스프라이트
        sprite = self.surfaces.get(self.facing, self.surfaces["left"])

        # 공격 예고(TELEGRAPH) 중일 때 약간의 붉은 점멸/진동 효과
        draw_x, draw_y = screen_x, screen_y
        if self.state == "TELEGRAPH":
            draw_x += random.randint(-1, 1)
            draw_y += random.randint(-1, 1)

        target_surface.blit(sprite, (draw_x, draw_y))

        # 3. 공격 예고 표시 (머리 위 붉은 느낌표 및 화난 눈)
        if self.state == "TELEGRAPH":
            # 붉은 눈빛
            eye_x = draw_x + (16 if self.facing == "left" else 38)
            pygame.draw.circle(target_surface, COLOR_BOAR_EYE_ANGRY, (eye_x, draw_y + 15), 3)

            # 느낌표 말풍선
            alert_font = get_font(16, bold=True)
            alert_surf = alert_font.render("!", True, (255, 40, 40))
            bg_rect = pygame.Rect(draw_x + self.width // 2 - 8, draw_y - 18, 16, 16)
            pygame.draw.rect(target_surface, (20, 20, 20, 220), bg_rect, border_radius=3)
            pygame.draw.rect(target_surface, (255, 60, 60), bg_rect, 1, border_radius=3)
            target_surface.blit(alert_surf, (draw_x + self.width // 2 - 4, draw_y - 20))

        elif self.state == "CHARGE":
            # 돌진 중 붉은 눈빛 유지
            eye_x = draw_x + (16 if self.facing == "left" else 38)
            pygame.draw.circle(target_surface, COLOR_BOAR_EYE_ANGRY, (eye_x, draw_y + 15), 3)
            # 돌진 흙먼지 효과
            dust_x = draw_x + (self.width - 2 if self.facing == "left" else 2)
            pygame.draw.circle(target_surface, (180, 160, 130, 120), (dust_x, draw_y + self.height - 4), 4)

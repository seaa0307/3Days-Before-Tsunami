'''
해일 전 3일 (3 Days Before Tsunami)
시간 및 낮/밤 주기 관리 시스템
'''

import math
from settings import (
    TOTAL_DAYS,
    DAY_NIGHT_SCHEDULE,
    DARKNESS_MAX_ALPHA,
    SLEEP_DISABLED_DAY,
)


class TimeSystem:
    '''게임 내 3일간의 낮과 밤 시간 흐름을 관리하는 시스템'''

    def __init__(self):
        self.current_day = 1
        self.day_time = 0.0  # 현재 일차에서 경과된 시간 (초)
        self.tsunami_arrived = False
        self.just_became_night = False
        self.just_became_day = False
        self._prev_is_night = False

    @property
    def current_schedule(self) -> dict:
        '''현재 일차의 낮/밤 시간 설정 반환'''
        return DAY_NIGHT_SCHEDULE.get(self.current_day, {"day": 120.0, "night": 180.0})

    @property
    def day_duration(self) -> float:
        return self.current_schedule["day"]

    @property
    def night_duration(self) -> float:
        return self.current_schedule["night"]

    @property
    def total_day_seconds(self) -> float:
        return self.day_duration + self.night_duration

    @property
    def is_night(self) -> bool:
        '''현재 밤인지 여부'''
        return self.day_time >= self.day_duration

    @property
    def remaining_phase_time(self) -> float:
        '''현재 낮 또는 밤에서 남은 시간 (초)'''
        if not self.is_night:
            return max(0.0, self.day_duration - self.day_time)
        else:
            return max(0.0, self.total_day_seconds - self.day_time)

    def get_darkness_alpha(self) -> int:
        '''
        현재 시각에 따른 부드러운 밤 암전 투명도 (0 ~ DARKNESS_MAX_ALPHA)
        - 낮 종료 20초 전부터 서서히 황혼(Dusk)이 찾아옴
        - 밤 종료 15초 전부터 서서히 여명(Dawn)이 밝아옴
        '''
        if self.tsunami_arrived:
            return DARKNESS_MAX_ALPHA

        # 1. 낮 시간대
        if not self.is_night:
            time_until_night = self.day_duration - self.day_time
            if time_until_night < 20.0:
                # 황혼 전이 (0 -> DARKNESS_MAX_ALPHA)
                factor = 1.0 - (time_until_night / 20.0)
                return int(DARKNESS_MAX_ALPHA * factor)
            return 0

        # 2. 밤 시간대
        time_until_day = self.total_day_seconds - self.day_time
        if time_until_day < 15.0:
            # 여명 전이 (DARKNESS_MAX_ALPHA -> 0)
            factor = time_until_day / 15.0
            return int(DARKNESS_MAX_ALPHA * factor)

        return DARKNESS_MAX_ALPHA

    def update(self, dt: float) -> list:
        '''
        시간 갱신 및 날짜/주기 전이 이벤트 발생
        반환: [(이벤트타입, 메시지), ...]
        '''
        events = []
        if self.tsunami_arrived:
            return events

        self.day_time += dt

        # 낮/밤 전이 감지
        curr_is_night = self.is_night
        if curr_is_night and not self._prev_is_night:
            events.append(("NIGHT_START", f"{self.current_day}일 차의 밤이 찾아왔습니다! 시야가 좁아지고 체온이 떨어집니다."))
        elif not curr_is_night and self._prev_is_night:
            events.append(("DAY_START", f"{self.current_day}일 차의 아침이 밝았습니다!"))

        self._prev_is_night = curr_is_night

        # 하루 종료 및 다음 날 전이
        if self.day_time >= self.total_day_seconds:
            if self.current_day < TOTAL_DAYS:
                self.current_day += 1
                self.day_time = 0.0
                self._prev_is_night = False
                events.append(("NEW_DAY", f"새로운 날이 시작되었습니다! [{self.current_day}일 차]"))
            else:
                self.tsunami_arrived = True
                events.append(("TSUNAMI", "3일이 모두 지났습니다! 거대한 해일이 섬을 덮쳐옵니다!"))

        return events

    def can_sleep(self) -> tuple:
        '''
        간이 거처 수면 가능 여부 검사
        반환: (가능여부: bool, 사유메시지: str)
        '''
        if self.current_day >= SLEEP_DISABLED_DAY:
            return False, "3일 차에는 해일이 임박하여 잠을 잘 수 없습니다!"
        if not self.is_night:
            return False, "밤에만 잠을 잘 수 있습니다."
        return True, "수면 가능"

    def skip_night(self) -> tuple:
        '''
        수면을 통해 남은 밤 시간을 건너뛰고 다음 날 아침으로 진행
        반환: (성공여부: bool, 결과메시지: str)
        '''
        can_do, reason = self.can_sleep()
        if not can_do:
            return False, reason

        # 다음 날 아침으로 즉시 전이
        if self.current_day < TOTAL_DAYS:
            self.current_day += 1
            self.day_time = 0.0
            self._prev_is_night = False
            return True, f"잠을 자고 일어났습니다. [{self.current_day}일 차 아침이 밝았습니다! 체력 +15 회복]"
        else:
            return False, "3일 차에는 잠을 잘 수 없습니다."

    def get_phase_text(self) -> str:
        '''UI 표시용 시간 문자열'''
        rem = int(self.remaining_phase_time)
        phase_name = "밤" if self.is_night else "낮"
        return f"{self.current_day}일 차 ({phase_name} {rem}초 남음)"

'''
해일 전 3일 (3 Days Before Tsunami)
플레이어 클래스, 인벤토리 및 생존 시스템 연동 모듈
'''

import math
import pygame
from settings import (
    PLAYER_SPEED,
    PLAYER_WIDTH,
    PLAYER_HEIGHT,
    TILE_SIZE,
    HITBOX_WIDTH,
    HITBOX_HEIGHT,
    HITBOX_OFFSET_Y,
    COLOR_SHADOW,
)
from image_assets import get_player_frames, get_axe_frames, load_image, scale_pixel_art
from inventory import Inventory
from survival import SurvivalStats


class Player:
    def __init__(self, x: float, y: float):
        # 플레이어 위치 (스프라이트 좌상단 기준 좌표)
        self.x = float(x)
        self.y = float(y)
        self.width = PLAYER_WIDTH
        self.height = PLAYER_HEIGHT
        self.speed = PLAYER_SPEED

        # 탑뷰 2.5D 입체감을 위한 발 부분 충돌 박스(Hitbox)
        self.hitbox_width = HITBOX_WIDTH
        self.hitbox_height = HITBOX_HEIGHT
        self.hitbox_offset_x = (self.width - self.hitbox_width) // 2
        self.hitbox_offset_y = HITBOX_OFFSET_Y

        # 상태 및 방향 ('down', 'up', 'left', 'right')
        self.facing = "down"
        self.is_moving = False
        self.near_campfire = False
        self.is_visible = True
        self.is_lying_down = False
        self.animation_timer = 0.0
        self.animation_frame = 0

        # 플레이어 인벤토리 및 생존 수치(체력, 허기, 체온)
        self.inventory = Inventory()
        self.survival = SurvivalStats()

        # 도끼질 애니메이션 상태
        self.is_chopping = False
        self.chop_timer = 0.0
        self.chop_duration = 0.45
        self.chop_target = None
        self.axe_frame_index = 0

        # 방향별 걷기 및 도끼질 스프라이트 로드
        self._create_surfaces()

    @property
    def hitbox(self) -> pygame.Rect:
        '''충돌 판정에 사용하는 플레이어 발 밑 히트박스'''
        return pygame.Rect(
            int(self.x + self.hitbox_offset_x),
            int(self.y + self.hitbox_offset_y),
            self.hitbox_width,
            self.hitbox_height,
        )

    @property
    def render_rect(self) -> pygame.Rect:
        '''렌더링 및 Y-정렬 기준 사각형'''
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)

    def _create_surfaces(self):
        '''방향별 걷기 및 도끼질 스프라이트 시트를 원본 비율 그대로 3배 정수 스케일링'''
        self.surfaces = {}
        for direction in ("down", "up", "left", "right"):
            frames = get_player_frames(direction)
            self.surfaces[direction] = tuple(
                scale_pixel_art(frame, 3)
                for frame in frames
            )
        self.down_surface = scale_pixel_art(load_image("Player_down.png"), 3)

        # 도끼질 애니메이션 (24x24 원본을 3배 스케일한 72x72)
        self.axe_surfaces = {}
        for direction in ("down", "up", "left", "right"):
            axe_frames = get_axe_frames(direction)
            self.axe_surfaces[direction] = tuple(
                scale_pixel_art(frame, 3)
                for frame in axe_frames
            )

        # 발 밑 반투명 그림자 서피스
        self.shadow_surf = pygame.Surface((self.width - 8, 12), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow_surf, COLOR_SHADOW, (0, 0, self.width - 8, 12))

    def start_chopping(self, target_tree):
        '''마지막 이동 방향을 유지한 채 도끼질 애니메이션 시작'''
        self.is_chopping = True
        self.chop_timer = 0.0
        self.chop_target = target_tree
        self.is_moving = False
        self.axe_frame_index = 0

    def _update_animation(self, dt: float):
        if not self.is_moving:
            self.animation_frame = 0
            self.animation_timer = 0.0
            return

        self.animation_timer += dt
        while self.animation_timer >= 0.14:
            self.animation_timer -= 0.14
            self.animation_frame = (self.animation_frame + 1) % 4

    def handle_input(self, can_move: bool = True) -> pygame.Vector2:
        '''키 입력 처리 (WASD 이동)'''
        keys = pygame.key.get_pressed()
        move_vec = pygame.Vector2(0, 0)

        if not can_move or self.survival.is_dead:
            self.is_moving = False
            return move_vec

        # WASD 이동 입력 (방향키도 지원)
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            move_vec.y -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            move_vec.y += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            move_vec.x -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            move_vec.x += 1

        # 대각선 이동 시 속도 정규화
        if move_vec.length_squared() > 0:
            move_vec = move_vec.normalize()
            self.is_moving = True

            # 바라보는 방향 갱신
            if abs(move_vec.x) > abs(move_vec.y):
                self.facing = "right" if move_vec.x > 0 else "left"
            else:
                self.facing = "down" if move_vec.y > 0 else "up"
        else:
            self.is_moving = False

        return move_vec

    def update(self, dt: float, world, can_move: bool = True) -> list:
        '''플레이어 이동, 도끼질 애니메이션 및 생존 수치 갱신'''
        # 1. 모닥불 근접 여부 확인 (체온 회복 판정)
        self.near_campfire = any(cf.is_player_near(self) for cf in world.campfires)

        # 2. 생존 수치(체력, 허기, 체온) 갱신
        is_night = world.time_system.is_night
        alerts = self.survival.update(dt, is_night, self.near_campfire, world.time_system.current_day)

        # 3. 사망 상태면 이동 및 동작 불가
        if self.survival.is_dead:
            self.is_moving = False
            self.is_chopping = False
            self._update_animation(0.0)
            return alerts

        # 4. 도끼질 애니메이션 진행 중인 경우 처리
        if self.is_chopping:
            self.is_moving = False
            self.chop_timer += dt
            frames = self.axe_surfaces.get(self.facing, self.axe_surfaces["down"])
            self.axe_frame_index = min(len(frames) - 1, int((self.chop_timer / self.chop_duration) * len(frames)))

            # 도끼질 완료 시점 -> 나무 벌목 완료 처리 및 드롭 아이템 생성
            if self.chop_timer >= self.chop_duration:
                if self.chop_target is not None:
                    message = self.chop_target.finish_chopping(self, world)
                    if message:
                        alerts.append(("AXE_HIT", message))
                    if message and not message.startswith("나무를 찍었습니다!"):
                        alerts.append(("CHOP", message))
                    self.chop_target = None
                self.is_chopping = False
                self.chop_timer = 0.0

            return alerts

        # 5. 키 입력 및 이동
        move_vec = self.handle_input(can_move)
        self._update_animation(dt)
        if not self.is_moving:
            return alerts

        # X축 이동 및 충돌 검사
        dx = move_vec.x * self.speed * dt
        self.x += dx
        current_hitbox = self.hitbox
        for obstacle_rect in world.get_colliding_obstacles(current_hitbox):
            if current_hitbox.colliderect(obstacle_rect):
                if dx > 0:
                    self.x = obstacle_rect.left - self.hitbox_offset_x - self.hitbox_width
                elif dx < 0:
                    self.x = obstacle_rect.right - self.hitbox_offset_x
                current_hitbox = self.hitbox

        # Y축 이동 및 충돌 검사
        dy = move_vec.y * self.speed * dt
        self.y += dy
        current_hitbox = self.hitbox
        for obstacle_rect in world.get_colliding_obstacles(current_hitbox):
            if current_hitbox.colliderect(obstacle_rect):
                if dy > 0:
                    self.y = obstacle_rect.top - self.hitbox_offset_y - self.hitbox_height
                elif dy < 0:
                    self.y = obstacle_rect.bottom - self.hitbox_offset_y
                current_hitbox = self.hitbox

        return alerts

    def draw(self, target_surface: pygame.Surface, camera):
        '''카메라 좌표계를 반영하여 플레이어 렌더링'''
        if not self.is_visible:
            return

        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 발 밑 그림자
        shadow_x = int(self.x + (self.width - self.shadow_surf.get_width()) / 2 - camera.x)
        shadow_y = int(self.y + self.height - 10 - camera.y)
        target_surface.blit(self.shadow_surf, (shadow_x, shadow_y))

        # 1. 도끼질 애니메이션 중인 경우: Axe_front, back, left, right 스프라이트 렌더링
        if self.is_chopping:
            frames = self.axe_surfaces.get(self.facing, self.axe_surfaces["down"])
            sprite = frames[self.axe_frame_index]
            # 72x72 프레임을 플레이어 발 위치(screen_x-12, screen_y-21)에 정렬하여 블릿
            sprite_x = screen_x - (sprite.get_width() - self.width) // 2
            sprite_y = screen_y - (sprite.get_height() - self.height)
            target_surface.blit(sprite, (sprite_x, sprite_y))
        else:
            if self.is_lying_down:
                sprite = self.down_surface
            else:
                # 2. 일반 걷기/정지 스프라이트
                frames = self.surfaces.get(self.facing, self.surfaces["down"])
                sprite = frames[self.animation_frame]
            sprite_x = int(self.x + (self.width - sprite.get_width()) / 2 - camera.x)
            sprite_y = int(self.y + (self.height - sprite.get_height()) / 2 - camera.y)
            target_surface.blit(sprite, (sprite_x, sprite_y))

        # 3. 횃불 휴대 시 조명 표현 (도끼 보유 시 옆에 뜨던 작게 뜨는 이미지는 제거됨)
        if self.inventory.has_item("torch"):
            torch_x = screen_x + (self.width - 4 if self.facing != "left" else -2)
            torch_y = screen_y + 20
            pygame.draw.line(target_surface, (110, 75, 45), (torch_x, torch_y + 8), (torch_x + 4, torch_y), 2)
            pygame.draw.circle(target_surface, (245, 90, 30), (torch_x + 4, torch_y), 4)
            pygame.draw.circle(target_surface, (255, 215, 60), (torch_x + 4, torch_y), 2)

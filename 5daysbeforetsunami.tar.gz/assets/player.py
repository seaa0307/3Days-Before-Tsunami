"""
해일 전 5일 (5 Days Before Tsunami)
플레이어 클래스, 인벤토리 및 생존 시스템 연동 모듈
"""

import math
import pygame
from settings import (
    PLAYER_SPEED,
    PLAYER_WIDTH,
    PLAYER_HEIGHT,
    HITBOX_WIDTH,
    HITBOX_HEIGHT,
    HITBOX_OFFSET_Y,
    COLOR_PLAYER_SKIN,
    COLOR_PLAYER_SHIRT,
    COLOR_PLAYER_PANTS,
    COLOR_PLAYER_HAIR,
    COLOR_SHADOW,
)
from inventory import Inventory
from survival import SurvivalStats


class Player:
    def __init__(self, x: float, y: float):
        # 플레이어 위치 (스프라이트 좌상단 기준 좌표)
        self.x = float(x)
        self.y = float(y)
        self.width = PLAYER_WIDTH
        self.height = PLAYER_HEIGHT
        self.speed = PLAYER_SPEED

        # 탑뷰 2.5D 입체감을 위한 발 부분 충돌 박스(Hitbox)
        self.hitbox_width = HITBOX_WIDTH
        self.hitbox_height = HITBOX_HEIGHT
        self.hitbox_offset_x = (self.width - self.hitbox_width) // 2
        self.hitbox_offset_y = HITBOX_OFFSET_Y

        # 상태 및 방향 ('down', 'up', 'left', 'right')
        self.facing = "down"
        self.is_moving = False
        self.is_interacting = False
        self.e_just_pressed = False
        self._prev_e_down = False
        self.near_campfire = False
        self.is_visible = True

        # 플레이어 인벤토리 및 생존 수치(체력, 허기, 체온)
        self.inventory = Inventory()
        self.survival = SurvivalStats()

        # 픽셀 아트 임시 스프라이트 표면 생성
        self._create_surfaces()

    @property
    def hitbox(self) -> pygame.Rect:
        """충돌 판정에 사용하는 플레이어 발 밑 히트박스"""
        return pygame.Rect(
            int(self.x + self.hitbox_offset_x),
            int(self.y + self.hitbox_offset_y),
            self.hitbox_width,
            self.hitbox_height,
        )

    @property
    def render_rect(self) -> pygame.Rect:
        """렌더링 및 Y-정렬 기준 사각형"""
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)

    def _create_surfaces(self):
        """방향별 임시 픽셀 아트 스프라이트 표면 생성"""
        self.surfaces = {}
        for direction in ("down", "up", "left", "right"):
            surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)

            # 1. 머리 (가로 20, 세로 16)
            head_rect = pygame.Rect(6, 4, 20, 16)
            pygame.draw.rect(surf, COLOR_PLAYER_HAIR, head_rect)
            # 얼굴 노출 영역
            if direction != "up":
                face_rect = pygame.Rect(8, 10, 16, 10)
                pygame.draw.rect(surf, COLOR_PLAYER_SKIN, face_rect)
                # 눈 (방향에 따른 시선)
                if direction == "down":
                    pygame.draw.rect(surf, (20, 20, 20), (11, 13, 3, 3))
                    pygame.draw.rect(surf, (20, 20, 20), (18, 13, 3, 3))
                elif direction == "left":
                    pygame.draw.rect(surf, (20, 20, 20), (8, 13, 3, 3))
                    pygame.draw.rect(surf, (20, 20, 20), (13, 13, 3, 3))
                elif direction == "right":
                    pygame.draw.rect(surf, (20, 20, 20), (16, 13, 3, 3))
                    pygame.draw.rect(surf, (20, 20, 20), (21, 13, 3, 3))

            # 2. 몸통 / 셔츠 (가로 22, 세로 14)
            torso_rect = pygame.Rect(5, 20, 22, 14)
            pygame.draw.rect(surf, COLOR_PLAYER_SHIRT, torso_rect)
            # 가방 끈
            pygame.draw.rect(surf, (180, 60, 35), (9, 20, 4, 14))

            # 3. 바지 및 다리 (가로 18, 세로 10)
            pants_rect = pygame.Rect(7, 34, 18, 10)
            pygame.draw.rect(surf, COLOR_PLAYER_PANTS, pants_rect)
            # 다리 분리선
            pygame.draw.line(surf, (30, 40, 60), (15, 36), (15, 43), 2)

            # 픽셀 테두리 외곽선
            pygame.draw.rect(surf, (20, 20, 24), (5, 4, 22, 40), 1)

            self.surfaces[direction] = surf

        # 발 밑 반투명 그림자 서피스
        self.shadow_surf = pygame.Surface((self.width, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow_surf, COLOR_SHADOW, (2, 2, self.width - 4, 10))

    def handle_input(self, can_move: bool = True) -> pygame.Vector2:
        """키 입력 처리 (WASD 이동 및 E 상호작용)"""
        keys = pygame.key.get_pressed()
        move_vec = pygame.Vector2(0, 0)

        # E 키 1회 누름(Down) 이벤트 감지
        e_is_down = keys[pygame.K_e]
        self.e_just_pressed = e_is_down and not self._prev_e_down
        self._prev_e_down = e_is_down
        self.is_interacting = e_is_down

        if not can_move or self.survival.is_dead:
            self.is_moving = False
            return move_vec

        # WASD 이동 입력 (방향키도 지원)
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            move_vec.y -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            move_vec.y += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            move_vec.x -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            move_vec.x += 1

        # 대각선 이동 시 속도 정규화
        if move_vec.length_squared() > 0:
            move_vec = move_vec.normalize()
            self.is_moving = True

            # 바라보는 방향 갱신
            if abs(move_vec.x) > abs(move_vec.y):
                self.facing = "right" if move_vec.x > 0 else "left"
            else:
                self.facing = "down" if move_vec.y > 0 else "up"
        else:
            self.is_moving = False

        return move_vec

    def update(self, dt: float, world, can_move: bool = True) -> list:
        """플레이어 이동 및 생존 수치 갱신"""
        # 1. 모닥불 근접 여부 확인 (체온 회복 판정)
        self.near_campfire = any(cf.is_player_near(self) for cf in world.campfires)

        # 2. 생존 수치(체력, 허기, 체온) 갱신
        is_night = world.time_system.is_night
        alerts = self.survival.update(dt, is_night, self.near_campfire)

        # 3. 사망 상태면 이동 불가
        if self.survival.is_dead:
            self.is_moving = False
            return alerts

        # 4. 키 입력 및 이동
        move_vec = self.handle_input(can_move)
        if not self.is_moving:
            return alerts

        # X축 이동 및 충돌 검사
        dx = move_vec.x * self.speed * dt
        self.x += dx
        current_hitbox = self.hitbox
        for obstacle_rect in world.get_colliding_obstacles(current_hitbox):
            if current_hitbox.colliderect(obstacle_rect):
                if dx > 0:
                    self.x = obstacle_rect.left - self.hitbox_offset_x - self.hitbox_width
                elif dx < 0:
                    self.x = obstacle_rect.right - self.hitbox_offset_x
                current_hitbox = self.hitbox

        # Y축 이동 및 충돌 검사
        dy = move_vec.y * self.speed * dt
        self.y += dy
        current_hitbox = self.hitbox
        for obstacle_rect in world.get_colliding_obstacles(current_hitbox):
            if current_hitbox.colliderect(obstacle_rect):
                if dy > 0:
                    self.y = obstacle_rect.top - self.hitbox_offset_y - self.hitbox_height
                elif dy < 0:
                    self.y = obstacle_rect.bottom - self.hitbox_offset_y
                current_hitbox = self.hitbox

        return alerts

    def draw(self, target_surface: pygame.Surface, camera):
        """카메라 좌표계를 반영하여 플레이어 렌더링"""
        if not self.is_visible:
            return

        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)

        # 발 밑 그림자
        shadow_y = int(self.y + self.height - 10 - camera.y)
        target_surface.blit(self.shadow_surf, (screen_x, shadow_y))

        # 방향별 플레이어 본체 스프라이트
        sprite = self.surfaces.get(self.facing, self.surfaces["down"])
        target_surface.blit(sprite, (screen_x, screen_y))

        # 장비 아이템 표현 (돌도끼 또는 횃불)
        if self.inventory.has_tool("stone_axe"):
            axe_x = screen_x + (self.width - 4 if self.facing != "left" else -2)
            axe_y = screen_y + 22
            pygame.draw.line(target_surface, (100, 65, 40), (axe_x, axe_y + 8), (axe_x + 6, axe_y), 2)
            pygame.draw.polygon(target_surface, (170, 175, 185), [(axe_x + 4, axe_y - 2), (axe_x + 9, axe_y), (axe_x + 6, axe_y + 4)])
        elif self.inventory.has_item("torch"):
            torch_x = screen_x + (self.width - 4 if self.facing != "left" else -2)
            torch_y = screen_y + 20
            pygame.draw.line(target_surface, (110, 75, 45), (torch_x, torch_y + 8), (torch_x + 4, torch_y), 2)
            pygame.draw.circle(target_surface, (245, 90, 30), (torch_x + 4, torch_y), 4)
            pygame.draw.circle(target_surface, (255, 215, 60), (torch_x + 4, torch_y), 2)

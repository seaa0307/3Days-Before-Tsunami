'''
해일 전 3일 (3 Days Before Tsunami)
플레이어 인벤토리 및 제작 처리 모듈
'''

from typing import Dict, Tuple, List, Optional
from items import get_item, get_recipe, RECIPES


class Inventory:
    '''아이템 보관, 수량 관리 및 제작 로직을 담당하는 인벤토리 클래스'''

    def __init__(self):
        # 아이템 ID -> 보유 수량
        self._items: Dict[str, int] = {}
        self._item_order: List[Optional[str]] = []

    @property
    def items(self) -> Dict[str, int]:
        '''보유 중인 아이템 딕셔너리 (복사본 반환)'''
        return dict(self._items)

    def get_count(self, item_id: str) -> int:
        '''특정 아이템의 보유 수량 반환'''
        return self._items.get(item_id, 0)

    def has_item(self, item_id: str, count: int = 1) -> bool:
        '''특정 아이템을 필요한 수량만큼 보유하고 있는지 확인'''
        return self.get_count(item_id) >= count

    def add_item(self, item_id: str, count: int = 1) -> int:
        '''아이템 추가 후 총 수량 반환'''
        if count <= 0:
            return self.get_count(item_id)
        current = self._items.get(item_id, 0)
        self._items[item_id] = current + count
        if item_id not in self._item_order:
            empty_index = next(
                (index for index, slot_item in enumerate(self._item_order) if slot_item is None),
                None,
            )
            if empty_index is None:
                self._item_order.append(item_id)
            else:
                self._item_order[empty_index] = item_id
        return self._items[item_id]

    def remove_item(self, item_id: str, count: int = 1) -> bool:
        '''아이템 차감. 수량이 부족하면 차감하지 않고 False 반환'''
        if count <= 0:
            return True
        current = self.get_count(item_id)
        if current < count:
            return False

        if current == count:
            del self._items[item_id]
            self._item_order[self._item_order.index(item_id)] = None
            while self._item_order and self._item_order[-1] is None:
                self._item_order.pop()
        else:
            self._items[item_id] = current - count
        return True

    @property
    def item_order(self) -> List[Optional[str]]:
        return list(self._item_order)

    def move_item(self, source_id: str, target_id: Optional[str] = None, target_index: Optional[int] = None):
        '''Move an inventory stack or swap it with another stack.'''
        if source_id not in self._item_order:
            return
        source_index = self._item_order.index(source_id)
        if target_id is not None and target_id in self._item_order:
            target_index = self._item_order.index(target_id)
        if target_index is None:
            return
        target_index = max(0, target_index)
        if target_index == source_index:
            return
        while len(self._item_order) <= target_index:
            self._item_order.append(None)
        self._item_order[source_index], self._item_order[target_index] = (
            self._item_order[target_index],
            self._item_order[source_index],
        )

    def has_tool(self, tool_id: str) -> bool:
        '''해당 도구를 소지하고 있는지 확인'''
        return self.get_count(tool_id) > 0

    def check_ingredients(self, ingredients: Dict[str, int]) -> Tuple[bool, Dict[str, Tuple[int, int]]]:
        '''
        필요 재료 충족 여부 검사
        반환: (제작가능여부, {재료ID: (보유수량, 필요수량)})
        '''
        all_met = True
        status: Dict[str, Tuple[int, int]] = {}

        for mat_id, need_count in ingredients.items():
            have_count = self.get_count(mat_id)
            status[mat_id] = (have_count, need_count)
            if have_count < need_count:
                all_met = False

        return all_met, status

    def can_craft(self, recipe_id: str) -> Tuple[bool, str, Dict[str, Tuple[int, int]]]:
        '''
        레시피 제작 가능 여부 상세 검사
        반환: (가능여부, 사유메시지, 재료보유현황)
        '''
        recipe = get_recipe(recipe_id)
        if not recipe:
            return False, "존재하지 않는 제작법입니다.", {}

        ingredients = recipe.get("ingredients", {})
        all_met, status = self.check_ingredients(ingredients)

        if not all_met:
            # 부족한 재료 목록 문자열 생성
            missing_items = []
            for mat_id, (have, need) in status.items():
                if have < need:
                    mat_name = get_item(mat_id)["name"]
                    missing_items.append(f"{mat_name}({have}/{need})")
            return False, f"재료 부족: {', '.join(missing_items)}", status

        return True, "제작 가능", status

    def craft(self, recipe_id: str) -> Tuple[bool, str]:
        '''
        제작 시도. 재료가 부족하면 제작을 차단하고 상세 사유를 반환.
        성공 시 재료를 차감하고 완성품을 인벤토리에 추가.
        '''
        can_make, reason, _ = self.can_craft(recipe_id)
        if not can_make:
            return False, reason

        recipe = get_recipe(recipe_id)
        ingredients = recipe.get("ingredients", {})
        result_id = recipe.get("result_id", recipe_id)
        yield_count = recipe.get("yield_count", 1)

        # 재료 차감
        for mat_id, count in ingredients.items():
            self.remove_item(mat_id, count)

        # 완성품 지급
        self.add_item(result_id, yield_count)
        item_name = recipe.get("name", result_id)
        return True, f"'{item_name}' 제작 완료!"

    def get_item_list(self) -> List[Tuple[str, int, dict]]:
        '''인벤토리에 있는 아이템 목록 정렬 반환 [(id, count, metadata), ...]'''
        result = []
        for item_id in self._item_order:
            if item_id is None:
                continue
            count = self._items.get(item_id, 0)
            if count > 0:
                result.append((item_id, count, get_item(item_id)))
        return result

"""
해일 전 5일 (5 Days Before Tsunami)
월드 맵, 타일 시스템, 멧돼지 및 탐험가의 일지 연동 모듈
"""

import math
import random
import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    TILE_SIZE,
    MAP_COLS,
    MAP_ROWS,
    WORLD_WIDTH,
    WORLD_HEIGHT,
    COLOR_OCEAN_DEEP,
    COLOR_OCEAN_SHALLOW,
    COLOR_BEACH_SAND,
    COLOR_BEACH_DARK,
    COLOR_GRASS,
    COLOR_GRASS_DARK,
    COLOR_ROCK,
    COLOR_ROCK_LIGHT,
    COLOR_ROCK_DARK,
    COLOR_SHADOW,
    NIGHT_VISION_RADIUS_BASE,
    TORCH_VISION_BONUS,
    CAMPFIRE_LIGHT_RADIUS,
)
from time_system import TimeSystem
from structures import PlacedCampfire, PlacedShelter
from journal import PlacedJournal
from boar import WildBoar
from raft import RaftSlipway
from resource_nodes import (
    BranchNode,
    StoneNode,
    FiberNode,
    BerryBushNode,
    CoconutNode,
    InteractableTree,
)

# 타일 종류 ID
TILE_DEEP_WATER = 0     # 깊은 바다 (이동 불가)
TILE_SHALLOW_WATER = 1  # 해안 얕은 바다 (파도 거품)
TILE_SAND = 2           # 모래사장
TILE_GRASS = 3          # 초원
TILE_DARK_GRASS = 4     # 고지대 잔디

_LIGHT_MASK_CACHE = {}


def get_light_mask(radius: int) -> pygame.Surface:
    """부드러운 원형 빛 구멍 마스크 생성 및 캐시"""
    radius = int(radius)
    if radius in _LIGHT_MASK_CACHE:
        return _LIGHT_MASK_CACHE[radius]

    size = radius * 2
    mask = pygame.Surface((size, size), pygame.SRCALPHA)
    step = 4
    for r in range(radius, 0, -step):
        factor = (1.0 - (r / radius) ** 1.6)
        alpha = int(255 * factor)
        pygame.draw.circle(mask, (0, 0, 0, alpha), (radius, radius), r)

    _LIGHT_MASK_CACHE[radius] = mask
    return mask


class Camera:
    """플레이어를 부드럽게 추적하고 월드 경계 내로 제한하는 카메라"""

    def __init__(self, world_width: int, world_height: int):
        self.world_width = world_width
        self.world_height = world_height
        self.x = 0.0
        self.y = 0.0

    def update(self, target_rect: pygame.Rect):
        target_x = target_rect.centerx - SCREEN_WIDTH / 2
        target_y = target_rect.centery - SCREEN_HEIGHT / 2

        self.x += (target_x - self.x) * 0.12
        self.y += (target_y - self.y) * 0.12

        max_x = max(0, self.world_width - SCREEN_WIDTH)
        max_y = max(0, self.world_height - SCREEN_HEIGHT)
        self.x = max(0.0, min(self.x, float(max_x)))
        self.y = max(0.0, min(self.y, float(max_y)))

    def apply_rect(self, rect: pygame.Rect) -> pygame.Rect:
        return rect.move(int(-self.x), int(-self.y))


class Rock:
    """섬에 흩어져 있는 바위 장애물 (고체 충돌체)"""

    def __init__(self, x: int, y: int, size: str = "medium"):
        self.x = x
        self.y = y
        if size == "large":
            self.width, self.height = 52, 40
            self.hitbox = pygame.Rect(x + 4, y + 14, 44, 24)
        else:
            self.width, self.height = 38, 30
            self.hitbox = pygame.Rect(x + 4, y + 10, 30, 18)

        self.surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        self._build_surface()

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def _build_surface(self):
        shadow_rect = pygame.Rect(2, self.height - 12, self.width - 4, 10)
        pygame.draw.ellipse(self.surface, COLOR_SHADOW, shadow_rect)

        pts = [
            (8, self.height - 6),
            (2, self.height // 2),
            (self.width // 4, 4),
            (self.width * 3 // 4, 3),
            (self.width - 4, self.height // 2),
            (self.width - 8, self.height - 6),
        ]
        pygame.draw.polygon(self.surface, COLOR_ROCK, pts)

        highlight_pts = [
            (self.width // 4, 5),
            (self.width * 3 // 4 - 2, 4),
            (self.width // 2, self.height // 2 - 2),
            (self.width // 4 + 4, self.height // 2 - 1),
        ]
        pygame.draw.polygon(self.surface, COLOR_ROCK_LIGHT, highlight_pts)
        pygame.draw.polygon(self.surface, COLOR_ROCK_DARK, pts, 2)

    def draw(self, target_surface: pygame.Surface, camera: Camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class World:
    """탑뷰 섬 맵, 시간 시스템, 멧돼지, 탐험가의 일지 및 사물 총괄"""

    def __init__(self):
        self.width = WORLD_WIDTH
        self.height = WORLD_HEIGHT
        self.cols = MAP_COLS
        self.rows = MAP_ROWS

        # 5일 시간 및 낮/밤 시스템
        self.time_system = TimeSystem()

        # 스폰 지점
        self.spawn_point = (WORLD_WIDTH // 2, WORLD_HEIGHT // 2)

        # 맵 데이터 및 엔티티 목록
        self.grid = [[TILE_DEEP_WATER for _ in range(self.cols)] for _ in range(self.rows)]
        self.obstacles = []       # 바위
        self.trees = []           # 벌목/흔들기 야자수
        self.resource_nodes = []  # 채집 가능한 바닥 자원 노드
        self.campfires = []       # 설치된 모닥불 목록
        self.shelters = []        # 설치된 간이 거처 목록
        self.boars = []           # 숲의 멧돼지 목록
        self.journal = None       # 시작 지점의 탐험가의 일지
        self.raft_slipway = None  # 해변의 최종 뗏목 건조대 및 탈출 뗏목

        # 타일 서피스 캐시
        self.tile_surfaces = {}
        self._init_tile_surfaces()

        # 섬 지형, 자원 노드, 베이스캠프 및 일지/멧돼지 생성
        self._generate_island()

    def _init_tile_surfaces(self):
        """각 타일 타입별 픽셀 그래픽 텍스처 캐시"""
        surf_deep = pygame.Surface((TILE_SIZE, TILE_SIZE))
        surf_deep.fill(COLOR_OCEAN_DEEP)
        pygame.draw.line(surf_deep, (35, 75, 110), (6, 16), (20, 16), 2)
        pygame.draw.line(surf_deep, (35, 75, 110), (28, 36), (42, 36), 2)
        self.tile_surfaces[TILE_DEEP_WATER] = surf_deep

        surf_shallow = pygame.Surface((TILE_SIZE, TILE_SIZE))
        surf_shallow.fill(COLOR_OCEAN_SHALLOW)
        pygame.draw.line(surf_shallow, (180, 220, 240), (4, 12), (24, 12), 2)
        pygame.draw.line(surf_shallow, (180, 220, 240), (24, 32), (44, 32), 2)
        self.tile_surfaces[TILE_SHALLOW_WATER] = surf_shallow

        surf_sand = pygame.Surface((TILE_SIZE, TILE_SIZE))
        surf_sand.fill(COLOR_BEACH_SAND)
        surf_sand.set_at((12, 14), COLOR_BEACH_DARK)
        surf_sand.set_at((13, 14), COLOR_BEACH_DARK)
        surf_sand.set_at((34, 28), COLOR_BEACH_DARK)
        surf_sand.set_at((22, 40), (245, 235, 210))
        self.tile_surfaces[TILE_SAND] = surf_sand

        surf_grass = pygame.Surface((TILE_SIZE, TILE_SIZE))
        surf_grass.fill(COLOR_GRASS)
        surf_grass.set_at((10, 12), COLOR_GRASS_DARK)
        surf_grass.set_at((10, 13), COLOR_GRASS_DARK)
        surf_grass.set_at((32, 22), COLOR_GRASS_DARK)
        surf_grass.set_at((24, 36), (115, 185, 105))
        self.tile_surfaces[TILE_GRASS] = surf_grass

        surf_dark_grass = pygame.Surface((TILE_SIZE, TILE_SIZE))
        surf_dark_grass.fill(COLOR_GRASS_DARK)
        surf_dark_grass.set_at((14, 18), (55, 105, 52))
        surf_dark_grass.set_at((36, 32), (85, 145, 80))
        self.tile_surfaces[TILE_DARK_GRASS] = surf_dark_grass

    def _generate_island(self):
        """섬 지형 절차적 생성, 시작 지점 일지 및 숲속 멧돼지 배치"""
        center_col = self.cols / 2.0
        center_row = self.rows / 2.0
        radius_col = self.cols * 0.40
        radius_row = self.rows * 0.40

        rng = random.Random(42)

        # 1. 지형 격자 생성
        for r in range(self.rows):
            for c in range(self.cols):
                norm_c = (c - center_col) / radius_col
                norm_r = (r - center_row) / radius_row
                dist = math.sqrt(norm_c * norm_c + norm_r * norm_r)

                angle = math.atan2(norm_r, norm_c)
                distortion = 0.12 * math.sin(angle * 5) + 0.08 * math.cos(angle * 3)
                island_metric = dist + distortion

                if island_metric > 1.05:
                    self.grid[r][c] = TILE_DEEP_WATER
                elif island_metric > 0.88:
                    self.grid[r][c] = TILE_SHALLOW_WATER
                elif island_metric > 0.68:
                    self.grid[r][c] = TILE_SAND
                elif island_metric > 0.32:
                    self.grid[r][c] = TILE_GRASS
                else:
                    self.grid[r][c] = TILE_DARK_GRASS

        spawn_x = int(center_col * TILE_SIZE)
        spawn_y = int(center_row * TILE_SIZE)
        self.spawn_point = (spawn_x, spawn_y)

        # 2. 시작 지점 베이스캠프 구조물 및 [탐험가의 일지] 배치
        self.campfires.append(PlacedCampfire(spawn_x - 56, spawn_y + 14))
        self.shelters.append(PlacedShelter(spawn_x + 38, spawn_y - 24))
        self.journal = PlacedJournal(spawn_x - 24, spawn_y + 36)

        # 3. 숲의 특정 구역에 멧돼지 배치 (북동쪽 숲속 서식지)
        boar_territory_x = spawn_x + 280
        boar_territory_y = spawn_y - 210
        self.boars.append(WildBoar(boar_territory_x, boar_territory_y))

        # 4. 자연 자원 노드 및 장애물 배치
        for r in range(2, self.rows - 2):
            for c in range(2, self.cols - 2):
                tile = self.grid[r][c]
                px = c * TILE_SIZE + rng.randint(4, 12)
                py = r * TILE_SIZE + rng.randint(4, 12)

                # 스폰 포인트 및 베이스캠프 주변 95px는 비워두기
                if math.hypot(px - spawn_x, py - spawn_y) < 95:
                    continue

                roll = rng.random()

                # 초원 및 고지대
                if tile in (TILE_GRASS, TILE_DARK_GRASS):
                    if roll < 0.07:
                        self.trees.append(InteractableTree(px - 10, py - 24))
                    elif roll < 0.12:
                        self.resource_nodes.append(FiberNode(px, py))
                    elif roll < 0.17:
                        self.resource_nodes.append(BranchNode(px, py))
                    elif roll < 0.22:
                        self.resource_nodes.append(BerryBushNode(px, py))
                    elif roll < 0.26:
                        self.resource_nodes.append(StoneNode(px, py))
                    elif roll < 0.29:
                        self.obstacles.append(Rock(px, py, "medium"))

                # 모래사장
                elif tile == TILE_SAND:
                    if roll < 0.06:
                        self.resource_nodes.append(CoconutNode(px, py))
                    elif roll < 0.13:
                        self.resource_nodes.append(StoneNode(px, py))
                    elif roll < 0.19:
                        self.resource_nodes.append(BranchNode(px, py))
                    elif roll < 0.23:
                        self.trees.append(InteractableTree(px - 10, py - 24))
                    elif roll < 0.26:
                        self.obstacles.append(Rock(px, py, "large"))

    def add_campfire(self, x: int, y: int):
        cf = PlacedCampfire(x, y)
        self.campfires.append(cf)
        return cf

    def add_shelter(self, x: int, y: int):
        sh = PlacedShelter(x, y)
        self.shelters.append(sh)
        return sh

    def is_solid_tile(self, col: int, row: int) -> bool:
        if col < 0 or col >= self.cols or row < 0 or row >= self.rows:
            return True
        return self.grid[row][col] == TILE_DEEP_WATER

    def get_colliding_obstacles(self, hitbox: pygame.Rect):
        colliders = []

        min_c = max(0, (hitbox.left - 10) // TILE_SIZE)
        max_c = min(self.cols - 1, (hitbox.right + 10) // TILE_SIZE)
        min_r = max(0, (hitbox.top - 10) // TILE_SIZE)
        max_r = min(self.rows - 1, (hitbox.bottom + 10) // TILE_SIZE)

        for r in range(min_r, max_r + 1):
            for c in range(min_c, max_c + 1):
                if self.is_solid_tile(c, r):
                    colliders.append(
                        pygame.Rect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    )

        for obj in self.obstacles:
            if hitbox.inflate(30, 30).colliderect(obj.hitbox):
                colliders.append(obj.hitbox)

        for tree in self.trees:
            if hitbox.inflate(30, 30).colliderect(tree.hitbox):
                colliders.append(tree.hitbox)

        for sh in self.shelters:
            if hitbox.inflate(30, 30).colliderect(sh.hitbox):
                colliders.append(sh.hitbox)

        for cf in self.campfires:
            if hitbox.inflate(30, 30).colliderect(cf.hitbox):
                colliders.append(cf.hitbox)

        return colliders

    def get_nearby_interactable(self, player):
        """플레이어 주변의 최우선 상호작용 대상 (일지, 거처, 모닥불, 야자수, 자원)"""
        closest_node = None
        closest_dist = float("inf")
        player_pos = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)

        # 1. 탐험가의 일지
        if self.journal and self.journal.can_interact(player):
            d = player_pos.distance_to(self.journal.center)
            if d < closest_dist:
                closest_dist = d
                closest_node = self.journal

        # 2. 거처 (수면)
        for sh in self.shelters:
            if sh.can_interact(player):
                d = player_pos.distance_to(sh.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = sh

        # 3. 모닥불
        for cf in self.campfires:
            if cf.can_interact(player):
                d = player_pos.distance_to(cf.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = cf

        # 4. 야자수
        for tree in self.trees:
            if tree.can_interact(player):
                d = player_pos.distance_to(tree.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = tree

        # 5. 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active and node.can_interact(player):
                d = player_pos.distance_to(node.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = node

        return closest_node

    def update(self, dt: float, player) -> list:
        """모닥불 및 멧돼지 AI 갱신"""
        events = []
        for cf in self.campfires:
            cf.update(dt)

        # 멧돼지 AI 업데이트 및 공격 이벤트 감지
        for boar in self.boars:
            attack_hit, damage, msg = boar.update(dt, player, self)
            if attack_hit:
                events.append(("BOAR_ATTACK", msg))

        return events

    def draw_ground(self, target_surface: pygame.Surface, camera: Camera):
        start_col = max(0, int(camera.x // TILE_SIZE))
        end_col = min(self.cols, int((camera.x + SCREEN_WIDTH) // TILE_SIZE) + 2)
        start_row = max(0, int(camera.y // TILE_SIZE))
        end_row = min(self.rows, int((camera.y + SCREEN_HEIGHT) // TILE_SIZE) + 2)

        for r in range(start_row, end_row):
            for c in range(start_col, end_col):
                tile_type = self.grid[r][c]
                surf = self.tile_surfaces[tile_type]
                screen_x = int(c * TILE_SIZE - camera.x)
                screen_y = int(r * TILE_SIZE - camera.y)
                target_surface.blit(surf, (screen_x, screen_y))

    def draw_entities(self, target_surface: pygame.Surface, camera: Camera, player):
        """Y-Sorting 깊이 렌더링 (바위, 나무, 거처, 모닥불, 일지, 멧돼지, 자원, 플레이어)"""
        view_rect = pygame.Rect(
            int(camera.x - 70),
            int(camera.y - 70),
            SCREEN_WIDTH + 140,
            SCREEN_HEIGHT + 140,
        )

        visible_drawables = []

        # 바위
        for rock in self.obstacles:
            r = pygame.Rect(rock.x, rock.y, rock.width, rock.height)
            if view_rect.colliderect(r):
                visible_drawables.append((rock.render_y, rock))

        # 야자수
        for tree in self.trees:
            tr = pygame.Rect(tree.x, tree.y, tree.width, tree.height)
            if view_rect.colliderect(tr):
                visible_drawables.append((tree.render_y, tree))

        # 구조물 (거처, 모닥불)
        for sh in self.shelters:
            sr = pygame.Rect(sh.x, sh.y, sh.width, sh.height)
            if view_rect.colliderect(sr):
                visible_drawables.append((sh.render_y, sh))

        for cf in self.campfires:
            cr = pygame.Rect(cf.x, cf.y, cf.width, cf.height)
            if view_rect.colliderect(cr):
                visible_drawables.append((cf.render_y, cf))

        # 탐험가의 일지
        if self.journal:
            jr = pygame.Rect(self.journal.x, self.journal.y, self.journal.width, self.journal.height)
            if view_rect.colliderect(jr):
                visible_drawables.append((self.journal.render_y, self.journal))

        # 멧돼지
        for boar in self.boars:
            br = pygame.Rect(int(boar.x), int(boar.y), boar.width, boar.height)
            if view_rect.colliderect(br):
                visible_drawables.append((boar.render_y, boar))

        # 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active:
                nr = pygame.Rect(node.x, node.y, node.width, node.height)
                if view_rect.colliderect(nr):
                    visible_drawables.append((node.render_y, node))

        # 플레이어
        visible_drawables.append((player.hitbox.bottom, player))

        # Y 정렬 후 그리기
        visible_drawables.sort(key=lambda item: item[0])
        for _, entity in visible_drawables:
            entity.draw(target_surface, camera)

    def draw_lighting_and_darkness(self, target_surface: pygame.Surface, camera: Camera, player):
        alpha = self.time_system.get_darkness_alpha()
        if alpha <= 0:
            return

        dark_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dark_surf.fill((10, 16, 28, alpha))

        # 플레이어 시야 뚫기
        player_screen_x = int(player.hitbox.centerx - camera.x)
        player_screen_y = int(player.hitbox.centery - camera.y)

        vision_radius = NIGHT_VISION_RADIUS_BASE
        if player.inventory.has_item("torch"):
            vision_radius += TORCH_VISION_BONUS

        player_light = get_light_mask(vision_radius)
        dark_surf.blit(
            player_light,
            (player_screen_x - vision_radius, player_screen_y - vision_radius),
            special_flags=pygame.BLEND_RGBA_SUB,
        )

        # 모닥불 조명 뚫기
        for cf in self.campfires:
            cf_screen_x = int(cf.center.x - camera.x)
            cf_screen_y = int(cf.center.y - camera.y)
            if -100 <= cf_screen_x <= SCREEN_WIDTH + 100 and -100 <= cf_screen_y <= SCREEN_HEIGHT + 100:
                cf_light = get_light_mask(cf.light_radius)
                dark_surf.blit(
                    cf_light,
                    (cf_screen_x - cf.light_radius, cf_screen_y - cf.light_radius),
                    special_flags=pygame.BLEND_RGBA_SUB,
                )

        target_surface.blit(dark_surf, (0, 0))

'''
해일 전 3일 (3 Days Before Tsunami)
월드 맵, 타일 시스템, 야생 동물 및 탐험가의 일지 연동 모듈
'''

import math
import random
from pathlib import Path
from typing import Optional, Type
import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    TILE_SIZE,
    PLAYER_WIDTH,
    PLAYER_HEIGHT,
    NIGHT_VISION_RADIUS_BASE,
    TORCH_VISION_BONUS,
    CAMPFIRE_LIGHT_RADIUS,
)
from image_assets import fit_sprite, get_item_sprite, get_item_surface, scale_pixel_art
from tiled_map import TiledMap
from time_system import TimeSystem
from weather import WeatherEffects
from structures import PlacedCampfire, PlacedShelter
from journal import PlacedJournal
from boar import WildBoar
from snake import VenomSnake
from raft import RaftSlipway
from resource_nodes import (
    BranchNode,
    StoneNode,
    FiberNode,
    BerryBushNode,
    InteractableTree,
    ResourceNode,
)

# 타일 종류 ID
TILE_DEEP_WATER = 0     # 깊은 바다 (이동 불가)
TILE_SHALLOW_WATER = 1  # 해안 얕은 바다 (파도 거품)
TILE_SAND = 2           # 모래사장
TILE_GRASS = 3          # 초원
TILE_DARK_GRASS = 4     # 고지대 잔디

_LIGHT_MASK_CACHE = {}


def get_light_mask(radius: int) -> pygame.Surface:
    '''부드러운 원형 빛 구멍 마스크 생성 및 캐시'''
    radius = int(radius)
    if radius in _LIGHT_MASK_CACHE:
        return _LIGHT_MASK_CACHE[radius]

    size = radius * 2
    mask = pygame.Surface((size, size), pygame.SRCALPHA)
    step = 4
    for r in range(radius, 0, -step):
        factor = (1.0 - (r / radius) ** 1.6)
        alpha = int(255 * factor)
        pygame.draw.circle(mask, (0, 0, 0, alpha), (radius, radius), r)

    _LIGHT_MASK_CACHE[radius] = mask
    return mask


class Camera:
    '''플레이어를 부드럽게 추적하고 월드 경계 내로 제한하는 카메라'''

    def __init__(self, world_width: int, world_height: int):
        self.world_width = world_width
        self.world_height = world_height
        self.x = 0.0
        self.y = 0.0

    def update(self, target_rect: pygame.Rect, dt: float = 1 / 60):
        target_x = target_rect.centerx - SCREEN_WIDTH / 2
        target_y = target_rect.centery - SCREEN_HEIGHT / 2

        follow_amount = 1.0 - math.exp(-8.0 * max(0.0, dt))
        self.x += (target_x - self.x) * follow_amount
        self.y += (target_y - self.y) * follow_amount

        max_x = max(0, self.world_width - SCREEN_WIDTH)
        max_y = max(0, self.world_height - SCREEN_HEIGHT)
        self.x = float(round(max(0.0, min(self.x, float(max_x)))))
        self.y = float(round(max(0.0, min(self.y, float(max_y)))))

    def apply_rect(self, rect: pygame.Rect) -> pygame.Rect:
        return rect.move(int(-self.x), int(-self.y))


class Rock:
    '''섬에 흩어져 있는 바위 장애물 (고체 충돌체 - 원본 16x16의 3배 정수 스케일)'''

    def __init__(self, x: int, y: int, size: str = "medium"):
        self.x = x
        self.y = y
        self.width = 48
        self.height = 48
        self.hitbox = pygame.Rect(x + 6, y + 16, 36, 24)

        variant = (x // TILE_SIZE + y // TILE_SIZE) % 2
        key = "stone" if variant == 0 else "stone_2"
        self.surface = scale_pixel_art(get_item_surface(key), 3)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def draw(self, target_surface: pygame.Surface, camera: Camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class MapProp:
    '''맵에 배치된 정적 프롭 스프라이트 (예: 난파선)'''

    def __init__(self, x: int, y: int, surface: pygame.Surface, render_y: Optional[int] = None):
        self.x = x
        self.y = y
        self.width = surface.get_width()
        self.height = surface.get_height()
        self.surface = surface
        self._render_y = render_y if render_y is not None else y + self.height

    @property
    def render_y(self) -> int:
        return self._render_y

    def draw(self, target_surface: pygame.Surface, camera: Camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class World:
    '''탑뷰 섬 맵, 시간 시스템, 야생 동물, 탐험가의 일지 및 사물 총괄'''

    def __init__(self):
        self.tiled_map = TiledMap(
            Path(__file__).parent / "assets" / "map" / "Newisland.tmj",
            TILE_SIZE,
        )
        self.cols = self.tiled_map.cols
        self.rows = self.tiled_map.rows
        self.width = self.cols * TILE_SIZE
        self.height = self.rows * TILE_SIZE

        # 3일 시간 및 낮/밤 시스템
        self.time_system = TimeSystem()
        self.weather = WeatherEffects()

        # 스폰 지점은 섬 남쪽 해변의 모래사장으로 설정합니다.
        self.spawn_point = (self.width // 2, self.height // 2)

        # 맵 데이터 및 엔티티 목록
        self.grid = self.tiled_map.terrain
        self.ground_surfaces = self.tiled_map.ground_surfaces
        self.obstacles = []       # 바위
        self.props = []           # 맵 프롭 (난파선 등)
        self.map_colliders = []   # 맵 오브젝트 충돌 영역
        self.trees = []           # 벌목/흔들기 야자수
        self.resource_nodes = []  # 채집 가능한 바닥 자원 노드
        self._placement_rects = []
        self.campfires = []       # 설치된 모닥불 목록
        self.shelters = []        # 설치된 간이 거처 목록
        self.boars = []           # 숲의 멧돼지 목록
        self.snakes = []          # 오른쪽 풀숲의 독사
        self.dropped_items = []   # 바닥에 떨어진 아이템 (나무 원목 등)
        self.journal = None       # 시작 지점의 탐험가의 일지
        self.raft_slipway = None  # 해변의 최종 뗏목 건조대 및 탈출 뗏목

        # Tiled terrain, resource nodes, base camp, journal, and animal habitats
        self._generate_island()
        self._place_raft_slipway()
        self._resource_respawn_rng = random.Random()
        self._resource_respawn_nodes = {
            node_type: [
                node for node in self.resource_nodes
                if isinstance(node, node_type)
            ]
            for node_type in (BranchNode, StoneNode, FiberNode, BerryBushNode)
        }
        self._last_resource_respawn_day = self.time_system.current_day

    def _generate_island(self):
        '''Place existing gameplay systems on top of the Tiled terrain.'''
        south_shore_rows = [
            row
            for row in range(self.rows - 1)
            if any(
                self.grid[row][column] == TILE_SAND
                and self.grid[row + 1][column] == TILE_DEEP_WATER
                for column in range(self.cols)
            )
        ]
        if not south_shore_rows:
            raise ValueError("The island map has no south-facing sandy shoreline for the player spawn.")

        south_shore_row = max(south_shore_rows)
        beach_row = south_shore_row - 1
        beach_columns = [
            column
            for column in range(self.cols)
            if self.grid[beach_row][column] == TILE_SAND
        ]
        if not beach_columns:
            raise ValueError("The island map has no sandy beach tile beside its southern shoreline.")

        center_col = self.cols // 2
        spawn_col = min(beach_columns, key=lambda column: abs(column - center_col))
        spawn_row = beach_row
        spawn_x = spawn_col * TILE_SIZE + TILE_SIZE // 2
        spawn_y = spawn_row * TILE_SIZE + TILE_SIZE // 2
        self.spawn_point = (
            spawn_x - PLAYER_WIDTH // 2,
            spawn_y - PLAYER_HEIGHT // 2,
        )

        # 시작 지점 옆에는 일지만 두고, 모닥불과 거처는 직접 만들도록 합니다.
        self.journal = PlacedJournal(spawn_x - 88, spawn_y - 16)
        self._placement_rects.append(
            pygame.Rect(self.journal.x, self.journal.y, self.journal.width, self.journal.height)
        )

        # 3. 숲 군집, 해변 자원 무리와 멧돼지 서식지 배치
        self._populate_resources(spawn_x, spawn_y, random.Random(2026))

    def _place_raft_slipway(self):
        '''Place the build site at the center of the protruding southern cove.'''
        south_shore = [
            (column, row)
            for row in range(self.rows - 1)
            for column in range(self.cols)
            if self.grid[row][column] == TILE_SAND
            and self.grid[row + 1][column] == TILE_DEEP_WATER
        ]
        if not south_shore:
            raise ValueError("The island map has no south-facing sandy shoreline for the raft.")

        south_row = max(row for _, row in south_shore)
        shore_columns = sorted(column for column, row in south_shore if row == south_row)
        spawn_center_x = self.spawn_point[0] + PLAYER_WIDTH // 2
        cove_center_x = spawn_center_x + TILE_SIZE + TILE_SIZE // 2
        cove_column = cove_center_x // TILE_SIZE
        if cove_column not in shore_columns:
            cove_column = min(
                shore_columns,
                key=lambda column: abs(
                    column * TILE_SIZE + TILE_SIZE // 2 - cove_center_x
                ),
            )
            cove_center_x = cove_column * TILE_SIZE + TILE_SIZE // 2
        raft_center_x = cove_center_x
        raft_center_y = south_row * TILE_SIZE + TILE_SIZE // 2
        raft_x = raft_center_x - RaftSlipway.WIDTH // 2
        raft_y = raft_center_y - RaftSlipway.HEIGHT // 2
        self.raft_slipway = RaftSlipway(raft_x, raft_y)

    def _respawn_gatherables_for_new_days(self):
        while self._last_resource_respawn_day < self.time_system.current_day:
            self._last_resource_respawn_day += 1
            for nodes in self._resource_respawn_nodes.values():
                whole, remainder = divmod(len(nodes), 3)
                respawn_count = whole
                if remainder and self._resource_respawn_rng.randrange(3) < remainder:
                    respawn_count += 1

                depleted_nodes = [node for node in nodes if node.is_depleted]
                selected_nodes = self._resource_respawn_rng.sample(
                    depleted_nodes,
                    min(respawn_count, len(depleted_nodes)),
                )
                for node in selected_nodes:
                    node.respawn()

    def _terrain_at(self, x: int, y: int) -> Optional[int]:
        column = int(x // TILE_SIZE)
        row = int(y // TILE_SIZE)
        if 0 <= column < self.cols and 0 <= row < self.rows:
            return self.grid[row][column]
        return None

    def _is_terrain(self, rect: pygame.Rect, allowed_terrain: tuple[int, ...], margin: int = 4) -> bool:
        '''사각형과 안전 여백 전체가 지정된 지형 타일 안에 있는지 검사'''
        checked_rect = rect.inflate(margin * 2, margin * 2)
        min_col = checked_rect.left // TILE_SIZE
        max_col = (checked_rect.right - 1) // TILE_SIZE
        min_row = checked_rect.top // TILE_SIZE
        max_row = (checked_rect.bottom - 1) // TILE_SIZE

        for row in range(min_row, max_row + 1):
            for column in range(min_col, max_col + 1):
                if self._terrain_at(column * TILE_SIZE, row * TILE_SIZE) not in allowed_terrain:
                    return False
        return True

    def _can_place(self, rect: pygame.Rect, allowed_terrain: tuple[int, ...], min_spawn_dist: float = 90.0, margin: int = 4) -> bool:
        if not self._is_terrain(rect, allowed_terrain, margin=margin):
            return False

        spawn_x, spawn_y = self.spawn_point
        if math.hypot(rect.centerx - spawn_x, rect.centery - spawn_y) < min_spawn_dist:
            return False
        return not any(rect.inflate(6, 6).colliderect(other) for other in self._placement_rects)

    def _try_add_resource(
        self,
        node_type: Type[ResourceNode],
        x: int,
        y: int,
        allowed_terrain: tuple[int, ...],
        min_spawn_dist: float = 90.0,
        margin: int = 4,
    ) -> bool:
        node = node_type(x, y)
        rect = pygame.Rect(node.x, node.y, node.width, node.height)
        if not self._can_place(rect, allowed_terrain, min_spawn_dist=min_spawn_dist, margin=margin):
            return False
        self.resource_nodes.append(node)
        self._placement_rects.append(rect)
        return True

    def _has_duplicate_node(self, node_type: Type[ResourceNode], x: int, y: int) -> bool:
        cx = x + 24
        cy = y + 24
        return any(
            isinstance(existing, node_type)
            and math.hypot(existing.center.x - cx, existing.center.y - cy) < 6.0
            for existing in self.resource_nodes
        )

    def _populate_resources(self, spawn_x: int, spawn_y: int, rng: random.Random):
        scale = self.tiled_map.render_scale

        # 1. Tiled Collisions 레이어 로드 (예: 난파선 충돌 박스)
        for obj in self.tiled_map.object_layers.get("Collisions", []):
            rect = pygame.Rect(
                round(obj["x"] * scale),
                round(obj["y"] * scale),
                max(1, round(obj["width"] * scale)),
                max(1, round(obj["height"] * scale)),
            )
            self.map_colliders.append(rect)

        # 2. Tiled Interactables 및 Props 레이어에서 나무, 돌, 덤불, 풀, 나뭇가지, 난파선 배치
        map_objects = (
            self.tiled_map.object_layers.get("Interactables", [])
            + self.tiled_map.object_layers.get("Props", [])
        )
        for obj in map_objects:
            obj_type = obj.get("type", "")
            image_name = obj.get("image_name") or ""
            center_x = (obj["x"] + obj["width"] / 2) * scale
            center_y = (obj["y"] - obj["height"] / 2) * scale

            if obj_type in ("tree_full", "tree_coconut_full") or image_name in ("tree_full.png", "tree_coconut_full.png"):
                has_coconuts = (
                    obj_type == "tree_coconut_full"
                    or image_name == "tree_coconut_full.png"
                )
                tx = round(center_x - 45)
                ty = round(obj["y"] * scale - 123)
                tree = InteractableTree(tx, ty, has_coconuts=has_coconuts)
                self.trees.append(tree)
                self._placement_rects.append(tree.hitbox.inflate(20, 20))
            elif obj_type == "berry_bush" or image_name == "berry_bush.png":
                bx = round(center_x - 24)
                by = round(center_y - 24)
                if not self._has_duplicate_node(BerryBushNode, bx, by):
                    self.resource_nodes.append(BerryBushNode(bx, by))
                    self._placement_rects.append(pygame.Rect(bx, by, 48, 48))
            elif obj_type == "grass" or image_name in ("grass1.png", "grass2.png"):
                gx = round(center_x - 24)
                gy = round(center_y - 24)
                sprite_key = "plant_fiber_alt" if image_name == "grass2.png" else "plant_fiber"
                if not self._has_duplicate_node(FiberNode, gx, gy):
                    self.resource_nodes.append(
                        FiberNode(gx, gy, sprite_key=sprite_key, flip_x=obj.get("flip_x", False))
                    )
                    self._placement_rects.append(pygame.Rect(gx, gy, 48, 48))
            elif obj_type == "rock" or image_name in ("rock1.png", "rock2.png"):
                rx = round(center_x - 24)
                ry = round(center_y - 24)
                sprite_key = "stone_2" if image_name == "rock2.png" else "stone"
                if not self._has_duplicate_node(StoneNode, rx, ry):
                    self.resource_nodes.append(
                        StoneNode(rx, ry, sprite_key=sprite_key, flip_x=obj.get("flip_x", False))
                    )
                    self._placement_rects.append(pygame.Rect(rx, ry, 48, 48))
            elif obj_type == "branch" or image_name == "branch.png":
                brx = round(center_x - 24)
                bry = round(center_y - 24)
                if not self._has_duplicate_node(BranchNode, brx, bry):
                    self.resource_nodes.append(
                        BranchNode(brx, bry, flip_x=obj.get("flip_x", False))
                    )
                    self._placement_rects.append(pygame.Rect(brx, bry, 48, 48))
            elif obj.get("image") is not None:
                pw = max(1, round(obj["width"] * scale))
                ph = max(1, round(obj["height"] * scale))
                px = round(obj["x"] * scale)
                py = round(obj["y"] * scale - ph)
                surface = pygame.transform.scale(obj["image"], (pw, ph))
                if obj.get("flip_x") or obj.get("flip_y"):
                    surface = pygame.transform.flip(
                        surface, obj.get("flip_x", False), obj.get("flip_y", False)
                    )
                prop_rect = pygame.Rect(px, py, pw, ph)
                overlapping_colliders = [
                    collider for collider in self.map_colliders
                    if prop_rect.colliderect(collider)
                ]
                render_y = max((c.bottom for c in overlapping_colliders), default=py + ph)
                self.props.append(MapProp(px, py, surface, render_y=render_y))

        # 3. 멧돼지 (WildBoar): 숲속 깊은 잔디밭에 서식지 배치
        grass_tiles = [
            (c, r) for r in range(self.rows) for c in range(self.cols)
            if self.grid[r][c] in (TILE_GRASS, TILE_DARK_GRASS)
        ]
        boar_candidates = [
            (c * TILE_SIZE + TILE_SIZE // 2, r * TILE_SIZE + TILE_SIZE // 2)
            for c, r in grass_tiles
            if math.hypot(c * TILE_SIZE - spawn_x, r * TILE_SIZE - spawn_y) > 280
        ]
        if boar_candidates:
            boar_x, boar_y = rng.choice(boar_candidates)
            self.boars.append(WildBoar(boar_x, boar_y))

        grass_nodes = [
            node for node in self.resource_nodes if isinstance(node, FiberNode)
        ]
        if not grass_nodes:
            raise ValueError("The island map has no grass patch for the snake habitat.")
        right_grass = max(grass_nodes, key=lambda node: node.center.x)
        self.snakes.append(
            VenomSnake(
                right_grass.center.x + TILE_SIZE,
                right_grass.center.y,
            )
        )

    def add_dropped_item(self, item):
        '''바닥에 떨어지는 아이템 등록'''
        self.dropped_items.append(item)

    def add_campfire(self, x: int, y: int):
        cf = PlacedCampfire(x, y)
        self.campfires.append(cf)
        return cf

    def add_shelter(self, x: int, y: int):
        sh = PlacedShelter(x, y)
        self.shelters.append(sh)
        return sh

    def is_solid_tile(self, col: int, row: int) -> bool:
        if col < 0 or col >= self.cols or row < 0 or row >= self.rows:
            return True
        return self.grid[row][col] == TILE_DEEP_WATER

    def get_colliding_obstacles(self, hitbox: pygame.Rect):
        colliders = []

        min_c = (hitbox.left - 10) // TILE_SIZE
        max_c = (hitbox.right + 10) // TILE_SIZE
        min_r = (hitbox.top - 10) // TILE_SIZE
        max_r = (hitbox.bottom + 10) // TILE_SIZE

        for r in range(min_r, max_r + 1):
            for c in range(min_c, max_c + 1):
                if c < 0 or c >= self.cols or r < 0 or r >= self.rows:
                    colliders.append(
                        pygame.Rect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    )
                else:
                    tile_x = c * TILE_SIZE
                    tile_y = r * TILE_SIZE
                    for local_rect in self.tiled_map.tile_colliders[r][c]:
                        colliders.append(local_rect.move(tile_x, tile_y))

        for rect in self.map_colliders:
            if hitbox.inflate(30, 30).colliderect(rect):
                colliders.append(rect)

        for obj in self.obstacles:
            if hitbox.inflate(30, 30).colliderect(obj.hitbox):
                colliders.append(obj.hitbox)

        for tree in self.trees:
            if hitbox.inflate(30, 30).colliderect(tree.hitbox):
                colliders.append(tree.hitbox)

        for sh in self.shelters:
            if hitbox.inflate(30, 30).colliderect(sh.hitbox):
                colliders.append(sh.hitbox)

        for cf in self.campfires:
            if hitbox.inflate(30, 30).colliderect(cf.hitbox):
                colliders.append(cf.hitbox)

        return colliders

    def get_nearby_interactable(self, player):
        '''플레이어 주변의 최우선 상호작용 대상'''
        closest_node = None
        closest_dist = float("inf")
        player_pos = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)

        if self.raft_slipway and self.raft_slipway.can_interact(player):
            return self.raft_slipway

        # 1. 탐험가의 일지
        if self.journal and self.journal.can_interact(player):
            d = player_pos.distance_to(self.journal.center)
            if d < closest_dist:
                closest_dist = d
                closest_node = self.journal

        # 2. 거처 (수면)
        for sh in self.shelters:
            if sh.can_interact(player):
                d = player_pos.distance_to(sh.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = sh

        # 3. 모닥불
        for cf in self.campfires:
            if cf.can_interact(player):
                d = player_pos.distance_to(cf.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = cf

        # 4. 야자수
        for tree in self.trees:
            if tree.can_interact(player):
                d = player_pos.distance_to(tree.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = tree

        # 5. 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active and node.can_interact(player):
                d = player_pos.distance_to(node.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = node

        return closest_node

    def update(self, dt: float, player) -> list:
        '''모닥불, 야생 동물 AI 및 바닥 드롭 아이템 갱신'''
        events = []
        self._respawn_gatherables_for_new_days()
        if self.weather.update(dt, self.time_system.current_day, player):
            events.append(("LIGHTNING_HIT", "번개에 맞았습니다! 체력 -20"))

        if self.raft_slipway:
            self.raft_slipway.update(dt)
        for cf in self.campfires:
            cf.update(dt)

        # 바닥에 떨어진 아이템 (나무 원목 등) 픽업 판정 및 갱신
        for item in self.dropped_items:
            item.update(dt)
            if item.check_pickup(player):
                events.append(("ITEM_PICKUP", f"+{item.count} 나무 원목 획득!"))
        self.dropped_items = [it for it in self.dropped_items if it.is_active]

        # 멧돼지 AI 업데이트 및 공격 이벤트 감지
        for boar in self.boars:
            attack_hit, damage, msg = boar.update(dt, player, self)
            if attack_hit:
                events.append(("BOAR_ATTACK", msg))

        for snake in self.snakes:
            poison_hit, msg = snake.update(dt, player)
            if poison_hit:
                player.survival.apply_poison()
                events.append(("SNAKE_POISONED", msg))

        return events

    def draw_ground(self, target_surface: pygame.Surface, camera: Camera):
        start_col = max(0, int(camera.x // TILE_SIZE))
        end_col = min(self.cols, int((camera.x + SCREEN_WIDTH) // TILE_SIZE) + 2)
        start_row = max(0, int(camera.y // TILE_SIZE))
        end_row = min(self.rows, int((camera.y + SCREEN_HEIGHT) // TILE_SIZE) + 2)

        for r in range(start_row, end_row):
            for c in range(start_col, end_col):
                surf = self.ground_surfaces[r][c]
                screen_x = int(c * TILE_SIZE - camera.x)
                screen_y = int(r * TILE_SIZE - camera.y)
                target_surface.blit(surf, (screen_x, screen_y))

    def draw_entities(self, target_surface: pygame.Surface, camera: Camera, player):
        '''Y-Sorting 깊이 렌더링 (환경물, 야생 동물, 자원, 플레이어)'''
        view_rect = pygame.Rect(
            int(camera.x - 70),
            int(camera.y - 70),
            SCREEN_WIDTH + 140,
            SCREEN_HEIGHT + 140,
        )

        visible_drawables = []

        # 맵 프롭 (난파선 등)
        for prop in self.props:
            pr = pygame.Rect(prop.x, prop.y, prop.width, prop.height)
            if view_rect.colliderect(pr):
                visible_drawables.append((prop.render_y, prop))

        # 바위
        for rock in self.obstacles:
            r = pygame.Rect(rock.x, rock.y, rock.width, rock.height)
            if view_rect.colliderect(r):
                visible_drawables.append((rock.render_y, rock))

        # 야자수
        for tree in self.trees:
            tr = pygame.Rect(tree.x, tree.y, tree.width, tree.height)
            if view_rect.colliderect(tr):
                visible_drawables.append((tree.render_y, tree))

        # 구조물 (거처, 모닥불)
        for sh in self.shelters:
            sr = pygame.Rect(sh.x, sh.y, sh.width, sh.height)
            if view_rect.colliderect(sr):
                visible_drawables.append((sh.render_y, sh))

        for cf in self.campfires:
            cr = pygame.Rect(cf.x, cf.y, cf.width, cf.height)
            if view_rect.colliderect(cr):
                visible_drawables.append((cf.render_y, cf))

        # 탐험가의 일지
        if self.journal:
            jr = pygame.Rect(self.journal.x, self.journal.y, self.journal.width, self.journal.height)
            if view_rect.colliderect(jr):
                visible_drawables.append((self.journal.render_y, self.journal))

        # 최종 뗏목 건조대
        if self.raft_slipway:
            rr = pygame.Rect(
                self.raft_slipway.x,
                self.raft_slipway.y,
                self.raft_slipway.width,
                self.raft_slipway.height,
            )
            if view_rect.colliderect(rr):
                visible_drawables.append((self.raft_slipway.render_y, self.raft_slipway))

        # 멧돼지
        for boar in self.boars:
            br = pygame.Rect(int(boar.x), int(boar.y), boar.width, boar.height)
            if view_rect.colliderect(br):
                visible_drawables.append((boar.render_y, boar))

        for snake in self.snakes:
            if view_rect.colliderect(snake.rect):
                visible_drawables.append((snake.render_y, snake))
            for projectile in snake.projectiles:
                if view_rect.colliderect(projectile.render_rect):
                    visible_drawables.append((projectile.render_y, projectile))

        # 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active:
                nr = pygame.Rect(node.x, node.y, node.width, node.height)
                if view_rect.colliderect(nr):
                    visible_drawables.append((node.render_y, node))

        # 바닥에 떨어진 아이템 (나무 원목 등)
        for item in self.dropped_items:
            if item.is_active:
                ir = pygame.Rect(int(item.x), int(item.y), item.width, item.height)
                if view_rect.colliderect(ir):
                    visible_drawables.append((item.render_y, item))

        # 플레이어
        visible_drawables.append((player.hitbox.bottom, player))

        # Y 정렬 후 그리기
        visible_drawables.sort(key=lambda item: item[0])
        for _, entity in visible_drawables:
            entity.draw(target_surface, camera)

    def draw_lighting_and_darkness(self, target_surface: pygame.Surface, camera: Camera, player):
        alpha = self.time_system.get_darkness_alpha()
        if alpha <= 0:
            return

        dark_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dark_surf.fill((10, 16, 28, alpha))

        # 5. 밤이 됐을 때 플레이어 주변이 기본으로 밝게 빛나지 않게 처리 (오로지 횃불 또는 모닥불만 조명 제공)
        player_screen_x = int(player.hitbox.centerx - camera.x)
        player_screen_y = int(player.hitbox.centery - camera.y)

        if player.selected_item_id == "torch":
            torch_radius = 160
            player_light = get_light_mask(torch_radius)
            dark_surf.blit(
                player_light,
                (player_screen_x - torch_radius, player_screen_y - torch_radius),
                special_flags=pygame.BLEND_RGBA_SUB,
            )

        # 모닥불 조명 뚫기
        for cf in self.campfires:
            cf_screen_x = int(cf.center.x - camera.x)
            cf_screen_y = int(cf.center.y - camera.y)
            if -100 <= cf_screen_x <= SCREEN_WIDTH + 100 and -100 <= cf_screen_y <= SCREEN_HEIGHT + 100:
                cf_light = get_light_mask(cf.light_radius)
                dark_surf.blit(
                    cf_light,
                    (cf_screen_x - cf.light_radius, cf_screen_y - cf.light_radius),
                    special_flags=pygame.BLEND_RGBA_SUB,
                )

        target_surface.blit(dark_surf, (0, 0))

    def draw_weather(self, target_surface: pygame.Surface, camera: Camera):
        self.weather.draw(target_surface, camera, self.time_system.current_day)

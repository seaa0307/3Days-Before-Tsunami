'''
해일 전 3일 (3 Days Before Tsunami)
월드 맵, 타일 시스템, 멧돼지 및 탐험가의 일지 연동 모듈
'''

import math
import random
from pathlib import Path
from typing import Optional, Type
import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    TILE_SIZE,
    PLAYER_WIDTH,
    PLAYER_HEIGHT,
    NIGHT_VISION_RADIUS_BASE,
    TORCH_VISION_BONUS,
    CAMPFIRE_LIGHT_RADIUS,
)
from image_assets import fit_sprite, get_item_sprite, get_item_surface, scale_pixel_art
from tiled_map import TiledMap
from time_system import TimeSystem
from structures import PlacedCampfire, PlacedShelter
from journal import PlacedJournal
from boar import WildBoar
from raft import RaftSlipway
from resource_nodes import (
    BranchNode,
    StoneNode,
    FiberNode,
    BerryBushNode,
    InteractableTree,
    ResourceNode,
)

# 타일 종류 ID
TILE_DEEP_WATER = 0     # 깊은 바다 (이동 불가)
TILE_SHALLOW_WATER = 1  # 해안 얕은 바다 (파도 거품)
TILE_SAND = 2           # 모래사장
TILE_GRASS = 3          # 초원
TILE_DARK_GRASS = 4     # 고지대 잔디

_LIGHT_MASK_CACHE = {}


def get_light_mask(radius: int) -> pygame.Surface:
    '''부드러운 원형 빛 구멍 마스크 생성 및 캐시'''
    radius = int(radius)
    if radius in _LIGHT_MASK_CACHE:
        return _LIGHT_MASK_CACHE[radius]

    size = radius * 2
    mask = pygame.Surface((size, size), pygame.SRCALPHA)
    step = 4
    for r in range(radius, 0, -step):
        factor = (1.0 - (r / radius) ** 1.6)
        alpha = int(255 * factor)
        pygame.draw.circle(mask, (0, 0, 0, alpha), (radius, radius), r)

    _LIGHT_MASK_CACHE[radius] = mask
    return mask


class Camera:
    '''플레이어를 부드럽게 추적하고 월드 경계 내로 제한하는 카메라'''

    def __init__(self, world_width: int, world_height: int):
        self.world_width = world_width
        self.world_height = world_height
        self.x = 0.0
        self.y = 0.0

    def update(self, target_rect: pygame.Rect, dt: float = 1 / 60):
        target_x = target_rect.centerx - SCREEN_WIDTH / 2
        target_y = target_rect.centery - SCREEN_HEIGHT / 2

        follow_amount = 1.0 - math.exp(-8.0 * max(0.0, dt))
        self.x += (target_x - self.x) * follow_amount
        self.y += (target_y - self.y) * follow_amount

        max_x = max(0, self.world_width - SCREEN_WIDTH)
        max_y = max(0, self.world_height - SCREEN_HEIGHT)
        self.x = float(round(max(0.0, min(self.x, float(max_x)))))
        self.y = float(round(max(0.0, min(self.y, float(max_y)))))

    def apply_rect(self, rect: pygame.Rect) -> pygame.Rect:
        return rect.move(int(-self.x), int(-self.y))


class Rock:
    '''섬에 흩어져 있는 바위 장애물 (고체 충돌체 - 원본 16x16의 3배 정수 스케일)'''

    def __init__(self, x: int, y: int, size: str = "medium"):
        self.x = x
        self.y = y
        self.width = 48
        self.height = 48
        self.hitbox = pygame.Rect(x + 6, y + 16, 36, 24)

        variant = (x // TILE_SIZE + y // TILE_SIZE) % 2
        key = "stone" if variant == 0 else "stone_2"
        self.surface = scale_pixel_art(get_item_surface(key), 3)

    @property
    def render_y(self) -> int:
        return self.hitbox.bottom

    def draw(self, target_surface: pygame.Surface, camera: Camera):
        screen_x = int(self.x - camera.x)
        screen_y = int(self.y - camera.y)
        target_surface.blit(self.surface, (screen_x, screen_y))


class World:
    '''탑뷰 섬 맵, 시간 시스템, 멧돼지, 탐험가의 일지 및 사물 총괄'''

    def __init__(self):
        self.tiled_map = TiledMap(
            Path(__file__).parent / "assets" / "map" / "lsland.tmj",
            TILE_SIZE,
        )
        self.cols = self.tiled_map.cols
        self.rows = self.tiled_map.rows
        self.width = self.cols * TILE_SIZE
        self.height = self.rows * TILE_SIZE

        # 3일 시간 및 낮/밤 시스템
        self.time_system = TimeSystem()

        # 스폰 지점은 섬 남쪽 해변의 모래사장으로 설정합니다.
        self.spawn_point = (self.width // 2, self.height // 2)

        # 맵 데이터 및 엔티티 목록
        self.grid = self.tiled_map.terrain
        self.ground_surfaces = self.tiled_map.ground_surfaces
        self.obstacles = []       # 바위
        self.trees = []           # 벌목/흔들기 야자수
        self.resource_nodes = []  # 채집 가능한 바닥 자원 노드
        self._placement_rects = []
        self.campfires = []       # 설치된 모닥불 목록
        self.shelters = []        # 설치된 간이 거처 목록
        self.boars = []           # 숲의 멧돼지 목록
        self.dropped_items = []   # 바닥에 떨어진 아이템 (나무 원목 등)
        self.journal = None       # 시작 지점의 탐험가의 일지
        self.raft_slipway = None  # 해변의 최종 뗏목 건조대 및 탈출 뗏목

        # Tiled terrain, resource nodes, base camp, journal, and boar habitat
        self._generate_island()
        self._place_raft_slipway()

    def _generate_island(self):
        '''Place existing gameplay systems on top of the Tiled terrain.'''
        south_shore_rows = [
            row
            for row in range(self.rows - 1)
            if any(
                self.grid[row][column] == TILE_SAND
                and self.grid[row + 1][column] == TILE_DEEP_WATER
                for column in range(self.cols)
            )
        ]
        if not south_shore_rows:
            raise ValueError("The island map has no south-facing sandy shoreline for the player spawn.")

        south_shore_row = max(south_shore_rows)
        beach_row = south_shore_row - 1
        beach_columns = [
            column
            for column in range(self.cols)
            if self.grid[beach_row][column] == TILE_SAND
        ]
        if not beach_columns:
            raise ValueError("The island map has no sandy beach tile beside its southern shoreline.")

        center_col = self.cols // 2
        spawn_col = min(beach_columns, key=lambda column: abs(column - center_col))
        spawn_row = beach_row
        spawn_x = spawn_col * TILE_SIZE + TILE_SIZE // 2
        spawn_y = spawn_row * TILE_SIZE + TILE_SIZE // 2
        self.spawn_point = (
            spawn_x - PLAYER_WIDTH // 2,
            spawn_y - PLAYER_HEIGHT // 2,
        )

        # 시작 지점 옆에는 일지만 두고, 모닥불과 거처는 직접 만들도록 합니다.
        self.journal = PlacedJournal(spawn_x - 88, spawn_y - 16)
        self._placement_rects.append(
            pygame.Rect(self.journal.x, self.journal.y, self.journal.width, self.journal.height)
        )

        # 3. 숲 군집, 해변 자원 무리와 멧돼지 서식지 배치
        self._populate_resources(spawn_x, spawn_y, random.Random(2026))

    def _place_raft_slipway(self):
        '''Place the build site at the island's southern sand-to-ocean shoreline.'''
        south_shore = [
            (column, row)
            for row in range(self.rows - 1)
            for column in range(self.cols)
            if self.grid[row][column] == TILE_SAND
            and self.grid[row + 1][column] == TILE_DEEP_WATER
        ]
        if not south_shore:
            raise ValueError("The island map has no south-facing sandy shoreline for the raft.")

        south_row = max(row for _, row in south_shore)
        shore_columns = sorted(column for column, row in south_shore if row == south_row)
        segments = []
        segment_start = segment_end = shore_columns[0]
        for column in shore_columns[1:]:
            if column == segment_end + 1:
                segment_end = column
            else:
                segments.append((segment_start, segment_end))
                segment_start = segment_end = column
        segments.append((segment_start, segment_end))
        start_column, end_column = max(segments, key=lambda segment: segment[1] - segment[0])

        raft_x = round((start_column + end_column + 1) * TILE_SIZE / 2 - RaftSlipway.WIDTH / 2)
        raft_y = (south_row + 1) * TILE_SIZE - RaftSlipway.HEIGHT // 2
        self.raft_slipway = RaftSlipway(raft_x, raft_y)

    def _terrain_at(self, x: int, y: int) -> Optional[int]:
        column = int(x // TILE_SIZE)
        row = int(y // TILE_SIZE)
        if 0 <= column < self.cols and 0 <= row < self.rows:
            return self.grid[row][column]
        return None

    def _is_terrain(self, rect: pygame.Rect, allowed_terrain: tuple[int, ...], margin: int = 4) -> bool:
        '''사각형과 안전 여백 전체가 지정된 지형 타일 안에 있는지 검사'''
        checked_rect = rect.inflate(margin * 2, margin * 2)
        min_col = checked_rect.left // TILE_SIZE
        max_col = (checked_rect.right - 1) // TILE_SIZE
        min_row = checked_rect.top // TILE_SIZE
        max_row = (checked_rect.bottom - 1) // TILE_SIZE

        for row in range(min_row, max_row + 1):
            for column in range(min_col, max_col + 1):
                if self._terrain_at(column * TILE_SIZE, row * TILE_SIZE) not in allowed_terrain:
                    return False
        return True

    def _can_place(self, rect: pygame.Rect, allowed_terrain: tuple[int, ...], min_spawn_dist: float = 90.0, margin: int = 4) -> bool:
        if not self._is_terrain(rect, allowed_terrain, margin=margin):
            return False

        spawn_x, spawn_y = self.spawn_point
        if math.hypot(rect.centerx - spawn_x, rect.centery - spawn_y) < min_spawn_dist:
            return False
        return not any(rect.inflate(6, 6).colliderect(other) for other in self._placement_rects)

    def _try_add_resource(
        self,
        node_type: Type[ResourceNode],
        x: int,
        y: int,
        allowed_terrain: tuple[int, ...],
        min_spawn_dist: float = 90.0,
        margin: int = 4,
    ) -> bool:
        node = node_type(x, y)
        rect = pygame.Rect(node.x, node.y, node.width, node.height)
        if not self._can_place(rect, allowed_terrain, min_spawn_dist=min_spawn_dist, margin=margin):
            return False
        self.resource_nodes.append(node)
        self._placement_rects.append(rect)
        return True

    def _populate_resources(self, spawn_x: int, spawn_y: int, rng: random.Random):
        grass_types = (TILE_GRASS, TILE_DARK_GRASS)
        pure_grass = (TILE_GRASS,)
        pure_sand = (TILE_SAND,)

        grass_tiles = [
            (c, r) for r in range(self.rows) for c in range(self.cols)
            if self.grid[r][c] in grass_types
        ]
        sand_tiles = [
            (c, r) for r in range(self.rows) for c in range(self.cols)
            if self.grid[r][c] in pure_sand
        ]

        # -------------------------------------------------------------
        # 1. 야자수 (InteractableTree): 적절한 간격을 두어 시야를 가리지 않게 배치 (15~18그루)
        # -------------------------------------------------------------
        tree_trunks = []
        shuffled_grass = list(grass_tiles)
        rng.shuffle(shuffled_grass)

        for c, r in shuffled_grass:
            if len(self.trees) >= 16:
                break
            tx = c * TILE_SIZE + TILE_SIZE // 2 - 45
            ty = r * TILE_SIZE + TILE_SIZE // 2 - 96
            tree = InteractableTree(tx, ty, has_coconuts=(len(self.trees) % 2 == 0))
            trunk = tree.hitbox

            # 나무 밑동 간 최소 120px 간격 유지 (숲길 통로 확보 및 화면 과도한 가림 방지)
            if any(math.dist(trunk.center, t.center) < 120 for t in tree_trunks):
                continue
            if math.hypot(trunk.centerx - spawn_x, trunk.centery - spawn_y) < 130:
                continue
            # 나무 전체가 해안에서 떨어진 잔디 위에 놓이도록 확인
            tree_rect = pygame.Rect(tree.x, tree.y, tree.width, tree.height)
            if not self._is_terrain(tree_rect, grass_types, margin=20):
                continue
            if any(trunk.inflate(14, 14).colliderect(other) for other in self._placement_rects):
                continue

            self.trees.append(tree)
            tree_trunks.append(trunk)
            # 나무 밑동 주변에 다른 자원 노드가 겹치지 않도록 등록
            self._placement_rects.append(trunk.inflate(20, 20))

        # -------------------------------------------------------------
        # 2. 베리 덤불 (BerryBushNode): 오로지 순수 잔디 위에만 배치 (16~20개)
        # -------------------------------------------------------------
        rng.shuffle(shuffled_grass)
        berry_count = 0
        for c, r in shuffled_grass:
            if berry_count >= 18:
                break
            bx = c * TILE_SIZE + rng.randint(-4, 4)
            by = r * TILE_SIZE + rng.randint(-4, 4)
            if self._try_add_resource(BerryBushNode, bx, by, pure_grass, min_spawn_dist=95, margin=20):
                berry_count += 1

        # -------------------------------------------------------------
        # 3. 풀 (FiberNode): 오로지 순수 잔디 위에만 풍성하게 배치 (32~40개)
        # -------------------------------------------------------------
        fiber_count = 0
        for _ in range(4):
            rng.shuffle(shuffled_grass)
            for c, r in shuffled_grass:
                if fiber_count >= 36:
                    break
                fx = c * TILE_SIZE + rng.randint(-6, 6)
                fy = r * TILE_SIZE + rng.randint(-6, 6)
                if self._try_add_resource(FiberNode, fx, fy, pure_grass, min_spawn_dist=85, margin=20):
                    fiber_count += 1

        # -------------------------------------------------------------
        # 4. 잔디 영역 나뭇가지 및 돌 (채집 자원)
        # -------------------------------------------------------------
        branch_grass_count = 0
        rng.shuffle(shuffled_grass)
        for c, r in shuffled_grass:
            if branch_grass_count >= 10:
                break
            x = c * TILE_SIZE + rng.randint(-6, 6)
            y = r * TILE_SIZE + rng.randint(-6, 6)
            if self._try_add_resource(BranchNode, x, y, pure_grass, min_spawn_dist=75, margin=4):
                branch_grass_count += 1

        stone_grass_count = 0
        rng.shuffle(shuffled_grass)
        for c, r in shuffled_grass:
            if stone_grass_count >= 6:
                break
            x = c * TILE_SIZE + rng.randint(-6, 6)
            y = r * TILE_SIZE + rng.randint(-6, 6)
            if self._try_add_resource(StoneNode, x, y, pure_grass, min_spawn_dist=75, margin=4):
                stone_grass_count += 1

        # 바위 장애물 2개 (잔디 위)
        rock_count = 0
        rng.shuffle(shuffled_grass)
        for c, r in shuffled_grass:
            if rock_count >= 2:
                break
            rx = c * TILE_SIZE
            ry = r * TILE_SIZE
            rock = Rock(rx, ry)
            rect = pygame.Rect(rock.x, rock.y, rock.width, rock.height)
            if self._can_place(rect, pure_grass, min_spawn_dist=120, margin=4):
                self.obstacles.append(rock)
                self._placement_rects.append(rect)
                rock_count += 1

        # -------------------------------------------------------------
        # 5. 해변 모래(TILE_SAND) 영역: 베리와 풀은 절대 배치하지 않고, 돌과 나뭇가지만 배치
        # -------------------------------------------------------------
        shuffled_sand = list(sand_tiles)
        rng.shuffle(shuffled_sand)
        sand_stone_count = 0
        for c, r in shuffled_sand:
            if sand_stone_count >= 16:
                break
            sx = c * TILE_SIZE + rng.randint(-6, 6)
            sy = r * TILE_SIZE + rng.randint(-6, 6)
            if self._try_add_resource(StoneNode, sx, sy, pure_sand, min_spawn_dist=80, margin=4):
                sand_stone_count += 1

        rng.shuffle(shuffled_sand)
        sand_branch_count = 0
        for c, r in shuffled_sand:
            if sand_branch_count >= 16:
                break
            bx = c * TILE_SIZE + rng.randint(-6, 6)
            by = r * TILE_SIZE + rng.randint(-6, 6)
            if self._try_add_resource(BranchNode, bx, by, pure_sand, min_spawn_dist=80, margin=4):
                sand_branch_count += 1

        # -------------------------------------------------------------
        # 6. 멧돼지 (WildBoar): 숲속 깊은 잔디밭에 서식지 배치
        # -------------------------------------------------------------
        boar_candidates = [
            (c * TILE_SIZE + TILE_SIZE // 2, r * TILE_SIZE + TILE_SIZE // 2)
            for c, r in grass_tiles
            if math.hypot(c * TILE_SIZE - spawn_x, r * TILE_SIZE - spawn_y) > 280
        ]
        if boar_candidates:
            boar_x, boar_y = rng.choice(boar_candidates)
            self.boars.append(WildBoar(boar_x, boar_y))

    def add_dropped_item(self, item):
        '''바닥에 떨어지는 아이템 등록'''
        self.dropped_items.append(item)

    def add_campfire(self, x: int, y: int):
        cf = PlacedCampfire(x, y)
        self.campfires.append(cf)
        return cf

    def add_shelter(self, x: int, y: int):
        sh = PlacedShelter(x, y)
        self.shelters.append(sh)
        return sh

    def is_solid_tile(self, col: int, row: int) -> bool:
        if col < 0 or col >= self.cols or row < 0 or row >= self.rows:
            return True
        return self.grid[row][col] == TILE_DEEP_WATER

    def get_colliding_obstacles(self, hitbox: pygame.Rect):
        colliders = []

        min_c = max(0, (hitbox.left - 10) // TILE_SIZE)
        max_c = min(self.cols - 1, (hitbox.right + 10) // TILE_SIZE)
        min_r = max(0, (hitbox.top - 10) // TILE_SIZE)
        max_r = min(self.rows - 1, (hitbox.bottom + 10) // TILE_SIZE)

        for r in range(min_r, max_r + 1):
            for c in range(min_c, max_c + 1):
                if self.is_solid_tile(c, r):
                    colliders.append(
                        pygame.Rect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    )

        for obj in self.obstacles:
            if hitbox.inflate(30, 30).colliderect(obj.hitbox):
                colliders.append(obj.hitbox)

        for tree in self.trees:
            if hitbox.inflate(30, 30).colliderect(tree.hitbox):
                colliders.append(tree.hitbox)

        for sh in self.shelters:
            if hitbox.inflate(30, 30).colliderect(sh.hitbox):
                colliders.append(sh.hitbox)

        for cf in self.campfires:
            if hitbox.inflate(30, 30).colliderect(cf.hitbox):
                colliders.append(cf.hitbox)

        return colliders

    def get_nearby_interactable(self, player):
        '''플레이어 주변의 최우선 상호작용 대상'''
        closest_node = None
        closest_dist = float("inf")
        player_pos = pygame.Vector2(player.hitbox.centerx, player.hitbox.centery)

        if self.raft_slipway and self.raft_slipway.can_interact(player):
            return self.raft_slipway

        # 1. 탐험가의 일지
        if self.journal and self.journal.can_interact(player):
            d = player_pos.distance_to(self.journal.center)
            if d < closest_dist:
                closest_dist = d
                closest_node = self.journal

        # 2. 거처 (수면)
        for sh in self.shelters:
            if sh.can_interact(player):
                d = player_pos.distance_to(sh.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = sh

        # 3. 모닥불
        for cf in self.campfires:
            if cf.can_interact(player):
                d = player_pos.distance_to(cf.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = cf

        # 4. 야자수
        for tree in self.trees:
            if tree.can_interact(player):
                d = player_pos.distance_to(tree.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = tree

        # 5. 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active and node.can_interact(player):
                d = player_pos.distance_to(node.center)
                if d < closest_dist:
                    closest_dist = d
                    closest_node = node

        return closest_node

    def update(self, dt: float, player) -> list:
        '''모닥불, 멧돼지 AI 및 바닥 드롭 아이템 갱신'''
        events = []
        if self.raft_slipway:
            self.raft_slipway.update(dt)
        for cf in self.campfires:
            cf.update(dt)

        # 바닥에 떨어진 아이템 (나무 원목 등) 픽업 판정 및 갱신
        for item in self.dropped_items:
            item.update(dt)
            if item.check_pickup(player):
                events.append(("ITEM_PICKUP", f"+{item.count} 나무 원목 획득!"))
        self.dropped_items = [it for it in self.dropped_items if it.is_active]

        # 멧돼지 AI 업데이트 및 공격 이벤트 감지
        for boar in self.boars:
            attack_hit, damage, msg = boar.update(dt, player, self)
            if attack_hit:
                events.append(("BOAR_ATTACK", msg))

        return events

    def draw_ground(self, target_surface: pygame.Surface, camera: Camera):
        start_col = max(0, int(camera.x // TILE_SIZE))
        end_col = min(self.cols, int((camera.x + SCREEN_WIDTH) // TILE_SIZE) + 2)
        start_row = max(0, int(camera.y // TILE_SIZE))
        end_row = min(self.rows, int((camera.y + SCREEN_HEIGHT) // TILE_SIZE) + 2)

        for r in range(start_row, end_row):
            for c in range(start_col, end_col):
                surf = self.ground_surfaces[r][c]
                screen_x = int(c * TILE_SIZE - camera.x)
                screen_y = int(r * TILE_SIZE - camera.y)
                target_surface.blit(surf, (screen_x, screen_y))

    def draw_entities(self, target_surface: pygame.Surface, camera: Camera, player):
        '''Y-Sorting 깊이 렌더링 (바위, 나무, 거처, 모닥불, 일지, 멧돼지, 자원, 플레이어)'''
        view_rect = pygame.Rect(
            int(camera.x - 70),
            int(camera.y - 70),
            SCREEN_WIDTH + 140,
            SCREEN_HEIGHT + 140,
        )

        visible_drawables = []

        # 바위
        for rock in self.obstacles:
            r = pygame.Rect(rock.x, rock.y, rock.width, rock.height)
            if view_rect.colliderect(r):
                visible_drawables.append((rock.render_y, rock))

        # 야자수
        for tree in self.trees:
            tr = pygame.Rect(tree.x, tree.y, tree.width, tree.height)
            if view_rect.colliderect(tr):
                visible_drawables.append((tree.render_y, tree))

        # 구조물 (거처, 모닥불)
        for sh in self.shelters:
            sr = pygame.Rect(sh.x, sh.y, sh.width, sh.height)
            if view_rect.colliderect(sr):
                visible_drawables.append((sh.render_y, sh))

        for cf in self.campfires:
            cr = pygame.Rect(cf.x, cf.y, cf.width, cf.height)
            if view_rect.colliderect(cr):
                visible_drawables.append((cf.render_y, cf))

        # 탐험가의 일지
        if self.journal:
            jr = pygame.Rect(self.journal.x, self.journal.y, self.journal.width, self.journal.height)
            if view_rect.colliderect(jr):
                visible_drawables.append((self.journal.render_y, self.journal))

        # 최종 뗏목 건조대
        if self.raft_slipway:
            rr = pygame.Rect(
                self.raft_slipway.x,
                self.raft_slipway.y,
                self.raft_slipway.width,
                self.raft_slipway.height,
            )
            if view_rect.colliderect(rr):
                visible_drawables.append((self.raft_slipway.render_y, self.raft_slipway))

        # 멧돼지
        for boar in self.boars:
            br = pygame.Rect(int(boar.x), int(boar.y), boar.width, boar.height)
            if view_rect.colliderect(br):
                visible_drawables.append((boar.render_y, boar))

        # 바닥 자원 노드
        for node in self.resource_nodes:
            if node.is_active:
                nr = pygame.Rect(node.x, node.y, node.width, node.height)
                if view_rect.colliderect(nr):
                    visible_drawables.append((node.render_y, node))

        # 바닥에 떨어진 아이템 (나무 원목 등)
        for item in self.dropped_items:
            if item.is_active:
                ir = pygame.Rect(int(item.x), int(item.y), item.width, item.height)
                if view_rect.colliderect(ir):
                    visible_drawables.append((item.render_y, item))

        # 플레이어
        visible_drawables.append((player.hitbox.bottom, player))

        # Y 정렬 후 그리기
        visible_drawables.sort(key=lambda item: item[0])
        for _, entity in visible_drawables:
            entity.draw(target_surface, camera)

    def draw_lighting_and_darkness(self, target_surface: pygame.Surface, camera: Camera, player):
        alpha = self.time_system.get_darkness_alpha()
        if alpha <= 0:
            return

        dark_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dark_surf.fill((10, 16, 28, alpha))

        # 5. 밤이 됐을 때 플레이어 주변이 기본으로 밝게 빛나지 않게 처리 (오로지 횃불 또는 모닥불만 조명 제공)
        player_screen_x = int(player.hitbox.centerx - camera.x)
        player_screen_y = int(player.hitbox.centery - camera.y)

        if player.inventory.has_item("torch"):
            torch_radius = 160
            player_light = get_light_mask(torch_radius)
            dark_surf.blit(
                player_light,
                (player_screen_x - torch_radius, player_screen_y - torch_radius),
                special_flags=pygame.BLEND_RGBA_SUB,
            )

        # 모닥불 조명 뚫기
        for cf in self.campfires:
            cf_screen_x = int(cf.center.x - camera.x)
            cf_screen_y = int(cf.center.y - camera.y)
            if -100 <= cf_screen_x <= SCREEN_WIDTH + 100 and -100 <= cf_screen_y <= SCREEN_HEIGHT + 100:
                cf_light = get_light_mask(cf.light_radius)
                dark_surf.blit(
                    cf_light,
                    (cf_screen_x - cf.light_radius, cf_screen_y - cf.light_radius),
                    special_flags=pygame.BLEND_RGBA_SUB,
                )

        target_surface.blit(dark_surf, (0, 0))

"""
해일 전 5일 (5 Days Before Tsunami)
설정 및 상수 모듈
"""

# ==========================================
# 화면 및 성능 설정
# ==========================================
SCREEN_WIDTH = 960
SCREEN_HEIGHT = 540
FPS = 60
TITLE = "해일 전 5일 (5 Days Before Tsunami)"

# ==========================================
# 타일 및 월드 크기 (픽셀 아트 스타일: 48x48)
# ==========================================
TILE_SIZE = 48
MAP_COLS = 42
MAP_ROWS = 28
WORLD_WIDTH = MAP_COLS * TILE_SIZE    # 2016 px
WORLD_HEIGHT = MAP_ROWS * TILE_SIZE  # 1344 px

# ==========================================
# 플레이어 기본 설정
# ==========================================
PLAYER_SPEED = 210.0   # 초당 이동 픽셀 (WASD)
PLAYER_WIDTH = 32
PLAYER_HEIGHT = 44
HITBOX_WIDTH = 24
HITBOX_HEIGHT = 16
HITBOX_OFFSET_Y = 26   # 발 부분에 위치할 히트박스 Y 오프셋

# ==========================================
# 생존 수치 시스템 설정
# ==========================================
MAX_HEALTH = 100.0   # 체력 최대치
MAX_HUNGER = 100.0   # 허기 최대치
MAX_WARMTH = 100.0   # 체온 최대치

INITIAL_HEALTH = 100.0
INITIAL_HUNGER = 90.0
INITIAL_WARMTH = 100.0

# 감소율 (초당 감소량)
HUNGER_DECAY_RATE = 0.25        # 허기 초당 0.25 감소
NIGHT_WARMTH_DECAY_RATE = 0.15  # 체온 밤에 초당 0.15 감소
DAY_WARMTH_RECOVER_RATE = 0.20  # 낮 시간 자연 체온 회복 속도

# 체력 페널티 (허기/체온이 0일 때 초당 체력 감소량)
HEALTH_DECAY_HUNGER_ZERO = 0.5  # 허기 0일 때 초당 체력 0.5 감소
HEALTH_DECAY_WARMTH_ZERO = 0.5  # 체온 0일 때 초당 체력 0.5 감소

# 음식별 허기 회복량
BERRY_HUNGER_RECOVER = 20.0     # 베리 허기 +20
COCONUT_HUNGER_RECOVER = 30.0   # 코코넛 허기 +30

# ==========================================
# 시간 및 낮/밤 시스템 설정 (총 5일, 하루 5분 = 300초)
# ==========================================
TOTAL_DAYS = 5
DAY_TOTAL_SECONDS = 300.0

# 일차별 낮/밤 길이 스케줄 (초 단위)
# 1일: 낮 240초, 밤 60초
# 2일: 낮 210초, 밤 90초
# 3일: 낮 180초, 밤 120초
# 4일: 낮 150초, 밤 150초
# 5일: 낮 120초, 밤 180초
DAY_NIGHT_SCHEDULE = {
    1: {"day": 240.0, "night": 60.0},
    2: {"day": 210.0, "night": 90.0},
    3: {"day": 180.0, "night": 120.0},
    4: {"day": 150.0, "night": 150.0},
    5: {"day": 120.0, "night": 180.0},
}

# ==========================================
# 밤 시야 및 조명/모닥불/거처 설정
# ==========================================
NIGHT_VISION_RADIUS_BASE = 110    # 밤 기본 시야 반경 (픽셀)
TORCH_VISION_BONUS = 60          # 횃불 소지/장착 시 추가 시야 반경
CAMPFIRE_LIGHT_RADIUS = 180      # 모닥불 조명 반경
CAMPFIRE_WARMTH_RADIUS = 100     # 모닥불 체온 회복 범위 (거리)
CAMPFIRE_WARMTH_RECOVER_RATE = 1.2  # 모닥불 근처 초당 체온 회복량

DARKNESS_MAX_ALPHA = 215         # 밤 최대 암전 농도 (0~255)

# 간이 거처 수면 설정
SHELTER_SLEEP_HEALTH_RECOVER = 15.0  # 거처 수면 시 체력 15 회복
SLEEP_DISABLED_DAY = 5               # 수면 사용 불가 일차 (5일 차)

# ==========================================
# 멧돼지 (Wild Boar) 설정
# ==========================================
BOAR_ATTACK_DAMAGE = 10.0        # 공격력 10
BOAR_TELEGRAPH_TIME = 0.8        # 공격 예고 시간 0.8초
BOAR_PATROL_SPEED = 45.0         # 순찰 이동 속도
BOAR_CHARGE_SPEED = 260.0        # 돌진 속도
BOAR_AGGRO_RADIUS = 135.0        # 플레이어 감지 및 예고 시작 반경
BOAR_DEAGGRO_RADIUS = 280.0      # 추적 포기 및 복귀 반경
BOAR_TERRITORY_RADIUS = 150.0    # 서식지 순찰 반경
BOAR_HIT_COOLDOWN = 1.5          # 피격 후 연속 피해 방지 쿨타임 (초)

COLOR_BOAR_BODY = (75, 50, 35)
COLOR_BOAR_DARK = (45, 30, 20)
COLOR_BOAR_TUSK = (240, 235, 220)
COLOR_BOAR_EYE_ANGRY = (235, 40, 30)

# ==========================================
# 색상 팔레트 (픽셀 아트 / 섬 & 해일 분위기)
# ==========================================
COLOR_OCEAN_DEEP = (26, 60, 92)       # 깊은 바다 (이동 불가)
COLOR_OCEAN_SHALLOW = (48, 110, 140)  # 얕은 바다 (파도 경계)
COLOR_BEACH_SAND = (228, 207, 148)    # 모래사장
COLOR_BEACH_DARK = (205, 183, 126)    # 모래 무늬
COLOR_GRASS = (92, 156, 84)           # 잔디
COLOR_GRASS_DARK = (70, 128, 66)      # 잔디 그림자/패턴
COLOR_ROCK = (108, 114, 124)          # 바위
COLOR_ROCK_LIGHT = (144, 152, 164)    # 바위 하이라이트
COLOR_ROCK_DARK = (72, 76, 84)        # 바위 그림자
COLOR_TREE_TRUNK = (112, 76, 48)      # 나무 밑동
COLOR_TREE_LEAVES = (46, 114, 62)     # 나뭇잎
COLOR_TREE_LIGHT = (64, 146, 82)      # 나뭇잎 하이라이트

# 플레이어 픽셀 그래픽 색상
COLOR_PLAYER_SKIN = (245, 212, 178)
COLOR_PLAYER_SHIRT = (220, 84, 52)    # 주황/빨강 자켓
COLOR_PLAYER_PANTS = (44, 56, 80)     # 진청 바지
COLOR_PLAYER_HAIR = (60, 42, 34)      # 갈색 머리
COLOR_SHADOW = (0, 0, 0, 80)          # 반투명 그림자

# 생존 수치 UI 색상
COLOR_STAT_HEALTH = (235, 65, 65)     # 체력 바 빨강
COLOR_STAT_HUNGER = (240, 145, 45)    # 허기 바 주황
COLOR_STAT_WARMTH = (50, 185, 230)    # 체온 바 하늘/청록
COLOR_STAT_BG = (35, 40, 50)          # 바 배경색

# UI 색상
COLOR_UI_TEXT = (245, 245, 245)
COLOR_UI_BG = (18, 24, 32, 200)
COLOR_UI_ACCENT = (255, 204, 77)

'''
해일 전 3일 (3 Days Before Tsunami)
설정 및 상수 모듈
'''

# ==========================================
# 화면 및 성능 설정
# ==========================================
SCREEN_WIDTH = 960
SCREEN_HEIGHT = 540
FPS = 60
TITLE = "해일 전 3일 (3 Days Before Tsunami)"

# ==========================================
# 픽셀 아트 배율 및 타일 렌더링 크기 (16x16 원본 -> 3배 48x48)
# ==========================================
PIXEL_SCALE = 3
TILE_SIZE = 48

# ==========================================
# 플레이어 기본 설정 (원본 16x17의 3배 정수 스케일 48x51로 비율 정확히 일치)
# ==========================================
PLAYER_SPEED = 210.0   # 초당 이동 픽셀 (WASD)
PLAYER_WIDTH = 48      # 16 * 3
PLAYER_HEIGHT = 51     # 17 * 3
HITBOX_WIDTH = 24
HITBOX_HEIGHT = 16
HITBOX_OFFSET_Y = 32   # 발 부분에 위치할 히트박스 Y 오프셋

# ==========================================
# 생존 수치 시스템 설정
# ==========================================
MAX_HEALTH = 100.0   # 체력 최대치
MAX_HUNGER = 100.0   # 허기 최대치
MAX_WARMTH = 37.5    # 체온 최대치 (°C)

INITIAL_HEALTH = 100.0
INITIAL_HUNGER = 90.0
INITIAL_WARMTH = 36.5

# 감소율 (초당 감소량)
HUNGER_DECAY_RATE = 0.5         # 허기 초당 0.5 감소
WARMTH_DECAY_RATES = {
    1: {"day": 0.0, "night": 0.02},
    2: {"day": 0.015, "night": 0.04},
    3: {"day": 0.025, "night": 0.06},
}

# 체온별 초당 체력 감소량
HEALTH_DECAY_HUNGER_ZERO = 2.0  # 허기 0일 때 초당 체력 2 감소
WARMTH_DAMAGE_MILD_THRESHOLD = 34.5
WARMTH_DAMAGE_MODERATE_THRESHOLD = 32.0
WARMTH_DAMAGE_SEVERE_THRESHOLD = 28.0
HEALTH_DECAY_WARMTH_MILD = 5.0
HEALTH_DECAY_WARMTH_MODERATE = 10.0
HEALTH_DECAY_WARMTH_SEVERE = 20.0

# 음식별 허기 회복량
BERRY_HUNGER_RECOVER = 10.0     # 베리 허기 +10
COCONUT_HUNGER_RECOVER = 20.0   # 코코넛 허기 +20

# ==========================================
# 시간 및 낮/밤 시스템 설정 (총 3일, 하루 3분 = 180초)
# ==========================================
TOTAL_DAYS = 3
DAY_TOTAL_SECONDS = 180.0

# 일차별 낮/밤 길이 스케줄 (초 단위)
# 1일: 낮 150초, 밤 30초
# 2일: 낮 120초, 밤 60초
# 3일: 낮 90초, 밤 90초
DAY_NIGHT_SCHEDULE = {
    1: {"day": 150.0, "night": 30.0},
    2: {"day": 120.0, "night": 60.0},
    3: {"day": 90.0, "night": 90.0},
}

# ==========================================
# 밤 시야 및 조명/모닥불/거처 설정
# ==========================================
NIGHT_VISION_RADIUS_BASE = 110    # 밤 기본 시야 반경 (픽셀)
TORCH_VISION_BONUS = 60          # 횃불 소지/장착 시 추가 시야 반경
CAMPFIRE_LIGHT_RADIUS = 180      # 모닥불 조명 반경
CAMPFIRE_WARMTH_RADIUS = 100     # 모닥불 체온 회복 범위 (거리)
CAMPFIRE_WARMTH_RECOVER_RATE = 0.08  # 횃불 장착 또는 모닥불 근처 초당 체온 회복량 (°C)

DARKNESS_MAX_ALPHA = 250         # 횃불이 없을 때 밤 시야를 크게 제한

# 간이 거처 수면 설정
SHELTER_SLEEP_HEALTH_RECOVER = 15.0  # 거처 수면 시 체력 15 회복
SLEEP_DISABLED_DAY = 3               # 수면 사용 불가 일차 (3일 차)

# ==========================================
# 멧돼지 (Wild Boar) 설정
# ==========================================
BOAR_ATTACK_DAMAGE = 20.0        # 공격력 20
BOAR_TELEGRAPH_TIME = 0.5        # 공격 예고 시간
BOAR_PATROL_SPEED = 45.0         # 순찰 이동 속도
BOAR_CHARGE_SPEED = 320.0        # 돌진 속도
BOAR_AGGRO_RADIUS = 135.0        # 플레이어 감지 및 예고 시작 반경
BOAR_DAY1_AGGRO_RADIUS = BOAR_AGGRO_RADIUS + TILE_SIZE * 2
BOAR_DAY2_AGGRO_RADIUS = BOAR_AGGRO_RADIUS + TILE_SIZE * 4
BOAR_DAY2_TELEGRAPH_TIME = 0.35 # 2일 차부터 공격 예고 시간 단축
BOAR_DAY2_CHARGE_SPEED = 360.0  # 2일 차부터 돌진 속도 증가
BOAR_DAY2_CHARGE_DURATION = 1.3 # 2일 차부터 돌진 거리 증가
BOAR_DAY2_HIT_COOLDOWN = 1.0    # 2일 차부터 재공격 대기 시간 단축
BOAR_DEAGGRO_RADIUS = 280.0      # 추적 포기 및 복귀 반경
BOAR_TERRITORY_RADIUS = 150.0    # 서식지 순찰 반경
BOAR_HIT_COOLDOWN = 1.5          # 피격 후 연속 피해 방지 쿨타임 (초)

# 뱀의 독 원거리 공격
SNAKE_ATTACK_RANGE = 340.0
SNAKE_ATTACK_WINDUP = 0.9
SNAKE_ATTACK_COOLDOWN = 4.0
SNAKE_VENOM_SPEED = 300.0
SNAKE_POISON_DURATION = 10.0
SNAKE_POISON_DAMAGE_PER_SECOND = 3.0
SNAKE_POISON_FLASH_PERIOD = 0.36

# 3일 차 폭풍 및 번개
LIGHTNING_MIN_INTERVAL = 8.0
LIGHTNING_MAX_INTERVAL = 15.0
LIGHTNING_DAMAGE = 20.0
LIGHTNING_HIT_RADIUS = 48.0
LIGHTNING_SPREAD_X = 150.0
LIGHTNING_SPREAD_Y = 100.0

COLOR_BOAR_BODY = (75, 50, 35)
COLOR_BOAR_DARK = (45, 30, 20)
COLOR_BOAR_TUSK = (240, 235, 220)
COLOR_BOAR_EYE_ANGRY = (235, 40, 30)
COLOR_SNAKE_BODY = (244, 243, 235)
COLOR_SNAKE_DARK = (98, 91, 103)
COLOR_SNAKE_BELLY = (220, 218, 208)
COLOR_SNAKE_EYE = (214, 48, 67)
COLOR_SNAKE_VENOM = (190, 113, 235)
COLOR_SNAKE_VENOM_DARK = (112, 58, 158)
COLOR_PLAYER_POISON_FLASH = (224, 112, 255)

# ==========================================
# 색상 팔레트 (픽셀 아트 / 섬 & 해일 분위기)
# ==========================================
COLOR_OCEAN_DEEP = (26, 60, 92)       # 깊은 바다 (이동 불가)
COLOR_OCEAN_SHALLOW = (48, 110, 140)  # 얕은 바다 (파도 경계)
COLOR_BEACH_SAND = (228, 207, 148)    # 모래사장
COLOR_BEACH_DARK = (205, 183, 126)    # 모래 무늬
COLOR_GRASS = (92, 156, 84)           # 잔디
COLOR_GRASS_DARK = (70, 128, 66)      # 잔디 그림자/패턴
COLOR_ROCK = (108, 114, 124)          # 바위
COLOR_ROCK_LIGHT = (144, 152, 164)    # 바위 하이라이트
COLOR_ROCK_DARK = (72, 76, 84)        # 바위 그림자
COLOR_TREE_TRUNK = (112, 76, 48)      # 나무 밑동
COLOR_TREE_LEAVES = (46, 114, 62)     # 나뭇잎
COLOR_TREE_LIGHT = (64, 146, 82)      # 나뭇잎 하이라이트

# 플레이어 픽셀 그래픽 색상
COLOR_PLAYER_SKIN = (245, 212, 178)
COLOR_PLAYER_SHIRT = (220, 84, 52)    # 주황/빨강 자켓
COLOR_PLAYER_PANTS = (44, 56, 80)     # 진청 바지
COLOR_PLAYER_HAIR = (60, 42, 34)      # 갈색 머리
COLOR_SHADOW = (0, 0, 0, 80)          # 반투명 그림자

# 생존 수치 UI 색상
COLOR_STAT_HEALTH = (235, 65, 65)     # 체력 바 빨강
COLOR_STAT_HUNGER = (240, 145, 45)    # 허기 바 주황
COLOR_STAT_WARMTH = (50, 185, 230)    # 체온 바 하늘/청록
COLOR_STAT_BG = (35, 40, 50)          # 바 배경색

# UI 색상
COLOR_UI_DARK = (53, 35, 39)
COLOR_UI_PANEL = (99, 72, 77)
COLOR_UI_EDGE = (207, 157, 110)
COLOR_UI_LIGHT = (243, 219, 182)
COLOR_UI_TEXT = (255, 247, 226)
COLOR_UI_BG = (30, 20, 28, 210)
COLOR_UI_ACCENT = (239, 181, 110)

"""
해일 전 5일 (5 Days Before Tsunami)
생존 수치 바, 시간 HUD, 인벤토리/제작/섭취/설치 UI 시스템
"""

import pygame
from settings import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    COLOR_UI_TEXT,
    COLOR_UI_BG,
    COLOR_UI_ACCENT,
    COLOR_STAT_HEALTH,
    COLOR_STAT_HUNGER,
    COLOR_STAT_WARMTH,
    COLOR_STAT_BG,
    MAX_HEALTH,
    MAX_HUNGER,
    MAX_WARMTH,
)
from items import get_item, get_recipe, get_item_icon, RECIPES
from fonts import get_font


class NotificationManager:
    """화면에 표시되는 획득/제작/경고 알림 메시지 관리자"""

    def __init__(self):
        self.notifications = []

    def add(self, text: str, color=(255, 255, 255), duration: float = 3.0):
        if len(self.notifications) >= 4:
            self.notifications.pop(0)
        self.notifications.append({"text": text, "color": color, "time": duration, "max_time": duration})

    def update(self, dt: float):
        for n in self.notifications:
            n["time"] -= dt
        self.notifications = [n for n in self.notifications if n["time"] > 0]

    def draw(self, surface: pygame.Surface):
        font = get_font(14)
        y = 110
        for n in self.notifications:
            alpha = min(255, int((n["time"] / n["max_time"]) * 350))
            if alpha <= 0:
                continue

            text_surf = font.render(n["text"], True, n["color"])
            bg_w = text_surf.get_width() + 20
            bg_h = 28
            bg_surf = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
            pygame.draw.rect(bg_surf, (15, 20, 28, min(220, alpha)), (0, 0, bg_w, bg_h), border_radius=5)
            pygame.draw.rect(bg_surf, (80, 100, 130, min(180, alpha)), (0, 0, bg_w, bg_h), 1, border_radius=5)

            bg_surf.blit(text_surf, (10, 5))
            surface.blit(bg_surf, (16, y))
            y += 34


def draw_survival_bars(surface: pygame.Surface, player):
    """우측 상단 체력, 허기, 체온 생존 수치 바 렌더링"""
    survival = player.survival
    label_font = get_font(13, bold=True)
    val_font = get_font(12)

    panel_w = 230
    panel_h = 88
    panel_x = SCREEN_WIDTH - panel_w - 16
    panel_y = 16

    panel_surf = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    pygame.draw.rect(panel_surf, COLOR_UI_BG, (0, 0, panel_w, panel_h), border_radius=6)
    pygame.draw.rect(panel_surf, (70, 90, 110, 180), (0, 0, panel_w, panel_h), width=1, border_radius=6)

    # 3대 생존 수치 데이터 정의 (라벨, 현재값, 최대치, 색상)
    stats = [
        ("체력", survival.health, MAX_HEALTH, COLOR_STAT_HEALTH),
        ("허기", survival.hunger, MAX_HUNGER, COLOR_STAT_HUNGER),
        ("체온", survival.warmth, MAX_WARMTH, COLOR_STAT_WARMTH),
    ]

    bar_x = 44
    bar_w = 124
    bar_h = 13
    row_y = 12

    for label, val, max_val, color in stats:
        # 라벨
        lbl_surf = label_font.render(label, True, (230, 235, 240))
        panel_surf.blit(lbl_surf, (10, row_y - 2))

        # 게이지 바 배경
        bar_bg_rect = pygame.Rect(bar_x, row_y, bar_w, bar_h)
        pygame.draw.rect(panel_surf, COLOR_STAT_BG, bar_bg_rect, border_radius=3)

        # 게이지 바 채움
        fill_ratio = max(0.0, min(1.0, val / max_val))
        fill_w = int(bar_w * fill_ratio)
        if fill_w > 0:
            fill_rect = pygame.Rect(bar_x, row_y, fill_w, bar_h)
            pygame.draw.rect(panel_surf, color, fill_rect, border_radius=3)

        # 바 테두리
        pygame.draw.rect(panel_surf, (80, 90, 105), bar_bg_rect, 1, border_radius=3)

        # 수치 텍스트
        val_txt = f"{int(val)}"
        val_surf = val_font.render(val_txt, True, (245, 245, 245))
        panel_surf.blit(val_surf, (bar_x + bar_w + 8, row_y - 2))

        # 모닥불 온기 표시 (체온 행)
        if label == "체온" and player.near_campfire:
            fire_tag = val_font.render("온기+", True, (255, 180, 70))
            panel_surf.blit(fire_tag, (bar_x + bar_w + 32, row_y - 2))

        row_y += 24

    surface.blit(panel_surf, (panel_x, panel_y))


def draw_time_hud(surface: pygame.Surface, time_system):
    """상단 중앙 5일간의 낮/밤 시간 경과 HUD 렌더링"""
    title_font = get_font(15, bold=True)
    sub_font = get_font(13)

    panel_w = 210
    panel_h = 48
    panel_x = (SCREEN_WIDTH - panel_w) // 2
    panel_y = 16

    panel_surf = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    pygame.draw.rect(panel_surf, COLOR_UI_BG, (0, 0, panel_w, panel_h), border_radius=6)
    border_col = (70, 90, 110, 180) if not time_system.is_night else (100, 130, 180, 220)
    pygame.draw.rect(panel_surf, border_col, (0, 0, panel_w, panel_h), width=1, border_radius=6)

    # 낮/밤 아이콘 (원형 해 또는 초승달)
    is_night = time_system.is_night
    if not is_night:
        # 태양 (황금빛)
        pygame.draw.circle(panel_surf, (255, 200, 60), (22, 24), 9)
        phase_name = "낮"
        phase_col = (255, 215, 80)
    else:
        # 달 (은빛)
        pygame.draw.circle(panel_surf, (215, 230, 255), (22, 24), 9)
        pygame.draw.circle(panel_surf, (18, 24, 32), (26, 21), 7)
        phase_name = "밤"
        phase_col = (140, 180, 240)

    # 일차 텍스트
    day_txt = f"[{time_system.current_day}일 차] {phase_name}"
    day_surf = title_font.render(day_txt, True, phase_col)
    panel_surf.blit(day_surf, (42, 6))

    # 남은 시간
    rem_seconds = int(time_system.remaining_phase_time)
    time_txt = f"{rem_seconds}초 남음"
    time_surf = sub_font.render(time_txt, True, (210, 220, 235))
    panel_surf.blit(time_surf, (42, 26))

    surface.blit(panel_surf, (panel_x, panel_y))


class CraftingUI:
    """인벤토리 및 제작 창 UI (TAB 또는 I 키로 토글)"""

    def __init__(self):
        self.is_open = False
        self.width = 780
        self.height = 440
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2

        self.close_btn_rect = pygame.Rect(self.x + self.width - 34, self.y + 10, 24, 24)
        self.craft_btn_rects = []
        self.item_action_rects = []

    def toggle(self):
        self.is_open = not self.is_open

    def handle_event(self, event: pygame.event.Event, player, world, notifications: NotificationManager) -> bool:
        """
        UI 이벤트 처리 (아이템 제작, 음식 섭취, 구조물 설치)
        """
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_TAB, pygame.K_i, pygame.K_c):
                self.toggle()
                return True
            elif event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # 닫기 버튼 클릭
            if self.close_btn_rect.collidepoint(mouse_pos):
                self.is_open = False
                return True

            # 1. 인벤토리 액션 버튼 ([먹기], [설치]) 클릭 검사
            for item_id, action_type, btn_rect in self.item_action_rects:
                if btn_rect.collidepoint(mouse_pos):
                    if action_type == "eat":
                        success, rec, msg = player.survival.eat(item_id)
                        if success:
                            player.inventory.remove_item(item_id, 1)
                            notifications.add(msg, color=(100, 240, 140))
                        else:
                            notifications.add(msg, color=(255, 160, 90))
                    elif action_type == "place":
                        # 플레이어 앞쪽에 구조물 설치
                        px = player.x + (36 if player.facing == "right" else -36 if player.facing == "left" else 0)
                        py = player.y + (36 if player.facing == "down" else -36 if player.facing == "up" else 0)

                        if item_id == "campfire":
                            world.add_campfire(int(px), int(py))
                            player.inventory.remove_item("campfire", 1)
                            notifications.add("모닥불을 설치했습니다! 주변에서 체온을 회복합니다.", color=(255, 175, 75))
                            self.is_open = False
                        elif item_id == "shelter":
                            world.add_shelter(int(px), int(py))
                            player.inventory.remove_item("shelter", 1)
                            notifications.add("간이 거처를 설치했습니다! 밤에 잠을 잘 수 있습니다.", color=(200, 220, 110))
                            self.is_open = False
                    return True

            # 2. 제작 버튼 클릭 검사
            for recipe_id, btn_rect, can_craft, reason in self.craft_btn_rects:
                if btn_rect.collidepoint(mouse_pos):
                    if can_craft:
                        success, msg = player.inventory.craft(recipe_id)
                        if success:
                            notifications.add(msg, color=(80, 240, 120))
                    else:
                        notifications.add(reason, color=(255, 110, 90))
                    return True

        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            window_rect = pygame.Rect(self.x, self.y, self.width, self.height)
            if window_rect.collidepoint(event.pos):
                return True

        return True

    def draw(self, surface: pygame.Surface, player):
        if not self.is_open:
            return

        title_font = get_font(18, bold=True)
        header_font = get_font(15, bold=True)
        item_font = get_font(14)
        sub_font = get_font(13)
        btn_font = get_font(13, bold=True)

        # 1. 배경 어둡게 딤 처리
        dim_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim_surface.fill((5, 10, 15, 160))
        surface.blit(dim_surface, (0, 0))

        # 2. 메인 팝업 윈도우 패널
        win_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(win_surf, (24, 30, 42, 245), (0, 0, self.width, self.height), border_radius=8)
        pygame.draw.rect(win_surf, (80, 110, 145), (0, 0, self.width, self.height), 2, border_radius=8)

        # 3. 타이틀 바
        title_lbl = title_font.render("생존 가방 & 제작 (Inventory & Crafting)", True, COLOR_UI_ACCENT)
        win_surf.blit(title_lbl, (20, 14))

        # 닫기 버튼 [X]
        pygame.draw.rect(win_surf, (180, 60, 60), (self.width - 34, 10, 24, 24), border_radius=4)
        x_lbl = header_font.render("X", True, (255, 255, 255))
        win_surf.blit(x_lbl, (self.width - 27, 13))

        split_x = 300
        pygame.draw.line(win_surf, (60, 75, 100), (split_x, 46), (split_x, self.height - 18), 2)

        # ==========================================
        # [왼쪽 열: 인벤토리 및 사용/설치 액션]
        # ==========================================
        inv_title = header_font.render("보유 물품 (음식 섭취 / 구조물 설치)", True, (210, 220, 235))
        win_surf.blit(inv_title, (20, 52))

        self.item_action_rects.clear()
        inv_items = player.inventory.get_item_list() if player else []
        item_y = 84
        if not inv_items:
            empty_lbl = item_font.render("가방이 비어 있습니다.", True, (130, 140, 155))
            win_surf.blit(empty_lbl, (24, item_y + 10))
            hint_lbl = sub_font.render("섬에서 [E] 키로 자원을 채집하세요.", True, (100, 120, 140))
            win_surf.blit(hint_lbl, (24, item_y + 34))
        else:
            for item_id, count, metadata in inv_items:
                if item_y + 36 > self.height - 20:
                    break
                slot_w = split_x - 36
                slot_rect = pygame.Rect(18, item_y, slot_w, 32)
                pygame.draw.rect(win_surf, (34, 44, 60), slot_rect, border_radius=4)
                pygame.draw.rect(win_surf, (55, 70, 95), slot_rect, 1, border_radius=4)

                # 아이콘 & 이름 & 수량
                icon = get_item_icon(item_id, 24)
                win_surf.blit(icon, (24, item_y + 4))

                name_lbl = item_font.render(metadata["name"], True, (240, 240, 240))
                win_surf.blit(name_lbl, (52, item_y + 7))

                cnt_lbl = item_font.render(f"x{count}", True, COLOR_UI_ACCENT)
                win_surf.blit(cnt_lbl, (150, item_y + 7))

                # 액션 버튼 ([먹기] 또는 [설치])
                act_btn_w = 48
                act_btn_h = 24
                act_x = slot_w - act_btn_w + 10
                act_y = item_y + 4
                screen_btn_rect = pygame.Rect(self.x + act_x, self.y + act_y, act_btn_w, act_btn_h)

                if item_id in ("berry", "coconut"):
                    pygame.draw.rect(win_surf, (45, 130, 70), (act_x, act_y, act_btn_w, act_btn_h), border_radius=3)
                    pygame.draw.rect(win_surf, (80, 200, 110), (act_x, act_y, act_btn_w, act_btn_h), 1, border_radius=3)
                    act_lbl = sub_font.render("먹기", True, (255, 255, 255))
                    win_surf.blit(act_lbl, (act_x + 11, act_y + 3))
                    self.item_action_rects.append((item_id, "eat", screen_btn_rect))
                elif item_id in ("campfire", "shelter"):
                    pygame.draw.rect(win_surf, (150, 95, 40), (act_x, act_y, act_btn_w, act_btn_h), border_radius=3)
                    pygame.draw.rect(win_surf, (220, 160, 80), (act_x, act_y, act_btn_w, act_btn_h), 1, border_radius=3)
                    act_lbl = sub_font.render("설치", True, (255, 255, 255))
                    win_surf.blit(act_lbl, (act_x + 11, act_y + 3))
                    self.item_action_rects.append((item_id, "place", screen_btn_rect))

                item_y += 36

        # ==========================================
        # [오른쪽 열: 제작 레시피 목록]
        # ==========================================
        craft_title = header_font.render("제작 레시피 (Crafting)", True, (210, 220, 235))
        win_surf.blit(craft_title, (split_x + 20, 52))

        self.craft_btn_rects.clear()
        recipe_y = 82
        for recipe_id, recipe in RECIPES.items():
            can_craft, reason, ing_status = player.inventory.can_craft(recipe_id) if player else (False, "", {})

            row_w = self.width - split_x - 40
            row_h = 52
            row_bg = (32, 42, 58) if can_craft else (26, 32, 44)
            row_border = (80, 120, 160) if can_craft else (45, 55, 75)

            row_rect = pygame.Rect(split_x + 20, recipe_y, row_w, row_h)
            pygame.draw.rect(win_surf, row_bg, row_rect, border_radius=6)
            pygame.draw.rect(win_surf, row_border, row_rect, 1, border_radius=6)

            # 결과물 아이콘
            res_icon = get_item_icon(recipe["result_id"], 28)
            win_surf.blit(res_icon, (split_x + 28, recipe_y + 12))

            # 이름
            name_color = (255, 255, 255) if can_craft else (160, 170, 180)
            res_name = item_font.render(recipe["name"], True, name_color)
            win_surf.blit(res_name, (split_x + 64, recipe_y + 7))

            # 필요 재료 현황
            ing_strs = []
            for mat_id, (have, need) in ing_status.items():
                mat_name = get_item(mat_id)["name"]
                ing_strs.append(f"{mat_name} {have}/{need}")
            ing_text = " | ".join(ing_strs)
            ing_col = (130, 220, 140) if can_craft else (210, 120, 100)
            ing_lbl = sub_font.render(ing_text, True, ing_col)
            win_surf.blit(ing_lbl, (split_x + 64, recipe_y + 28))

            # 제작 버튼
            btn_w = 86
            btn_h = 32
            btn_local_x = self.width - 20 - btn_w - 10
            btn_local_y = recipe_y + 10
            btn_screen_rect = pygame.Rect(self.x + btn_local_x, self.y + btn_local_y, btn_w, btn_h)

            self.craft_btn_rects.append((recipe_id, btn_screen_rect, can_craft, reason))

            if can_craft:
                pygame.draw.rect(win_surf, (40, 140, 70), (btn_local_x, btn_local_y, btn_w, btn_h), border_radius=4)
                pygame.draw.rect(win_surf, (80, 210, 120), (btn_local_x, btn_local_y, btn_w, btn_h), 1, border_radius=4)
                btn_lbl = btn_font.render("제작하기", True, (255, 255, 255))
            else:
                pygame.draw.rect(win_surf, (42, 48, 60), (btn_local_x, btn_local_y, btn_w, btn_h), border_radius=4)
                pygame.draw.rect(win_surf, (60, 70, 85), (btn_local_x, btn_local_y, btn_w, btn_h), 1, border_radius=4)
                btn_lbl = btn_font.render("재료부족", True, (120, 130, 145))

            lbl_x = btn_local_x + (btn_w - btn_lbl.get_width()) // 2
            lbl_y = btn_local_y + (btn_h - btn_lbl.get_height()) // 2
            win_surf.blit(btn_lbl, (lbl_x, lbl_y))

            recipe_y += 56

        surface.blit(win_surf, (self.x, self.y))


def draw_interaction_prompt(surface: pygame.Surface, prompt_text: str = ""):
    """플레이어가 채집/벌목/수면 가능한 사물 가까이 갔을 때 표시되는 툴팁"""
    if not prompt_text:
        return

    render_font = get_font(15, bold=True)
    text_surf = render_font.render(prompt_text, True, (255, 255, 255))
    w = text_surf.get_width() + 24
    h = 32
    x = (SCREEN_WIDTH - w) // 2
    y = SCREEN_HEIGHT - 92

    bubble_surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(bubble_surf, (20, 30, 45, 235), (0, 0, w, h), border_radius=6)
    pygame.draw.rect(bubble_surf, COLOR_UI_ACCENT, (0, 0, w, h), 2, border_radius=6)
    bubble_surf.blit(text_surf, (12, 6))

    surface.blit(bubble_surf, (x, y))


def draw_bottom_quickbar(surface: pygame.Surface, player):
    """화면 하단 자원 현황 및 장착 도구 퀵바"""
    item_font = get_font(14)
    hint_font = get_font(13, bold=True)

    resources = [
        ("branch", "나뭇가지"),
        ("wood_log", "원목"),
        ("stone", "돌"),
        ("plant_fiber", "섬유"),
        ("berry", "베리"),
        ("coconut", "코코넛"),
    ]

    bar_w = 700
    bar_h = 44
    bar_x = (SCREEN_WIDTH - bar_w) // 2
    bar_y = SCREEN_HEIGHT - 54

    bar_surf = pygame.Surface((bar_w, bar_h), pygame.SRCALPHA)
    pygame.draw.rect(bar_surf, COLOR_UI_BG, (0, 0, bar_w, bar_h), border_radius=6)
    pygame.draw.rect(bar_surf, (60, 80, 105, 180), (0, 0, bar_w, bar_h), 1, border_radius=6)

    # 1. 6가지 자원 개수 표시
    slot_x = 12
    for item_id, label in resources:
        count = player.inventory.get_count(item_id) if player else 0
        icon = get_item_icon(item_id, 24)
        bar_surf.blit(icon, (slot_x, 10))

        count_col = (255, 255, 255) if count > 0 else (120, 130, 140)
        cnt_txt = item_font.render(str(count), True, count_col)
        bar_surf.blit(cnt_txt, (slot_x + 28, 14))

        slot_x += 74

    # 2. 구분선
    pygame.draw.line(bar_surf, (70, 90, 115), (slot_x + 8, 8), (slot_x + 8, bar_h - 8), 1)
    slot_x += 20

    # 3. 도구 상태 (돌도끼 보유 여부)
    has_axe = player.inventory.has_tool("stone_axe") if player else False
    axe_icon = get_item_icon("stone_axe", 24)
    bar_surf.blit(axe_icon, (slot_x, 10))

    axe_text = "돌도끼 보유" if has_axe else "돌도끼 없음"
    axe_col = (110, 220, 130) if has_axe else (140, 150, 160)
    axe_lbl = item_font.render(axe_text, True, axe_col)
    bar_surf.blit(axe_lbl, (slot_x + 28, 14))

    # 4. [TAB] 가방/제작 단축키 안내
    tab_hint = hint_font.render("[TAB] 가방 & 제작", True, COLOR_UI_ACCENT)
    bar_surf.blit(tab_hint, (bar_w - tab_hint.get_width() - 14, 14))

    surface.blit(bar_surf, (bar_x, bar_y))


def draw_game_over_or_tsunami(surface: pygame.Surface, player, time_system):
    """사망 또는 해일 도달 시 결과 화면 오버레이"""
    if player.survival.is_dead:
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((20, 5, 5, 210))
        surface.blit(dim, (0, 0))

        title_font = get_font(30, bold=True)
        sub_font = get_font(18)

        t1 = title_font.render("생명력을 모두 소진하여 쓰러졌습니다...", True, (240, 80, 80))
        t2 = sub_font.render("[R] 키를 눌러 다시 시작하세요", True, (230, 230, 230))
        surface.blit(t1, ((SCREEN_WIDTH - t1.get_width()) // 2, SCREEN_HEIGHT // 2 - 30))
        surface.blit(t2, ((SCREEN_WIDTH - t2.get_width()) // 2, SCREEN_HEIGHT // 2 + 15))

    elif time_system.tsunami_arrived:
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((10, 30, 60, 220))
        surface.blit(dim, (0, 0))

        title_font = get_font(30, bold=True)
        sub_font = get_font(18)

        t1 = title_font.render("5일이 지나 거대한 해일이 섬에 도달했습니다!", True, (100, 200, 255))
        t2 = sub_font.render("생존에 성공하셨습니다! [R] 키를 눌러 다시 시작", True, (240, 240, 240))
        surface.blit(t1, ((SCREEN_WIDTH - t1.get_width()) // 2, SCREEN_HEIGHT // 2 - 30))
        surface.blit(t2, ((SCREEN_WIDTH - t2.get_width()) // 2, SCREEN_HEIGHT // 2 + 15))

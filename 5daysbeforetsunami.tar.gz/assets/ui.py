'''Pixel-art HUD, inventory, crafting, and interaction UI.'''

import pygame
from typing import Optional, Tuple

from fonts import get_font
from items import RECIPES, get_item, get_item_icon
from image_assets import load_image
from settings import (
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    MAX_HEALTH,
    MAX_HUNGER,
    MAX_WARMTH,
)


PIXEL_DARK = (31, 39, 43)
PIXEL_PANEL = (67, 83, 73)
PIXEL_EDGE = (177, 157, 111)
PIXEL_LIGHT = (232, 220, 179)
PIXEL_TEXT = (250, 245, 220)
HOTBAR_SLOTS = 8
HOTBAR_SLOT_SIZE = 48
HOTBAR_GAP = 4
HOTBAR_WIDTH = HOTBAR_SLOTS * HOTBAR_SLOT_SIZE + (HOTBAR_SLOTS - 1) * HOTBAR_GAP
HOTBAR_X = (SCREEN_WIDTH - HOTBAR_WIDTH) // 2
HOTBAR_Y = SCREEN_HEIGHT - HOTBAR_SLOT_SIZE - 12


class NotificationManager:
    '''Small pixel-style transient messages.'''

    def __init__(self):
        self.notifications = []

    def add(self, text: str, color=(255, 255, 255), duration: float = 3.0):
        if len(self.notifications) >= 4:
            self.notifications.pop(0)
        self.notifications.append({"text": text, "color": color, "time": duration, "max_time": duration})

    def update(self, dt: float):
        for notification in self.notifications:
            notification["time"] -= dt
        self.notifications = [n for n in self.notifications if n["time"] > 0]

    def draw(self, surface: pygame.Surface):
        font = get_font(14, bold=True)
        for index, notification in enumerate(self.notifications):
            text = font.render(notification["text"], True, notification["color"])
            rect = pygame.Rect((SCREEN_WIDTH - text.get_width() - 20) // 2, 88 + index * 32, text.get_width() + 20, 28)
            pygame.draw.rect(surface, PIXEL_DARK, rect)
            pygame.draw.rect(surface, PIXEL_EDGE, rect, 2)
            surface.blit(text, (rect.x + 10, rect.y + 5))


def _draw_panel(surface: pygame.Surface, rect: pygame.Rect):
    pygame.draw.rect(surface, PIXEL_DARK, rect)
    pygame.draw.rect(surface, PIXEL_PANEL, rect.inflate(-4, -4))
    pygame.draw.rect(surface, PIXEL_EDGE, rect, 3)
    pygame.draw.line(surface, (215, 198, 145), rect.topleft, (rect.right - 1, rect.top), 1)


def draw_survival_bars(surface: pygame.Surface, player):
    '''Stack health, hunger, and warmth meters at the upper-left corner.'''
    stats = (
        ("체력", player.survival.health, MAX_HEALTH, (193, 72, 64)),
        ("배고픔", player.survival.hunger, MAX_HUNGER, (204, 139, 55)),
        ("체온", player.survival.warmth, MAX_WARMTH, (83, 153, 183)),
    )
    label_font = get_font(13, bold=True)
    value_font = get_font(11, bold=True)
    panel = pygame.Rect(12, 12, 184, 112)
    _draw_panel(surface, panel)

    for index, (label, value, maximum, color) in enumerate(stats):
        y = panel.y + 12 + index * 31
        surface.blit(label_font.render(label, True, PIXEL_TEXT), (panel.x + 10, y))
        bar = pygame.Rect(panel.x + 62, y + 1, 84, 13)
        pygame.draw.rect(surface, (30, 34, 34), bar)
        ratio = max(0.0, min(1.0, value / maximum))
        fill_width = int((bar.width - 4) * ratio)
        if fill_width:
            pygame.draw.rect(surface, color, (bar.x + 2, bar.y + 2, fill_width, bar.height - 4))
            pygame.draw.line(surface, tuple(min(255, c + 55) for c in color), (bar.x + 2, bar.y + 2), (bar.x + fill_width + 1, bar.y + 2), 1)
        pygame.draw.rect(surface, PIXEL_EDGE, bar, 1)
        value_text = value_font.render(str(int(value)), True, PIXEL_TEXT)
        surface.blit(value_text, (panel.x + 151, y + 1))


def draw_time_hud(surface: pygame.Surface, time_system):
    '''Show current day and day/night phase in the upper-right corner.'''
    panel = pygame.Rect(SCREEN_WIDTH - 164, 12, 152, 62)
    _draw_panel(surface, panel)
    title_font = get_font(16, bold=True)
    sub_font = get_font(12)
    phase = "밤" if time_system.is_night else "낮"
    phase_color = (177, 196, 241) if time_system.is_night else (255, 218, 112)
    surface.blit(title_font.render(f"{time_system.current_day}일 차", True, PIXEL_TEXT), (panel.x + 12, panel.y + 8))
    surface.blit(title_font.render(phase, True, phase_color), (panel.right - 38, panel.y + 8))
    remaining = max(0, int(time_system.remaining_phase_time))
    surface.blit(sub_font.render(f"남은 시간  {remaining // 60:02d}:{remaining % 60:02d}", True, PIXEL_LIGHT), (panel.x + 12, panel.y + 35))


class CraftingUI:
    '''Separate eight-slot inventory and recipe windows with draggable stacks.'''

    def __init__(self):
        self.is_open = False
        self.mode = "inventory"
        self.width = 720
        self.height = 390
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2
        self.selected_slot = 0
        self.hotbar_rects = []
        self.inventory_slot_rects = []
        self.craft_btn_rects = []
        self.drag_item_id = None
        self.drag_origin = None
        self.inventory_scroll = 0
        self.recipe_scroll = 0
        self.close_btn_rect = pygame.Rect(self.x + self.width - 34, self.y + 10, 24, 24)

    @property
    def selected_item_id(self):
        order = self._current_order()
        if 0 <= self.selected_slot < min(HOTBAR_SLOTS, len(order)):
            return order[self.selected_slot]
        return None

    def _current_order(self):
        return self._inventory.item_order if hasattr(self, "_inventory") else []

    def _toggle(self, mode: str):
        if self.is_open and self.mode == mode:
            self.is_open = False
        else:
            self.is_open = True
            self.mode = mode

    def _eat_item(self, item_id: str, player, notifications: NotificationManager) -> bool:
        if item_id not in ("berry", "coconut") or not player.inventory.has_item(item_id):
            return False
        success, _, message = player.survival.eat(item_id)
        if success:
            player.inventory.remove_item(item_id, 1)
            notifications.add(message, color=(150, 230, 150))
        else:
            notifications.add(message, color=(245, 170, 110))
        return True

    def _place_item(
        self,
        item_id: str,
        player,
        world,
        notifications: NotificationManager,
        position: Optional[Tuple[float, float]] = None,
    ) -> bool:
        if item_id not in ("campfire", "shelter") or not player.inventory.has_item(item_id):
            return False
        if position is None:
            px = player.x + (36 if player.facing == "right" else -36 if player.facing == "left" else 0)
            py = player.y + (36 if player.facing == "down" else -36 if player.facing == "up" else 0)
        else:
            px, py = position
        if item_id == "campfire":
            world.add_campfire(int(px), int(py))
            message = "모닥불을 설치했습니다."
        else:
            world.add_shelter(int(px), int(py))
            message = "간이 거처를 설치했습니다."
        player.inventory.remove_item(item_id, 1)
        notifications.add(message, color=(220, 200, 125))
        return True

    def handle_event(
        self,
        event: pygame.event.Event,
        player,
        world,
        notifications: NotificationManager,
        placement_position: Optional[Tuple[float, float]] = None,
    ) -> bool:
        self._inventory = player.inventory
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                self._toggle("inventory")
                return True
            if event.key == pygame.K_TAB:
                self._toggle("crafting")
                return True
            if event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True
            if pygame.K_1 <= event.key <= pygame.K_8:
                self.selected_slot = event.key - pygame.K_1
                return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
            selected_item = self.selected_item_id
            if selected_item in ("berry", "coconut"):
                return self._eat_item(selected_item, player, notifications)
            if selected_item in ("campfire", "shelter"):
                return self._place_item(
                    selected_item,
                    player,
                    world,
                    notifications,
                    placement_position,
                )

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for index, rect in enumerate(self.hotbar_rects):
                if rect.collidepoint(event.pos):
                    self.selected_slot = index
                    order = player.inventory.item_order
                    self.drag_item_id = order[index] if index < len(order) else None
                    self.drag_origin = ("hotbar", index)
                    return True

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEWHEEL:
            if self.mode == "inventory":
                self.inventory_scroll = max(0, self.inventory_scroll - event.y)
            else:
                self.recipe_scroll = max(0, self.recipe_scroll - event.y)
            return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.close_btn_rect.collidepoint(event.pos):
                self.is_open = False
                return True

            inventory_tab = pygame.Rect(self.x + 20, self.y + 50, 100, 30)
            crafting_tab = pygame.Rect(self.x + 126, self.y + 50, 100, 30)
            if inventory_tab.collidepoint(event.pos):
                self.is_open = True
                self.mode = "inventory"
                return True
            if crafting_tab.collidepoint(event.pos):
                self.is_open = True
                self.mode = "crafting"
                return True

            if self.mode == "inventory":
                for index, rect in self.inventory_slot_rects:
                    if rect.collidepoint(event.pos):
                        order = player.inventory.item_order
                        self.drag_item_id = order[index] if index < len(order) else None
                        self.drag_origin = ("inventory", index)
                        if index < HOTBAR_SLOTS:
                            self.selected_slot = index
                        return True
            else:
                for recipe_id, rect, can_craft, reason in self.craft_btn_rects:
                    if rect.collidepoint(event.pos):
                        if can_craft:
                            success, message = player.inventory.craft(recipe_id)
                            if success:
                                notifications.add(message, color=(150, 230, 150))
                        else:
                            notifications.add(reason, color=(245, 170, 110))
                        return True

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.drag_item_id is not None:
                for index, rect in enumerate(self.hotbar_rects):
                    if rect.collidepoint(event.pos):
                        player.inventory.move_item(self.drag_item_id, target_index=index)
                        self.drag_item_id = None
                        self.drag_origin = None
                        return True
                for index, rect in self.inventory_slot_rects:
                    if rect.collidepoint(event.pos):
                        player.inventory.move_item(self.drag_item_id, target_index=index)
                        self.drag_item_id = None
                        self.drag_origin = None
                        return True
            self.drag_item_id = None
            self.drag_origin = None

        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            return pygame.Rect(self.x, self.y, self.width, self.height).collidepoint(event.pos)
        return True

    def draw(self, surface: pygame.Surface, player):
        if not self.is_open:
            return
        self._inventory = player.inventory
        veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        veil.fill((9, 15, 17, 175))
        surface.blit(veil, (0, 0))

        panel = pygame.Rect(self.x, self.y, self.width, self.height)
        _draw_panel(surface, panel)
        title_font = get_font(20, bold=True)
        text_font = get_font(14, bold=True)
        small_font = get_font(12)
        title = "가방" if self.mode == "inventory" else "제작"
        surface.blit(title_font.render(title, True, PIXEL_TEXT), (self.x + 20, self.y + 14))
        pygame.draw.rect(surface, (119, 65, 53), self.close_btn_rect)
        pygame.draw.rect(surface, PIXEL_EDGE, self.close_btn_rect, 2)
        surface.blit(text_font.render("X", True, PIXEL_TEXT), (self.close_btn_rect.x + 7, self.close_btn_rect.y + 3))

        tab_y = self.y + 50
        for label, mode, x in (("가방 [E]", "inventory", self.x + 20), ("제작 [TAB]", "crafting", self.x + 126)):
            rect = pygame.Rect(x, tab_y, 100, 30)
            fill = (105, 117, 82) if mode == self.mode else (45, 54, 49)
            pygame.draw.rect(surface, fill, rect)
            pygame.draw.rect(surface, PIXEL_EDGE if mode == self.mode else (93, 99, 83), rect, 2)
            surface.blit(small_font.render(label, True, PIXEL_TEXT), (rect.x + 8, rect.y + 8))

        if self.mode == "inventory":
            self._draw_inventory(surface, player, small_font)
        else:
            self._draw_recipes(surface, player, text_font, small_font)

    def _draw_inventory(self, surface: pygame.Surface, player, small_font):
        surface.blit(small_font.render("아이템을 드래그하여 순서를 바꾸세요.", True, PIXEL_LIGHT), (self.x + 22, self.y + 91))
        order = player.inventory.item_order
        columns = 8
        slot = 58
        gap = 8
        row_gap = 22
        start_x = self.x + 24
        start_y = self.y + 112
        self.inventory_slot_rects.clear()
        visible_rows = 3
        visible_slots = columns * visible_rows

        for index in range(visible_slots):
            row = index // columns
            visible_row = row - self.inventory_scroll
            if not 0 <= visible_row < visible_rows:
                continue
            column = index % columns
            rect = pygame.Rect(
                start_x + column * (slot + gap),
                start_y + visible_row * (slot + row_gap),
                slot,
                slot,
            )
            self.inventory_slot_rects.append((index, rect))
            pygame.draw.rect(surface, (34, 42, 38), rect)
            pygame.draw.rect(surface, PIXEL_EDGE, rect, 2)
            if index >= len(order):
                continue
            item_id = order[index]
            if item_id is None:
                continue
            icon = get_item_icon(item_id, 38)
            surface.blit(icon, (rect.centerx - icon.get_width() // 2, rect.y + 4))
            count = player.inventory.get_count(item_id)
            number = small_font.render(str(count), True, (255, 255, 255))
            surface.blit(number, (rect.right - number.get_width() - 4, rect.bottom - number.get_height() - 2))
            name = get_item(item_id)["name"]
            label = small_font.render(name[:7], True, PIXEL_TEXT)
            label_rect = pygame.Rect(rect.x - 7, rect.bottom + 3, rect.width + 14, small_font.get_linesize())
            previous_clip = surface.get_clip()
            surface.set_clip(label_rect.clip(previous_clip))
            surface.blit(label, (rect.centerx - label.get_width() // 2, label_rect.y))
            surface.set_clip(previous_clip)

        selected = self.selected_item_id
        hint = "우클릭: 베리/코코넛 먹기" if selected in ("berry", "coconut") else "아이템을 드래그하여 순서를 바꾸세요."
        if selected in ("campfire", "shelter"):
            hint = "우클릭: 설치"
        if selected in ("base_raft", "sail"):
            hint = "선택한 뒤 해안의 뗏목 설치 장소를 좌클릭하세요."
        surface.blit(small_font.render(hint, True, PIXEL_LIGHT), (self.x + 22, self.y + self.height - 34))

    def _draw_recipes(self, surface: pygame.Surface, player, text_font, small_font):
        recipes = list(RECIPES.items())
        self.craft_btn_rects.clear()
        row_count = (len(recipes) + 1) // 2
        max_scroll = max(0, row_count - 4)
        self.recipe_scroll = max(0, min(self.recipe_scroll, max_scroll))
        for index, (recipe_id, recipe) in enumerate(recipes):
            row = index // 2 - self.recipe_scroll
            if row < 0 or row >= 4:
                continue
            x = self.x + 22 + (index % 2) * 338
            y = self.y + 100 + row * 68
            card = pygame.Rect(x, y, 324, 64)
            can_craft, reason, ingredients = player.inventory.can_craft(recipe_id)
            pygame.draw.rect(surface, (43, 52, 46) if can_craft else (36, 42, 39), card)
            pygame.draw.rect(surface, PIXEL_EDGE if can_craft else (91, 94, 79), card, 2)
            icon = get_item_icon(recipe["result_id"], 52)
            surface.blit(icon, (card.x + 6, card.y + 6))
            name = text_font.render(recipe["name"], True, PIXEL_TEXT)
            surface.blit(name, (card.x + 64, card.y + 8))
            for material_index, (item_id, (have, need)) in enumerate(ingredients.items()):
                color = (177, 224, 144) if have >= need else (221, 143, 118)
                material = get_font(10, bold=True).render(
                    f"{get_item(item_id)['name']} {have}/{need}",
                    True,
                    color,
                )
                column = material_index % 2
                material_rect = pygame.Rect(
                    card.x + 64 + column * 91,
                    card.y + 32 + (material_index // 2) * 14,
                    88,
                    13,
                )
                previous_clip = surface.get_clip()
                surface.set_clip(material_rect.clip(previous_clip))
                surface.blit(material, material_rect.topleft)
                surface.set_clip(previous_clip)

            button = pygame.Rect(card.right - 78, card.y + 8, 68, 22)
            pygame.draw.rect(surface, (93, 129, 72) if can_craft else (64, 67, 59), button)
            pygame.draw.rect(surface, PIXEL_EDGE, button, 1)
            button_text = small_font.render("제작", True, PIXEL_TEXT)
            surface.blit(button_text, (button.centerx - button_text.get_width() // 2, button.y + 4))
            self.craft_btn_rects.append((recipe_id, button, can_craft, reason))


def draw_interaction_prompt(surface: pygame.Surface, prompt_text: str = ""):
    if not prompt_text:
        return
    font = get_font(15, bold=True)
    text = font.render(prompt_text, True, PIXEL_TEXT)
    rect = pygame.Rect((SCREEN_WIDTH - text.get_width() - 28) // 2, SCREEN_HEIGHT - 102, text.get_width() + 28, 34)
    _draw_panel(surface, rect)
    surface.blit(text, (rect.x + 14, rect.y + 9))


def draw_bottom_quickbar(surface: pygame.Surface, player, inventory_ui: Optional[CraftingUI] = None):
    '''Eight centered hotbar slots with item counts and keyboard selectors.'''
    font = get_font(11, bold=True)
    order = player.inventory.item_order
    selected = inventory_ui.selected_slot if inventory_ui else 0
    rects = []
    for index in range(HOTBAR_SLOTS):
        rect = pygame.Rect(HOTBAR_X + index * (HOTBAR_SLOT_SIZE + HOTBAR_GAP), HOTBAR_Y, HOTBAR_SLOT_SIZE, HOTBAR_SLOT_SIZE)
        rects.append(rect)
        pygame.draw.rect(surface, (32, 38, 35), rect)
        pygame.draw.rect(surface, (240, 205, 103) if index == selected else PIXEL_EDGE, rect, 3 if index == selected else 2)
        key_text = font.render(str(index + 1), True, (218, 211, 182))
        surface.blit(key_text, (rect.x + 4, rect.y + 2))
        if index < len(order):
            item_id = order[index]
            if item_id is None:
                continue
            icon = get_item_icon(item_id, 34)
            surface.blit(icon, (rect.x + 8, rect.y + 8))
            count = font.render(str(player.inventory.get_count(item_id)), True, (255, 255, 255))
            surface.blit(count, (rect.right - count.get_width() - 3, rect.bottom - count.get_height() - 2))
    if inventory_ui is not None:
        inventory_ui.hotbar_rects = rects
        selected_item = inventory_ui.selected_item_id
        if selected_item in ("berry", "coconut") and player.inventory.has_item(selected_item):
            hint_text = "우클릭으로 먹기"
        elif selected_item == "stone_axe" and player.inventory.has_item(selected_item):
            hint_text = "좌클릭으로 나무 벌목"
        elif selected_item in ("campfire", "shelter") and player.inventory.has_item(selected_item):
            hint_text = "우클릭으로 설치"
        else:
            hint_text = None
        if hint_text:
            hint_font = get_font(13, bold=True)
            hint = hint_font.render(hint_text, True, PIXEL_TEXT)
            hint_rect = pygame.Rect(
                HOTBAR_X + HOTBAR_WIDTH + 12,
                HOTBAR_Y + (HOTBAR_SLOT_SIZE - 24) // 2,
                hint.get_width() + 24,
                24,
            )
            _draw_panel(surface, hint_rect)
            surface.blit(hint, (hint_rect.centerx - hint.get_width() // 2, hint_rect.y + 4))


class TitleScreen:
    '''Title screen using the game's cover artwork.'''

    def __init__(self):
        image = load_image("title.png")
        self.background = pygame.transform.smoothscale(image, (SCREEN_WIDTH, SCREEN_HEIGHT))
        self.is_open = True
        self.buttons = {}

    def handle_event(self, event: pygame.event.Event) -> Optional[str]:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                return "start"
            if event.key in (pygame.K_ESCAPE, pygame.K_q):
                return "quit"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for action, rect in self.buttons.items():
                if rect.collidepoint(event.pos):
                    return action
        return None

    def draw(self, surface: pygame.Surface):
        surface.blit(self.background, (0, 0))
        panel = pygame.Surface((SCREEN_WIDTH, 180), pygame.SRCALPHA)
        panel.fill((18, 30, 34, 185))
        surface.blit(panel, (0, SCREEN_HEIGHT - panel.get_height()))

        subtitle_font = get_font(17, bold=True)
        hint_font = get_font(13)
        subtitle = subtitle_font.render("무인도에서 살아남아 해일을 피해 탈출하세요", True, PIXEL_TEXT)
        surface.blit(subtitle, (SCREEN_WIDTH // 2 - subtitle.get_width() // 2, SCREEN_HEIGHT - 164))

        self.buttons = {
            "start": pygame.Rect(SCREEN_WIDTH // 2 - 120, SCREEN_HEIGHT - 126, 240, 52),
            "quit": pygame.Rect(SCREEN_WIDTH // 2 - 120, SCREEN_HEIGHT - 65, 240, 36),
        }
        mouse_pos = pygame.mouse.get_pos()
        for action, label in (("start", "게임 시작"), ("quit", "종료하기")):
            rect = self.buttons[action]
            hovered = rect.collidepoint(mouse_pos)
            fill = (105, 127, 79) if hovered else (78, 91, 67)
            pygame.draw.rect(surface, PIXEL_DARK, rect.inflate(4, 4))
            pygame.draw.rect(surface, fill, rect)
            pygame.draw.rect(surface, PIXEL_EDGE, rect, 3 if hovered else 2)
            font = get_font(19 if action == "start" else 15, bold=True)
            text = font.render(label, True, PIXEL_TEXT)
            surface.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

        hint = hint_font.render("ENTER: 시작   |   ESC: 종료", True, PIXEL_TEXT)
        surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT - 5 - hint.get_height()))


class OpeningSequence:
    '''Pauses the game while the survivor regains consciousness on the beach.'''

    DIALOGUE = (
        ("표류자", "으윽... 여긴 어디지? 배가 침몰한 건가..."),
        ("표류자", "거센 파도에 휩쓸려 무인도까지 떠밀려온 모양이야."),
        ("표류자", "저기 놓인 건 탐험가의 일지인가? 몸을 추스르고 읽어봐야겠어."),
    )

    def __init__(self):
        self.is_active = False
        self.current_line = 0

    def start(self, player):
        self.current_line = 0
        self.is_active = True
        player.is_lying_down = True

    def handle_event(self, event: pygame.event.Event, player) -> bool:
        if not self.is_active:
            return False
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
            self._advance(player)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._advance(player)
        return True

    def _advance(self, player):
        if self.current_line + 1 < len(self.DIALOGUE):
            self.current_line += 1
            return
        self.is_active = False
        player.is_lying_down = False

    def draw(self, surface: pygame.Surface):
        if not self.is_active:
            return

        speaker, dialogue = self.DIALOGUE[self.current_line]
        panel = pygame.Rect(62, SCREEN_HEIGHT - 178, SCREEN_WIDTH - 124, 150)
        _draw_panel(surface, panel)

        speaker_font = get_font(15, bold=True)
        dialogue_font = get_font(20, bold=True)
        hint_font = get_font(12)
        surface.blit(speaker_font.render(speaker, True, (238, 195, 106)), (panel.x + 24, panel.y + 18))
        surface.blit(dialogue_font.render(dialogue, True, PIXEL_TEXT), (panel.x + 24, panel.y + 53))
        hint = "클릭 또는 Enter/Space: 다음"
        if self.current_line == len(self.DIALOGUE) - 1:
            hint = "클릭 또는 Enter/Space: 일어나기"
        hint_surface = hint_font.render(
            f"{self.current_line + 1}/{len(self.DIALOGUE)}   {hint}",
            True,
            (205, 198, 164),
        )
        surface.blit(hint_surface, (panel.right - hint_surface.get_width() - 22, panel.bottom - 25))


class PauseMenu:
    '''Pause overlay with mouse buttons and keyboard shortcuts.'''

    def __init__(self):
        self.is_open = False
        self.buttons = {}

    def handle_event(self, event: pygame.event.Event) -> Optional[str]:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_c):
                return "continue"
            if event.key == pygame.K_r:
                return "title"
            if event.key == pygame.K_q:
                return "quit"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for action, rect in self.buttons.items():
                if rect.collidepoint(event.pos):
                    return action
        return None

    def draw(self, surface: pygame.Surface):
        if not self.is_open:
            return
        veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 13, 16, 190))
        surface.blit(veil, (0, 0))
        panel = pygame.Rect(SCREEN_WIDTH // 2 - 190, SCREEN_HEIGHT // 2 - 154, 380, 308)
        _draw_panel(surface, panel)
        title_font = get_font(26, bold=True)
        label_font = get_font(16, bold=True)
        title = title_font.render("일시 정지", True, PIXEL_TEXT)
        surface.blit(title, (panel.centerx - title.get_width() // 2, panel.y + 30))
        self.buttons = {}
        for index, (action, label, shortcut) in enumerate((
            ("continue", "계속하기", "ESC / C"),
            ("title", "타이틀 화면으로", "R"),
            ("quit", "종료하기", "Q"),
        )):
            rect = pygame.Rect(panel.x + 54, panel.y + 88 + index * 62, panel.width - 108, 48)
            self.buttons[action] = rect
            pygame.draw.rect(surface, (78, 91, 67), rect)
            pygame.draw.rect(surface, PIXEL_EDGE, rect, 2)
            text = label_font.render(f"{label}  [{shortcut}]", True, PIXEL_TEXT)
            surface.blit(text, (rect.centerx - text.get_width() // 2, rect.y + 13))


def draw_game_over_or_tsunami(surface: pygame.Surface, player, time_system):
    if not player.survival.is_dead and not time_system.tsunami_arrived:
        return
    veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    veil.fill((20, 8, 8, 210) if player.survival.is_dead else (10, 30, 60, 220))
    surface.blit(veil, (0, 0))
    title_font = get_font(30, bold=True)
    sub_font = get_font(18)
    title = "생명력을 모두 소진하여 쓰러졌습니다..." if player.survival.is_dead else "3일이 지나 거대한 해일이 섬에 도달했습니다!"
    subtitle = "Enter / R 키 또는 클릭: 타이틀 화면으로"
    title_surface = title_font.render(title, True, (240, 100, 90) if player.survival.is_dead else (100, 200, 255))
    sub_surface = sub_font.render(subtitle, True, PIXEL_TEXT)
    surface.blit(title_surface, ((SCREEN_WIDTH - title_surface.get_width()) // 2, SCREEN_HEIGHT // 2 - 30))
    surface.blit(sub_surface, ((SCREEN_WIDTH - sub_surface.get_width()) // 2, SCREEN_HEIGHT // 2 + 15))

'''Pixel-art HUD, inventory, crafting, and interaction UI.'''

from functools import lru_cache
import pygame
from typing import Optional, Tuple

from fonts import get_font
from items import RECIPES, get_item, get_item_icon
from image_assets import load_image
from settings import (
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    MAX_HEALTH,
    MAX_HUNGER,
    MAX_WARMTH,
    COLOR_UI_DARK,
    COLOR_UI_PANEL,
    COLOR_UI_EDGE,
    COLOR_UI_LIGHT,
    COLOR_UI_TEXT,
)


PIXEL_DARK = COLOR_UI_DARK
PIXEL_PANEL = COLOR_UI_PANEL
PIXEL_EDGE = COLOR_UI_EDGE
PIXEL_LIGHT = COLOR_UI_LIGHT
PIXEL_TEXT = COLOR_UI_TEXT
WARMTH_GAUGE_MIN = 15.0
WINDOW_PAPER = (192, 162, 129)
WINDOW_CONTENT = (176, 142, 111)
WINDOW_GREEN = (78, 111, 66)
WINDOW_RED = (139, 70, 63)
HOTBAR_SLOTS = 8
HOTBAR_SCALE = 1.5
HOTBAR_WIDTH = round(338 * HOTBAR_SCALE)
HOTBAR_HEIGHT = round(67 * HOTBAR_SCALE)
HOTBAR_SLOT_SIZE = round(30 * HOTBAR_SCALE)
HOTBAR_X = (SCREEN_WIDTH - HOTBAR_WIDTH) // 2
HOTBAR_Y = SCREEN_HEIGHT - HOTBAR_HEIGHT - 6

STOP_BUTTON_POS = (12, 12)
STOP_BUTTON_SCALE = 2


@lru_cache(maxsize=None)
def _load_ui_surface(
    filename: str,
    scale: float = 1.0,
    crop_bbox: bool = False,
) -> pygame.Surface:
    surface = load_image(f"ui/{filename}")
    if crop_bbox:
        bbox = surface.get_bounding_rect()
        if bbox.width > 0 and bbox.height > 0:
            surface = surface.subsurface(bbox).copy()
    if scale != 1.0:
        new_size = (
            max(1, round(surface.get_width() * scale)),
            max(1, round(surface.get_height() * scale)),
        )
        surface = pygame.transform.scale(surface, new_size)
    return surface


def get_stop_button_rect() -> pygame.Rect:
    btn = _load_ui_surface("StopButton.png", scale=STOP_BUTTON_SCALE, crop_bbox=True)
    return pygame.Rect(STOP_BUTTON_POS[0], STOP_BUTTON_POS[1], btn.get_width(), btn.get_height())


def draw_stop_button(surface: pygame.Surface) -> pygame.Rect:
    '''Draw the top-left pause/stop button using StopButton.png.'''
    btn = _load_ui_surface("StopButton.png", scale=STOP_BUTTON_SCALE, crop_bbox=True)
    rect = pygame.Rect(STOP_BUTTON_POS[0], STOP_BUTTON_POS[1], btn.get_width(), btn.get_height())
    surface.blit(btn, rect.topleft)
    if rect.collidepoint(pygame.mouse.get_pos()):
        hover = pygame.Surface(rect.size, pygame.SRCALPHA)
        hover.fill((255, 255, 255, 32))
        surface.blit(hover, rect.topleft)
    return rect


class NotificationManager:
    '''Small pixel-style transient messages.'''

    def __init__(self):
        self.notifications = []

    def add(self, text: str, color=PIXEL_TEXT, duration: float = 3.0):
        if len(self.notifications) >= 4:
            self.notifications.pop(0)
        self.notifications.append({"text": text, "color": color, "time": duration, "max_time": duration})

    def update(self, dt: float):
        for notification in self.notifications:
            notification["time"] -= dt
        self.notifications = [n for n in self.notifications if n["time"] > 0]

    def draw(self, surface: pygame.Surface):
        font = get_font(14, bold=True)
        for index, notification in enumerate(self.notifications):
            text = font.render(notification["text"], True, notification["color"])
            rect = pygame.Rect(
                (SCREEN_WIDTH - text.get_width() - 32) // 2,
                86 + index * 36,
                text.get_width() + 32,
                32,
            )
            _draw_panel(surface, rect)
            surface.blit(text, (rect.x + 16, rect.y + 8))


def _draw_panel(surface: pygame.Surface, rect: pygame.Rect):
    pygame.draw.rect(surface, PIXEL_DARK, rect)
    pygame.draw.rect(surface, PIXEL_PANEL, rect.inflate(-4, -4))
    pygame.draw.rect(surface, PIXEL_EDGE, rect, 3)
    pygame.draw.line(surface, (215, 198, 145), rect.topleft, (rect.right - 1, rect.top), 1)


def _make_nine_slice(image: pygame.Surface, size: Tuple[int, int]) -> pygame.Surface:
    source_border = 5
    target_border = 14
    source_width, source_height = image.get_size()
    target_width, target_height = size
    source_x = (0, source_border, source_width - source_border, source_width)
    source_y = (0, source_border, source_height - source_border, source_height)
    target_x = (0, target_border, target_width - target_border, target_width)
    target_y = (0, target_border, target_height - target_border, target_height)
    result = pygame.Surface(size, pygame.SRCALPHA)

    for row in range(3):
        for column in range(3):
            source_rect = pygame.Rect(
                source_x[column],
                source_y[row],
                source_x[column + 1] - source_x[column],
                source_y[row + 1] - source_y[row],
            )
            target_rect = pygame.Rect(
                target_x[column],
                target_y[row],
                target_x[column + 1] - target_x[column],
                target_y[row + 1] - target_y[row],
            )
            patch = image.subsurface(source_rect)
            if patch.get_size() != target_rect.size:
                patch = pygame.transform.scale(patch, target_rect.size)
            result.blit(patch, target_rect)

    return result


def _blit_outlined_text(
    surface: pygame.Surface,
    text: str,
    font: pygame.font.Font,
    color: tuple,
    position: tuple[int, int],
):
    outline = font.render(text, True, (49, 31, 31))
    for offset in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        surface.blit(outline, (position[0] + offset[0], position[1] + offset[1]))
    surface.blit(font.render(text, True, color), position)


def draw_survival_bars(surface: pygame.Surface, player):
    '''Draw health, hunger, and warmth meters at the center of the left edge.'''
    gauge_scale = 1.35
    gauge_surf = _load_ui_surface("Gauge.png", scale=gauge_scale)
    gauge_x = 12 - round(3 * gauge_scale)
    gauge_y = (SCREEN_HEIGHT - gauge_surf.get_height()) // 2
    surface.blit(gauge_surf, (gauge_x, gauge_y))

    stats = (
        ("Hp.png", player.survival.health, MAX_HEALTH, 10, "체력", "", 0.0),
        ("Hunger.png", player.survival.hunger, MAX_HUNGER, 37, "허기", "", 0.0),
        (
            "Temperature.png",
            player.survival.warmth,
            MAX_WARMTH,
            64,
            "체온",
            " °C",
            WARMTH_GAUGE_MIN,
        ),
    )
    bar_x = gauge_x + round(37 * gauge_scale)
    mouse_pos = pygame.mouse.get_pos()
    hovered_text = None
    for filename, value, maximum, raw_y, label, unit, gauge_minimum in stats:
        fill_surf = _load_ui_surface(filename, scale=gauge_scale, crop_bbox=True)
        ratio = max(0.0, min(1.0, (value - gauge_minimum) / (maximum - gauge_minimum)))
        fill_width = round(fill_surf.get_width() * ratio)
        row_y = gauge_y + round(raw_y * gauge_scale)
        if fill_width > 0:
            surface.blit(
                fill_surf,
                (bar_x, row_y),
                pygame.Rect(0, 0, fill_width, fill_surf.get_height()),
            )
        hit_rect = pygame.Rect(
            gauge_x,
            row_y,
            gauge_surf.get_width(),
            round(26 * gauge_scale),
        )
        if hit_rect.collidepoint(mouse_pos):
            hovered_text = f"{label}: {value:.1f} / {maximum:.1f}{unit}"

    if hovered_text:
        tooltip_font = get_font(12, bold=True)
        text = tooltip_font.render(hovered_text, True, PIXEL_TEXT)
        tooltip_rect = pygame.Rect(
            mouse_pos[0] + 16,
            mouse_pos[1] + 14,
            text.get_width() + 16,
            text.get_height() + 10,
        )
        if tooltip_rect.right > SCREEN_WIDTH:
            tooltip_rect.x = mouse_pos[0] - tooltip_rect.width - 12
        if tooltip_rect.bottom > SCREEN_HEIGHT:
            tooltip_rect.y = mouse_pos[1] - tooltip_rect.height - 12
        tooltip_rect.clamp_ip(pygame.Rect(4, 4, SCREEN_WIDTH - 8, SCREEN_HEIGHT - 8))
        _draw_panel(surface, tooltip_rect)
        surface.blit(text, (tooltip_rect.x + 8, tooltip_rect.y + 5))


def draw_time_hud(surface: pygame.Surface, time_system):
    '''Show current day, sun/moon icon, and remaining time in the upper-right corner.'''
    time_scale = 1.5
    time_surf = _load_ui_surface("Time.png", scale=time_scale)
    panel_x = SCREEN_WIDTH - time_surf.get_width() - 12
    panel_y = 12
    surface.blit(time_surf, (panel_x, panel_y))

    inner_x = panel_x + round(24 * time_scale)
    inner_y = panel_y + round(21 * time_scale)
    inner_w = round(83 * time_scale)
    inner_h = round(41 * time_scale)
    inner_cx = inner_x + inner_w // 2

    day_font = get_font(16, bold=True)
    time_font = get_font(12, bold=True)
    day_surf = day_font.render(f"{time_system.current_day}일 차", True, PIXEL_TEXT)

    icon_name = "Moon.png" if time_system.is_night else "Sun.png"
    icon_surf = _load_ui_surface(icon_name, scale=1.0, crop_bbox=True)
    gap = 6
    top_total_w = day_surf.get_width() + gap + icon_surf.get_width()
    top_x = inner_cx - top_total_w // 2
    top_y = inner_y + 6
    surface.blit(day_surf, (top_x, top_y + max(0, (icon_surf.get_height() - day_surf.get_height()) // 2)))
    surface.blit(icon_surf, (top_x + day_surf.get_width() + gap, top_y))

    remaining = max(0, int(time_system.remaining_phase_time))
    rem_surf = time_font.render(f"남은 시간 {remaining // 60:02d}:{remaining % 60:02d}", True, PIXEL_LIGHT)
    surface.blit(rem_surf, (inner_cx - rem_surf.get_width() // 2, inner_y + inner_h - rem_surf.get_height() - 6))


class CraftingUI:
    '''Tabbed pixel-art inventory and crafting window.'''

    def __init__(self):
        self.is_open = False
        self.mode = "inventory"
        self.width = 800
        self.height = 414
        self.x = (SCREEN_WIDTH - self.width) // 2
        self.y = (SCREEN_HEIGHT - self.height) // 2 + 1
        self.selected_slot = 0
        self.inventory_selection = 0
        self.hotbar_rects = []
        self.inventory_slot_rects = []
        self.recipe_slot_rects = []
        self.craft_btn_rects = []
        self.drag_item_id = None
        self.drag_origin = None
        self.inventory_scroll = 0
        self.recipe_scroll = 0
        self.selected_recipe_id = next(iter(RECIPES), None)
        self.close_btn_rect = pygame.Rect(self.x + self.width - 42, self.y + 29, 24, 24)
        self.bottom_close_btn_rect = pygame.Rect(
            self.x + self.width - 104,
            self.y + self.height - 42,
            80,
            26,
        )

    def _tab_rects(self):
        tab_y = self.y - 34
        return {
            "inventory": pygame.Rect(self.x + 32, tab_y, 156, 58),
            "crafting": pygame.Rect(self.x + 194, tab_y, 156, 58),
        }

    def _body_rects(self):
        body_y = self.y + 76
        return (
            pygame.Rect(self.x + 22, body_y, 450, 286),
            pygame.Rect(self.x + 486, body_y, 292, 286),
        )

    @property
    def selected_item_id(self):
        order = self._current_order()
        if 0 <= self.selected_slot < min(HOTBAR_SLOTS, len(order)):
            return order[self.selected_slot]
        return None

    def _current_order(self):
        return self._inventory.item_order if hasattr(self, "_inventory") else []

    def _toggle(self, mode: str):
        if self.is_open and self.mode == mode:
            self.is_open = False
        else:
            self.is_open = True
            self.mode = mode

    def _eat_item(self, item_id: str, player, notifications: NotificationManager) -> bool:
        if item_id not in ("berry", "coconut") or not player.inventory.has_item(item_id):
            return False
        success, _, message = player.survival.eat(item_id)
        if success:
            player.inventory.remove_item(item_id, 1)
        else:
            notifications.add(message, color=(245, 170, 110))
        return True

    def _place_item(
        self,
        item_id: str,
        player,
        world,
        notifications: NotificationManager,
        position: Optional[Tuple[float, float]] = None,
    ) -> bool:
        if item_id not in ("campfire", "shelter") or not player.inventory.has_item(item_id):
            return False
        if position is None:
            px = player.x + (36 if player.facing == "right" else -36 if player.facing == "left" else 0)
            py = player.y + (36 if player.facing == "down" else -36 if player.facing == "up" else 0)
        else:
            px, py = position
        if item_id == "campfire":
            world.add_campfire(int(px), int(py))
            message = "모닥불을 설치했습니다."
        else:
            world.add_shelter(int(px), int(py))
            message = "간이 거처를 설치했습니다."
        player.inventory.remove_item(item_id, 1)
        notifications.add(message, color=(220, 200, 125))
        return True

    def handle_event(
        self,
        event: pygame.event.Event,
        player,
        world,
        notifications: NotificationManager,
        placement_position: Optional[Tuple[float, float]] = None,
    ) -> bool:
        self._inventory = player.inventory
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                self._toggle("inventory")
                return True
            if event.key == pygame.K_TAB:
                self._toggle("crafting")
                return True
            if event.key == pygame.K_ESCAPE and self.is_open:
                self.is_open = False
                return True
            if pygame.K_1 <= event.key <= pygame.K_8:
                self.selected_slot = event.key - pygame.K_1
                self.inventory_selection = self.selected_slot
                return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
            selected_item = self.selected_item_id
            if selected_item in ("berry", "coconut"):
                return self._eat_item(selected_item, player, notifications)
            if selected_item in ("campfire", "shelter"):
                return self._place_item(
                    selected_item,
                    player,
                    world,
                    notifications,
                    placement_position,
                )

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not self.is_open:
            for index, rect in enumerate(self.hotbar_rects):
                if rect.collidepoint(event.pos):
                    self.selected_slot = index
                    self.inventory_selection = index
                    order = player.inventory.item_order
                    self.drag_item_id = order[index] if index < len(order) else None
                    self.drag_origin = ("hotbar", index)
                    return True

        if event.type == pygame.MOUSEWHEEL and not self.is_open:
            if event.y != 0:
                step = -1 if event.y > 0 else 1
                self.selected_slot = (self.selected_slot + step) % HOTBAR_SLOTS
                return True
            return False

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and not self.is_open:
            if self.drag_item_id is not None:
                for index, rect in enumerate(self.hotbar_rects):
                    if rect.collidepoint(event.pos):
                        player.inventory.move_item(self.drag_item_id, target_index=index)
                        self.drag_item_id = None
                        self.drag_origin = None
                        return True
            self.drag_item_id = None
            self.drag_origin = None

        if not self.is_open:
            return False

        if event.type == pygame.MOUSEWHEEL:
            if self.mode == "inventory":
                max_scroll = max(0, (len(self._inventory.item_order) + 7) // 8 - 3)
                self.inventory_scroll = max(
                    0,
                    min(max_scroll, self.inventory_scroll - event.y),
                )
            else:
                max_scroll = max(0, (len(RECIPES) + 1) // 2 - 4)
                self.recipe_scroll = max(
                    0,
                    min(max_scroll, self.recipe_scroll - event.y),
                )
            return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.bottom_close_btn_rect.collidepoint(event.pos):
                self.is_open = False
                return True
            if self.close_btn_rect.collidepoint(event.pos):
                self.is_open = False
                return True

            tab_rects = self._tab_rects()
            if tab_rects["inventory"].collidepoint(event.pos):
                self.is_open = True
                self.mode = "inventory"
                return True
            if tab_rects["crafting"].collidepoint(event.pos):
                self.is_open = True
                self.mode = "crafting"
                return True

            if self.mode == "inventory":
                for index, rect in self.inventory_slot_rects:
                    if rect.collidepoint(event.pos):
                        order = player.inventory.item_order
                        self.inventory_selection = index
                        self.drag_item_id = order[index] if index < len(order) else None
                        self.drag_origin = ("inventory", index)
                        if index < HOTBAR_SLOTS:
                            self.selected_slot = index
                        return True
            else:
                for recipe_id, rect in self.recipe_slot_rects:
                    if rect.collidepoint(event.pos):
                        self.selected_recipe_id = recipe_id
                        return True
                for recipe_id, rect, can_craft, reason in self.craft_btn_rects:
                    if rect.collidepoint(event.pos):
                        if can_craft:
                            success, message = player.inventory.craft(recipe_id)
                            if success:
                                notifications.add(message, color=(150, 230, 150))
                        else:
                            notifications.add(reason, color=(245, 170, 110))
                        return True

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.drag_item_id is not None:
                if not self.is_open:
                    for index, rect in enumerate(self.hotbar_rects):
                        if rect.collidepoint(event.pos):
                            player.inventory.move_item(self.drag_item_id, target_index=index)
                            self.selected_slot = index
                            self.inventory_selection = index
                            self.drag_item_id = None
                            self.drag_origin = None
                            return True
                for index, rect in self.inventory_slot_rects:
                    if rect.collidepoint(event.pos):
                        player.inventory.move_item(self.drag_item_id, target_index=index)
                        self.inventory_selection = index
                        if index < HOTBAR_SLOTS:
                            self.selected_slot = index
                        self.drag_item_id = None
                        self.drag_origin = None
                        return True
            self.drag_item_id = None
            self.drag_origin = None

        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            return pygame.Rect(self.x, self.y, self.width, self.height).collidepoint(event.pos)
        return True

    def draw(self, surface: pygame.Surface, player):
        if not self.is_open:
            return
        self._inventory = player.inventory
        veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        veil.fill((9, 15, 17, 175))
        surface.blit(veil, (0, 0))

        panel = pygame.Rect(self.x, self.y, self.width, self.height)
        self._draw_window_frame(surface, panel)
        small_font = get_font(11)
        title_font = get_font(16, bold=True)
        help_font = get_font(10, bold=True)

        for mode, rect in self._tab_rects().items():
            self._draw_tab(surface, rect, mode, mode == self.mode)

        pygame.draw.rect(surface, PIXEL_DARK, self.close_btn_rect)
        pygame.draw.rect(surface, (143, 74, 64), self.close_btn_rect.inflate(-4, -4))
        pygame.draw.rect(surface, PIXEL_EDGE, self.close_btn_rect, 2)
        close_text = get_font(13, bold=True).render("X", True, PIXEL_TEXT)
        surface.blit(
            close_text,
            (self.close_btn_rect.centerx - close_text.get_width() // 2,
             self.close_btn_rect.centery - close_text.get_height() // 2),
        )

        header = "소지품 보관함" if self.mode == "inventory" else "제작 작업대"
        surface.blit(
            title_font.render(header, True, PIXEL_DARK),
            (self.x + 24, self.y + 39),
        )
        help_text = help_font.render("E 가방   TAB 제작   ESC 닫기", True, PIXEL_DARK)
        surface.blit(
            help_text,
            (self.close_btn_rect.x - help_text.get_width() - 12, self.y + 44),
        )
        pygame.draw.line(
            surface,
            PIXEL_EDGE,
            (self.x + 20, self.y + 68),
            (self.x + self.width - 20, self.y + 68),
            2,
        )

        if self.mode == "inventory":
            self._draw_inventory(surface, player)
        else:
            self._draw_recipes(surface, player, small_font)

        pygame.draw.rect(surface, PIXEL_DARK, self.bottom_close_btn_rect)
        pygame.draw.rect(
            surface,
            (125, 87, 76),
            self.bottom_close_btn_rect.inflate(-4, -4),
        )
        pygame.draw.rect(surface, PIXEL_EDGE, self.bottom_close_btn_rect, 2)
        bottom_close_text = get_font(11, bold=True).render("닫기", True, PIXEL_TEXT)
        surface.blit(
            bottom_close_text,
            (
                self.bottom_close_btn_rect.centerx - bottom_close_text.get_width() // 2,
                self.bottom_close_btn_rect.centery - bottom_close_text.get_height() // 2,
            ),
        )

    def _draw_window_frame(self, surface: pygame.Surface, rect: pygame.Rect):
        pygame.draw.rect(surface, PIXEL_DARK, rect)
        pygame.draw.rect(surface, PIXEL_EDGE, rect.inflate(-4, -4))
        pygame.draw.rect(surface, PIXEL_PANEL, rect.inflate(-10, -10))
        inner = rect.inflate(-18, -18)
        pygame.draw.rect(surface, WINDOW_PAPER, inner)
        pygame.draw.rect(surface, PIXEL_DARK, inner, 2)
        pygame.draw.line(
            surface,
            PIXEL_LIGHT,
            (inner.x + 5, inner.y + 4),
            (inner.right - 6, inner.y + 4),
            2,
        )

    def _draw_content_panel(self, surface: pygame.Surface, rect: pygame.Rect):
        pygame.draw.rect(surface, PIXEL_DARK, rect)
        pygame.draw.rect(surface, PIXEL_EDGE, rect.inflate(-3, -3))
        content = rect.inflate(-7, -7)
        pygame.draw.rect(surface, WINDOW_CONTENT, content)
        pygame.draw.rect(surface, (133, 95, 78), content, 1)

    def _draw_tab(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        mode: str,
        selected: bool,
    ):
        fill = WINDOW_PAPER if selected else PIXEL_PANEL
        pygame.draw.rect(surface, PIXEL_DARK, (rect.x + 4, rect.y, rect.width - 8, rect.height))
        pygame.draw.rect(surface, PIXEL_DARK, (rect.x, rect.y + 8, rect.width, rect.height - 8))
        pygame.draw.rect(surface, PIXEL_EDGE, (rect.x + 6, rect.y + 3, rect.width - 12, rect.height - 6))
        pygame.draw.rect(surface, PIXEL_EDGE, (rect.x + 3, rect.y + 10, rect.width - 6, rect.height - 12))
        pygame.draw.rect(surface, fill, (rect.x + 9, rect.y + 7, rect.width - 18, rect.height - 12))
        pygame.draw.rect(surface, fill, (rect.x + 6, rect.y + 13, rect.width - 12, rect.height - 15))

        icon_x, icon_y = rect.x + 14, rect.y + 16
        icon_fill = PIXEL_DARK if selected else PIXEL_LIGHT
        accent = PIXEL_EDGE if selected else PIXEL_DARK
        if mode == "inventory":
            pygame.draw.rect(surface, icon_fill, (icon_x + 3, icon_y + 7, 18, 16))
            pygame.draw.rect(surface, accent, (icon_x + 5, icon_y + 9, 14, 11))
            pygame.draw.rect(surface, icon_fill, (icon_x + 7, icon_y + 3, 10, 5))
            pygame.draw.rect(surface, WINDOW_PAPER if selected else PIXEL_PANEL, (icon_x + 10, icon_y + 5, 4, 3))
        else:
            pygame.draw.rect(surface, icon_fill, (icon_x + 10, icon_y + 9, 4, 16))
            pygame.draw.rect(surface, accent, (icon_x + 4, icon_y + 4, 16, 7))
            pygame.draw.rect(surface, icon_fill, (icon_x + 7, icon_y + 7, 10, 3))

        text_color = PIXEL_DARK if selected else PIXEL_LIGHT
        label = "가방" if mode == "inventory" else "제작"
        label_font = get_font(13, bold=True)
        surface.blit(label_font.render(label, True, text_color), (rect.x + 44, rect.y + 21))
        key = "E" if mode == "inventory" else "TAB"
        key_font = get_font(9, bold=True)
        badge = pygame.Rect(rect.right - 32, rect.y + 20, 24, 18)
        pygame.draw.rect(surface, PIXEL_DARK if selected else (70, 50, 55), badge)
        pygame.draw.rect(surface, PIXEL_EDGE, badge, 1)
        key_text = key_font.render(key, True, PIXEL_TEXT)
        surface.blit(
            key_text,
            (badge.centerx - key_text.get_width() // 2, badge.centery - key_text.get_height() // 2),
        )

    def _draw_slot(self, surface: pygame.Surface, rect: pygame.Rect, selected: bool):
        pygame.draw.rect(surface, PIXEL_DARK, rect)
        inside = rect.inflate(-4, -4)
        pygame.draw.rect(surface, PIXEL_PANEL, inside)
        pygame.draw.line(
            surface,
            (143, 105, 88),
            (inside.x + 2, inside.y + 2),
            (inside.right - 3, inside.y + 2),
            1,
        )
        pygame.draw.line(
            surface,
            (63, 45, 50),
            (inside.x + 2, inside.bottom - 2),
            (inside.right - 3, inside.bottom - 2),
            1,
        )
        pygame.draw.rect(
            surface,
            PIXEL_LIGHT if selected else PIXEL_EDGE,
            rect,
            3 if selected else 2,
        )

    def _wrap_text(self, text: str, font: pygame.font.Font, width: int, max_lines: int):
        lines = []
        current = ""
        for character in text:
            if character == "\n":
                lines.append(current.rstrip())
                current = ""
                continue
            candidate = current + character
            if current and font.size(candidate)[0] > width:
                lines.append(current.rstrip())
                current = character.lstrip() if character.isspace() else character
            else:
                current = candidate
        if current:
            lines.append(current.rstrip())
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            last_line = lines[-1]
            while last_line and font.size(last_line + "...")[0] > width:
                last_line = last_line[:-1]
            lines[-1] = last_line.rstrip() + "..."
        return lines

    def _draw_wrapped_text(
        self,
        surface: pygame.Surface,
        text: str,
        font: pygame.font.Font,
        color,
        rect: pygame.Rect,
        max_lines: int,
    ):
        for index, line in enumerate(self._wrap_text(text, font, rect.width, max_lines)):
            surface.blit(
                font.render(line, True, color),
                (rect.x, rect.y + index * font.get_linesize()),
            )

    def _draw_inventory(self, surface: pygame.Surface, player):
        left_panel, right_panel = self._body_rects()
        self._draw_content_panel(surface, left_panel)
        self._draw_content_panel(surface, right_panel)
        order = player.inventory.item_order
        self.inventory_slot_rects.clear()
        max_scroll = max(0, (len(order) + 7) // 8 - 3)
        self.inventory_scroll = max(0, min(self.inventory_scroll, max_scroll))
        stack_count = sum(item is not None for item in order)
        section_font = get_font(12, bold=True)
        surface.blit(
            section_font.render(f"보관함  ·  {stack_count}종", True, PIXEL_DARK),
            (left_panel.x + 12, left_panel.y + 7),
        )
        surface.blit(
            section_font.render("아이템 정보", True, PIXEL_DARK),
            (right_panel.x + 12, right_panel.y + 7),
        )
        start_x = left_panel.x + 12
        start_y = left_panel.y + 29
        slot = 48
        gap = 5
        row_step = 80

        for visible_row in range(3):
            row = visible_row + self.inventory_scroll
            for column in range(8):
                index = row * 8 + column
                rect = pygame.Rect(
                    start_x + column * (slot + gap),
                    start_y + visible_row * row_step,
                    slot,
                    slot,
                )
                self.inventory_slot_rects.append((index, rect))
                self._draw_slot(surface, rect, index == self.inventory_selection)
                if index >= len(order):
                    continue
                item_id = order[index]
                if item_id is None:
                    continue
                icon = get_item_icon(item_id, 34)
                surface.blit(
                    icon,
                    (rect.centerx - icon.get_width() // 2, rect.centery - icon.get_height() // 2),
                )
                number = get_font(11, bold=True).render(
                    str(player.inventory.get_count(item_id)),
                    True,
                    PIXEL_TEXT,
                )
                surface.blit(
                    number,
                    (rect.right - number.get_width() - 3, rect.bottom - number.get_height() - 2),
                )
                name = get_item(item_id)["name"]
                label = get_font(11, bold=True).render(name, True, PIXEL_DARK)
                label_rect = pygame.Rect(rect.x - 3, rect.bottom + 1, rect.width + 6, 12)
                previous_clip = surface.get_clip()
                surface.set_clip(label_rect.clip(left_panel).clip(previous_clip))
                surface.blit(label, (rect.centerx - label.get_width() // 2, label_rect.y))
                surface.set_clip(previous_clip)

        selected_item = (
            order[self.inventory_selection]
            if 0 <= self.inventory_selection < len(order)
            else None
        )
        self._draw_inventory_details(surface, right_panel, player, selected_item)

    def _draw_inventory_details(self, surface, rect, player, item_id):
        if item_id is None:
            empty_text = get_font(14, bold=True).render("슬롯을 선택하세요.", True, PIXEL_DARK)
            surface.blit(empty_text, (rect.x + 14, rect.y + 42))
            empty_hint = get_font(12).render("아이템을 선택하면 정보가 표시됩니다.", True, PIXEL_DARK)
            surface.blit(empty_hint, (rect.x + 14, rect.y + 66))
            return

        item = get_item(item_id)
        icon = get_item_icon(item_id, 42)
        surface.blit(icon, (rect.x + 14, rect.y + 30))
        name_font = get_font(16, bold=True)
        surface.blit(
            name_font.render(item["name"], True, PIXEL_DARK),
            (rect.x + 66, rect.y + 32),
        )
        category = get_font(12, bold=True).render(item.get("category", ""), True, (105, 70, 61))
        surface.blit(category, (rect.x + 66, rect.y + 52))
        count = get_font(12, bold=True).render(
            f"보유 {player.inventory.get_count(item_id)}개",
            True,
            PIXEL_DARK,
        )
        surface.blit(count, (rect.x + 66, rect.y + 68))
        pygame.draw.line(
            surface,
            (139, 101, 80),
            (rect.x + 12, rect.y + 87),
            (rect.right - 12, rect.y + 87),
            1,
        )
        description_font = get_font(12)
        description_rect = pygame.Rect(
            rect.x + 12,
            rect.y + 96,
            rect.width - 24,
            rect.height - 148,
        )
        self._draw_wrapped_text(
            surface,
            item.get("description", ""),
            description_font,
            PIXEL_DARK,
            description_rect,
            8,
        )

        is_hotbar_item = self.inventory_selection < HOTBAR_SLOTS
        if is_hotbar_item and self.inventory_selection == self.selected_slot:
            if item_id in ("berry", "coconut"):
                hint = None
            elif item_id in ("campfire", "shelter"):
                hint = "우클릭: 설치"
            elif item_id == "stone_axe":
                hint = "좌클릭: 나무 벌목"
            elif item_id in ("base_raft", "sail"):
                hint = "해안 가까이에서 좌클릭: 설치"
            else:
                hint = "퀵슬롯에서 선택됨"
        else:
            hint = "1-8번 슬롯으로 드래그해 사용"
        if hint:
            hint_rect = pygame.Rect(rect.x + 10, rect.bottom - 34, rect.width - 20, 22)
            pygame.draw.rect(surface, PIXEL_DARK, hint_rect)
            pygame.draw.rect(surface, PIXEL_EDGE, hint_rect.inflate(-2, -2))
            hint_text = get_font(9, bold=True).render(hint, True, PIXEL_TEXT)
            previous_clip = surface.get_clip()
            surface.set_clip(hint_rect.inflate(-6, -2).clip(previous_clip))
            surface.blit(hint_text, (hint_rect.x + 5, hint_rect.y + 4))
            surface.set_clip(previous_clip)

    def _draw_recipes(self, surface: pygame.Surface, player, small_font):
        recipes = list(RECIPES.items())
        left_panel, right_panel = self._body_rects()
        self._draw_content_panel(surface, left_panel)
        self._draw_content_panel(surface, right_panel)
        self.recipe_slot_rects.clear()
        self.craft_btn_rects.clear()
        row_count = (len(recipes) + 1) // 2
        max_scroll = max(0, row_count - 4)
        self.recipe_scroll = max(0, min(self.recipe_scroll, max_scroll))
        if recipes and self.selected_recipe_id not in RECIPES:
            self.selected_recipe_id = recipes[0][0]
        section_font = get_font(12, bold=True)
        surface.blit(
            section_font.render("제작 레시피", True, PIXEL_DARK),
            (left_panel.x + 12, left_panel.y + 7),
        )
        surface.blit(
            section_font.render("선택한 레시피", True, PIXEL_DARK),
            (right_panel.x + 12, right_panel.y + 7),
        )

        for index, (recipe_id, recipe) in enumerate(recipes):
            row = index // 2 - self.recipe_scroll
            if row < 0 or row >= 4:
                continue
            x = left_panel.x + 12 + (index % 2) * 218
            y = left_panel.y + 28 + row * 65
            card = pygame.Rect(x, y, 210, 58)
            can_craft, _, _ = player.inventory.can_craft(recipe_id)
            selected = recipe_id == self.selected_recipe_id
            pygame.draw.rect(
                surface,
                (155, 116, 88) if selected else (191, 157, 121),
                card,
            )
            pygame.draw.rect(
                surface,
                PIXEL_DARK if selected else (135, 96, 78),
                card,
                2 if selected else 1,
            )
            icon = get_item_icon(recipe["result_id"], 28)
            surface.blit(icon, (card.x + 6, card.centery - icon.get_height() // 2))
            name_font = get_font(13, bold=True)
            surface.blit(
                name_font.render(recipe["name"], True, PIXEL_DARK),
                (card.x + 40, card.y + 12),
            )
            state_text = "제작 가능" if can_craft else "재료 부족"
            state_color = WINDOW_GREEN if can_craft else WINDOW_RED
            surface.blit(
                get_font(10, bold=True).render(state_text, True, state_color),
                (card.x + 40, card.y + 30),
            )
            self.recipe_slot_rects.append((recipe_id, card))

        self._draw_recipe_details(surface, right_panel, player, small_font)

    def _draw_recipe_details(self, surface, rect, player, small_font):
        recipe_id = self.selected_recipe_id
        recipe = RECIPES.get(recipe_id) if recipe_id is not None else None
        if recipe is None:
            empty_text = get_font(11, bold=True).render("레시피가 없습니다.", True, PIXEL_DARK)
            surface.blit(empty_text, (rect.x + 14, rect.y + 40))
            return

        can_craft, reason, ingredients = player.inventory.can_craft(recipe_id)
        icon = get_item_icon(recipe["result_id"], 40)
        surface.blit(icon, (rect.x + 12, rect.y + 29))
        name_font = get_font(16, bold=True)
        surface.blit(
            name_font.render(recipe["name"], True, PIXEL_DARK),
            (rect.x + 62, rect.y + 31),
        )
        category = get_font(11, bold=True).render(recipe.get("category", ""), True, (105, 70, 61))
        surface.blit(category, (rect.x + 62, rect.y + 51))
        description_rect = pygame.Rect(rect.x + 12, rect.y + 74, rect.width - 24, 38)
        self._draw_wrapped_text(
            surface,
            recipe.get("description", ""),
            get_font(11),
            PIXEL_DARK,
            description_rect,
            2,
        )
        pygame.draw.line(
            surface,
            (139, 101, 80),
            (rect.x + 12, rect.y + 121),
            (rect.right - 12, rect.y + 121),
            1,
        )
        surface.blit(
            get_font(12, bold=True).render("필요 재료", True, PIXEL_DARK),
            (rect.x + 12, rect.y + 125),
        )
        cell_width = (rect.width - 30) // 2
        for index, (item_id, (have, need)) in enumerate(ingredients.items()):
            column = index % 2
            row = index // 2
            cell = pygame.Rect(
                rect.x + 10 + column * (cell_width + 6),
                rect.y + 147 + row * 37,
                cell_width,
                32,
            )
            pygame.draw.rect(surface, PIXEL_DARK, cell)
            pygame.draw.rect(surface, (197, 165, 128), cell.inflate(-2, -2))
            material_icon = get_item_icon(item_id, 20)
            surface.blit(material_icon, (cell.x + 3, cell.y + 3))
            label_x = cell.x + 27
            label_width = cell.right - label_x - 3
            label_clip = pygame.Rect(label_x, cell.y + 1, label_width, 15)
            count_clip = pygame.Rect(label_x, cell.y + 16, label_width, 14)
            previous_clip = surface.get_clip()
            surface.set_clip(label_clip.clip(previous_clip))
            material_name = get_font(10, bold=True).render(get_item(item_id)["name"], True, PIXEL_DARK)
            surface.blit(material_name, (label_x, cell.y + 1))
            surface.set_clip(count_clip.clip(previous_clip))
            count_color = WINDOW_GREEN if have >= need else WINDOW_RED
            count_text = get_font(10, bold=True).render(f"{have}/{need}", True, count_color)
            surface.blit(count_text, (label_x, cell.y + 16))
            surface.set_clip(previous_clip)

        button = pygame.Rect(rect.right - 118, rect.bottom - 32, 108, 22)
        button_fill = (111, 130, 79) if can_craft else (91, 67, 69)
        pygame.draw.rect(surface, PIXEL_DARK, button)
        pygame.draw.rect(surface, button_fill, button.inflate(-4, -4))
        pygame.draw.rect(surface, PIXEL_EDGE, button, 2)
        button_label = "제작하기" if can_craft else "재료 부족"
        button_text = small_font.render(button_label, True, PIXEL_TEXT)
        surface.blit(
            button_text,
            (button.centerx - button_text.get_width() // 2, button.centery - button_text.get_height() // 2),
        )
        self.craft_btn_rects.append((recipe_id, button, can_craft, reason))


def draw_interaction_prompt(surface: pygame.Surface, prompt_text: str = ""):
    if not prompt_text:
        return
    font = get_font(15, bold=True)
    text = font.render(prompt_text, True, PIXEL_TEXT)
    rect = pygame.Rect((SCREEN_WIDTH - text.get_width() - 28) // 2, HOTBAR_Y - 42, text.get_width() + 28, 34)
    _draw_panel(surface, rect)
    surface.blit(text, (rect.x + 14, rect.y + 9))


def draw_bottom_quickbar(surface: pygame.Surface, player, inventory_ui: Optional[CraftingUI] = None):
    '''Eight centered hotbar slots using Inventory.png and Selection.png.'''
    if inventory_ui is not None and inventory_ui.is_open:
        inventory_ui.hotbar_rects = []
        return
    inv_surf = _load_ui_surface("Inventory.png", scale=HOTBAR_SCALE)
    sel_surf = _load_ui_surface("Selection.png", scale=HOTBAR_SCALE)
    bar_x, bar_y = HOTBAR_X, HOTBAR_Y
    surface.blit(inv_surf, (bar_x, bar_y))

    font = get_font(11, bold=True)
    order = player.inventory.item_order
    selected = inventory_ui.selected_slot if inventory_ui else 0
    rects = []
    icon_size = 32
    for index in range(HOTBAR_SLOTS):
        slot_x = bar_x + round((22 + index * 37) * HOTBAR_SCALE)
        slot_y = bar_y + round(20 * HOTBAR_SCALE)
        rect = pygame.Rect(slot_x, slot_y, HOTBAR_SLOT_SIZE, HOTBAR_SLOT_SIZE)
        rects.append(rect)

        key_text = font.render(str(index + 1), True, (218, 211, 182))
        surface.blit(key_text, (rect.x + 3, rect.y + 1))
        if index < len(order):
            item_id = order[index]
            if item_id is not None:
                icon = get_item_icon(item_id, icon_size)
                surface.blit(icon, (rect.centerx - icon.get_width() // 2, rect.centery - icon.get_height() // 2))
                count = font.render(str(player.inventory.get_count(item_id)), True, (255, 255, 255))
                surface.blit(count, (rect.right - count.get_width() - 3, rect.bottom - count.get_height() - 1))

    if 0 <= selected < len(rects):
        sel_rect = rects[selected]
        surface.blit(
            sel_surf,
            (sel_rect.centerx - sel_surf.get_width() // 2, sel_rect.centery - sel_surf.get_height() // 2),
        )

    if inventory_ui is not None:
        inventory_ui.hotbar_rects = rects
        selected_item = inventory_ui.selected_item_id
        if selected_item in ("berry", "coconut") and player.inventory.has_item(selected_item):
            hint_text = "우클릭으로 먹기"
        elif selected_item == "stone_axe" and player.inventory.has_item(selected_item):
            hint_text = "좌클릭으로 나무 벌목"
        elif selected_item in ("campfire", "shelter") and player.inventory.has_item(selected_item):
            hint_text = "우클릭으로 설치"
        else:
            hint_text = None
        if hint_text:
            hint_font = get_font(13, bold=True)
            hint = hint_font.render(hint_text, True, PIXEL_TEXT)
            hint_rect = pygame.Rect(
                bar_x + inv_surf.get_width() + 10,
                bar_y + round(20 * HOTBAR_SCALE) + (HOTBAR_SLOT_SIZE - 24) // 2,
                hint.get_width() + 24,
                24,
            )
            _draw_panel(surface, hint_rect)
            surface.blit(hint, (hint_rect.centerx - hint.get_width() // 2, hint_rect.y + 4))


class TitleScreen:
    '''Title screen using the cover artwork and start_button/end_button images.'''

    def __init__(self):
        image = load_image("title.png")
        self.background = pygame.transform.smoothscale(image, (SCREEN_WIDTH, SCREEN_HEIGHT))
        self.start_button = _load_ui_surface("start_button.png", scale=2)
        self.end_button = _load_ui_surface("end_button.png", scale=2)
        self.is_open = True
        btn_w = self.start_button.get_width()
        btn_h = self.start_button.get_height()
        btn_x = (SCREEN_WIDTH - btn_w) // 2
        self.buttons = {
            "start": pygame.Rect(btn_x, 326, btn_w, btn_h),
            "quit": pygame.Rect(btn_x, 414, btn_w, btn_h),
        }

    def handle_event(self, event: pygame.event.Event) -> Optional[str]:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                return "start"
            if event.key in (pygame.K_ESCAPE, pygame.K_q):
                return "quit"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for action, rect in self.buttons.items():
                if rect.collidepoint(event.pos):
                    return action
        return None

    def draw(self, surface: pygame.Surface):
        surface.blit(self.background, (0, 0))
        mouse_pos = pygame.mouse.get_pos()
        for action, btn_surf in (("start", self.start_button), ("quit", self.end_button)):
            rect = self.buttons[action]
            surface.blit(btn_surf, rect.topleft)
            if rect.collidepoint(mouse_pos):
                hover = pygame.Surface(rect.size, pygame.SRCALPHA)
                hover.fill((255, 255, 255, 32))
                surface.blit(hover, rect.topleft)


class OpeningSequence:
    '''Pauses the game while the survivor regains consciousness on the beach.'''

    DIALOGUE = (
        ("표류자", "으윽... 여긴 어디지? 배가 침몰한 건가..."),
        ("표류자", "거센 파도에 휩쓸려 무인도까지 떠밀려온 모양이야."),
        ("표류자", "저기 놓인 건 탐험가의 일지인가? 몸을 추스르고 읽어봐야겠어."),
    )

    def __init__(self):
        self.is_active = False
        self.current_line = 0
        self.panel_rect = pygame.Rect(62, SCREEN_HEIGHT - 178, SCREEN_WIDTH - 124, 150)
        self.panel_surface = _make_nine_slice(
            _load_ui_surface("speech.png"),
            self.panel_rect.size,
        )

    def start(self, player):
        self.current_line = 0
        self.is_active = True
        player.is_lying_down = True

    def handle_event(self, event: pygame.event.Event, player) -> bool:
        if not self.is_active:
            return False
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
            self._advance(player)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._advance(player)
        return True

    def _advance(self, player):
        if self.current_line + 1 < len(self.DIALOGUE):
            self.current_line += 1
            return
        self.is_active = False
        player.is_lying_down = False

    def draw(self, surface: pygame.Surface):
        if not self.is_active:
            return

        speaker, dialogue = self.DIALOGUE[self.current_line]
        panel = self.panel_rect
        surface.blit(self.panel_surface, panel.topleft)

        speaker_font = get_font(20, bold=True)
        dialogue_font = get_font(26, bold=True)
        _blit_outlined_text(
            surface,
            speaker,
            speaker_font,
            (255, 218, 145),
            (panel.x + 44, panel.y + 35),
        )
        _blit_outlined_text(
            surface,
            dialogue,
            dialogue_font,
            (255, 249, 226),
            (panel.x + 44, panel.y + 67),
        )


class PauseMenu:
    '''Pause overlay with mouse buttons and keyboard shortcuts.'''

    def __init__(self):
        self.is_open = False
        self.buttons = {}

    def handle_event(self, event: pygame.event.Event) -> Optional[str]:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_c):
                return "continue"
            if event.key == pygame.K_r:
                return "title"
            if event.key == pygame.K_q:
                return "quit"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for action, rect in self.buttons.items():
                if rect.collidepoint(event.pos):
                    return action
        return None

    def draw(self, surface: pygame.Surface):
        if not self.is_open:
            return
        veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 13, 16, 190))
        surface.blit(veil, (0, 0))
        panel = pygame.Rect(SCREEN_WIDTH // 2 - 190, SCREEN_HEIGHT // 2 - 154, 380, 308)
        _draw_panel(surface, panel)
        title_font = get_font(26, bold=True)
        label_font = get_font(16, bold=True)
        title = title_font.render("일시 정지", True, PIXEL_TEXT)
        surface.blit(title, (panel.centerx - title.get_width() // 2, panel.y + 30))
        self.buttons = {}
        for index, (action, label, shortcut) in enumerate((
            ("continue", "계속하기", "ESC / C"),
            ("title", "타이틀 화면으로", "R"),
            ("quit", "종료하기", "Q"),
        )):
            rect = pygame.Rect(panel.x + 54, panel.y + 88 + index * 62, panel.width - 108, 48)
            self.buttons[action] = rect
            pygame.draw.rect(surface, (112, 78, 68), rect)
            pygame.draw.rect(surface, PIXEL_EDGE, rect, 2)
            text = label_font.render(f"{label}  [{shortcut}]", True, PIXEL_TEXT)
            surface.blit(text, (rect.centerx - text.get_width() // 2, rect.y + 13))


def draw_game_over_or_tsunami(surface: pygame.Surface, player, time_system):
    if not player.survival.is_dead and not time_system.tsunami_arrived:
        return
    veil = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    veil.fill((27, 13, 19, 210) if player.survival.is_dead else (18, 25, 45, 220))
    surface.blit(veil, (0, 0))
    panel = pygame.Rect(38, SCREEN_HEIGHT // 2 - 84, SCREEN_WIDTH - 76, 168)
    _draw_panel(surface, panel)
    title_font = get_font(24, bold=True)
    sub_font = get_font(16, bold=True)
    title = "생명력을 모두 소진하여 쓰러졌습니다..." if player.survival.is_dead else "3일이 지나 거대한 해일이 섬에 도달했습니다!"
    subtitle = "Enter / R 키 또는 클릭: 타이틀 화면으로"
    title_surface = title_font.render(
        title,
        True,
        (246, 145, 123) if player.survival.is_dead else (161, 220, 238),
    )
    sub_surface = sub_font.render(subtitle, True, PIXEL_TEXT)
    surface.blit(title_surface, ((SCREEN_WIDTH - title_surface.get_width()) // 2, panel.y + 45))
    surface.blit(sub_surface, ((SCREEN_WIDTH - sub_surface.get_width()) // 2, panel.y + 98))
